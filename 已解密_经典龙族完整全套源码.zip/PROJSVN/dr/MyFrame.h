#include <wx/wxprec.h>
#ifndef WX_PRECOMP    
#include <wx/wx.h>
#endif
#include <wx/protocol/http.h>

#include "wx/custombgwin.h"
#include <wx/thread.h>

wxDECLARE_EVENT(wxEVT_COMMAND_MYTHREAD_COMPLETED, wxThreadEvent);
wxDECLARE_EVENT(wxEVT_COMMAND_MYTHREAD_UPDATE, wxThreadEvent);

class MyFrame;
class MyThread : public wxThread
{
public:    
	MyThread(MyFrame *handler)  : wxThread(wxTHREAD_DETACHED)       
	 {
		m_pHandler = handler;
	 }
 
	~MyThread();
 
protected:   
	 virtual ExitCode Entry();    
	 MyFrame *m_pHandler;
 
};

//class MyFrame : public wxFrame
class MyFrame : public wxCustomBackgroundWindow<wxFrame>
{
public:

	MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size);
	void OnBtnCancel(wxCommandEvent& event);
	void OnBtnStart(wxCommandEvent& event);
	void OnBtnHomePage(wxCommandEvent& event);

	void OnLButtonDown(wxMouseEvent& event);
	void OnLButtonUp(wxMouseEvent& event);
	void OnMouseMove(wxMouseEvent& event);
	void DoAsyncExec(const wxString& cmd);
	void OnListSelect(wxCommandEvent& event);
	void OnCheckBoxCheck(wxCommandEvent& event);
	void OnPwdChange(wxCommandEvent& event);
	void OnUserChang(wxCommandEvent& event);
	//MyFrame(const wxBitmap& bitmap, const wxPoint& pos, const wxSize& size);
	void OnCloseWindow(wxCloseEvent& event);	
	void ShowReadme( int idx );

	 //void OnThreadUpdate(wxThreadEvent&);
	 void OnThreadCompletion(wxThreadEvent&);
	MyThread* m_pThread;
	wxCriticalSection m_pThreadCS;
	wxString httpAddr;
	wxArrayString aString;
private:

	wxPoint m_delta;
	int m_ftpCount, m_ServerCount;
	bool IsDecrypted;
	wxArrayString m_szFtpIp, m_szServerIP, m_szPwd;
	wxString m_readmeURL;
	wxString m_szHomePage;
	wxDECLARE_EVENT_TABLE();
};
