
#include "MyFrame.h"
#include <wx/fileconf.h>
#include <wx/wfstream.h>
#include <wx/sstream.h>
#include <wx/txtstrm.h>
#include <wx/html/htmlwin.h>



#include <wx/url.h>
#include <wx/process.h>
#include <process.h>
#include "base64.h"

void DownloadFile(wxString& szUrl, wxString& szFileName );
bool isExistsByArrayString(wxArrayString szString, wxString sString)
{
	bool ret = false;
	for (int i = 0; i < szString.Count(); i++) {
		if (szString.Item(i) == sString) {
			ret = true;
			break;
		}
	}
	return ret;
}


class MyApp : public wxApp
{
public:
	virtual bool OnInit();
};


MyThread::~MyThread(){   
	wxCriticalSectionLocker enter(m_pHandler->m_pThreadCS);   
	// the thread is being destroyed; make sure not to leave dangling pointers around    
	m_pHandler->m_pThread = NULL;
}

wxThread::ExitCode MyThread::Entry()
{    
	while (!TestDestroy())    
	{        
		// ... do a bit of work...        

		wxGauge* pGauge=(wxGauge*)m_pHandler->FindWindow(5);


		int c = m_pHandler->aString.Count();

		if( c <= 0 )
			break;

		for(int i=0; i<c; i++)
		{
			//pStaticTextPer->SetLabelText(  aString.Item(i) );

			DownloadFile(m_pHandler->httpAddr, m_pHandler->aString.Item(i)  );


			int p = int( ((float)i / (float)c) * 100 );


			pGauge->SetValue( p );

			//pStaticTextPer->SetLabelText( wxString::Format("%d:%d", c, i+1) );
		}

		
		//wxExecute("dragonRaja.bin", wxEXEC_ASYNC, NULL);

		break;
		//this->Pause();
	}    


	//m_pHandler->DoAsyncExec("notepad.exe");
	

	// signal the event handler that this thread is going to be destroyed    
	// NOTE: here we assume that using the m_pHandler pointer is safe,    
	//       (in this case this is assured by the MyFrame destructor)    
	 wxQueueEvent(m_pHandler, new wxThreadEvent(wxEVT_THREAD, wxID_HIGHEST+1 ));   
	 return (wxThread::ExitCode)0;     // success
}

//wxDEFINE_EVENT(wxEVT_COMMAND_MYTHREAD_COMPLETED, wxThreadEvent)
//wxDEFINE_EVENT(wxEVT_COMMAND_MYTHREAD_UPDATE, wxThreadEvent)

wxBEGIN_EVENT_TABLE(MyFrame, wxFrame)
	EVT_BUTTON(4, MyFrame::OnBtnCancel )
	EVT_BUTTON(2, MyFrame::OnBtnStart )
	EVT_BUTTON(3, MyFrame::OnBtnHomePage )
	EVT_LEFT_DOWN( MyFrame::OnLButtonDown)
	EVT_LEFT_UP( MyFrame::OnLButtonUp)
	EVT_MOTION(MyFrame::OnMouseMove)
    EVT_LISTBOX(1, OnListSelect )
	EVT_CHECKBOX(8, MyFrame::OnCheckBoxCheck )
	EVT_TEXT(12, OnPwdChange)
	EVT_COMBOBOX(10, OnUserChang)

	EVT_THREAD(wxID_HIGHEST+1, MyFrame::OnThreadCompletion)

wxEND_EVENT_TABLE()



wxIMPLEMENT_APP(MyApp);


//void MyFrame::OnThreadUpdate(wxThreadEvent&)
//{
// wxMessageOutputDebug().Printf("MYFRAME: MyThread update...\n");
//}

bool MyApp::OnInit()
{    
	MyFrame *frame = new MyFrame(  "", wxDefaultPosition, wxSize(290, 415) );  
	
	frame->Center();
	
	frame->Show( true );    

	return true;
}
void MyFrame::OnLButtonDown(wxMouseEvent& event)
{
	wxPoint point = event.GetPosition();
	PostMessageA(this->GetHWND(), WM_NCLBUTTONDOWN,HTCAPTION,MAKELPARAM(point.x,point.y));
}
void DeleteComma( char *text )
{
	char *temp_ch = strchr( text, ',' );
	if( !temp_ch ) return;

	int len = strlen( temp_ch );

	memmove( temp_ch, temp_ch+1, len );
	DeleteComma( text );
}

char* EatRearWhiteChar( char* pStr )
{	
	char*	szWhite = " \t\n\r";
	char*	pRear;

	pRear = pStr + strlen( pStr ) - 1;
	if ( pRear )
	{
		while ( pStr <= pRear )
		{
			if ( strchr( szWhite, *pRear ) )
			{
				*pRear-- = 0;
			}
			else
			{
				break;
			}
		}
	}

	return	pStr;
}	


void DownloadFile(wxString& szUrl, wxString& szFileName )
{
	//"http://119.147.101.84:12346/dir.txt"
	wxURL url( szUrl + szFileName );

	if (url.GetError() == wxURL_NOERR   )
	{

		wxFileName fileName( szFileName );

		int dirCount = fileName.GetDirCount();

		if( dirCount > 0 && fileName.DirExists() == false )
		{
			fileName.Mkdir();
		}

		wxInputStream *in_stream = 0;
		in_stream = url.GetInputStream();
	//	size_t FileSize = in_stream->GetSize();

		if( in_stream && in_stream->IsOk())
		{
			wxFileOffset size = in_stream->GetLength();

			wxFile file( fileName.GetFullPath(), wxFile::write);
			wxFileOutputStream fileOutputStream( file );
			fileOutputStream.Write(*in_stream);
			fileOutputStream.Close();
			file.Close();			
		}
		delete in_stream;

	}
}

void MyFrame::DoAsyncExec(const wxString& cmd)
{
	
	
	wxExecute(cmd, wxEXEC_ASYNC, NULL);
//m_pThread->Delete();
this->Destroy();
}

void MyFrame::OnBtnStart(wxCommandEvent& event)
{

	if( m_ftpCount == 0)
		return;

	wxBitmapButton* pBtn_Start = (wxBitmapButton*)FindWindow( 2 );
	pBtn_Start->Disable();
	wxCriticalSectionLocker enter(m_pThreadCS);

	// ���ٵ�½��������
	wxCheckBox* pChk_QuickLogin = (wxCheckBox*)FindWindow(8);
	wxCheckBox* pChk_OffSound = (wxCheckBox*)FindWindow(15);
	wxString sFileName = wxString("quickLogin.ini");
	wxComboBox* pCmb_User = (wxComboBox*)FindWindow(10);
	wxTextCtrl* pTxt_Pwd = (wxTextCtrl*)FindWindow(12);
	wxComboBox* pCmb_Server = (wxComboBox*)FindWindow(13);
	wxComboBox* pCmb_Character = (wxComboBox*)FindWindow(14);

	if ( pChk_QuickLogin->IsChecked() ) {
		if (pCmb_Server->GetValue().c_str().AsChar()[0] == '\0') {
			pCmb_Server->SetFocus();
			wxMessageBox("����ѡ�������");
			return;
		}
		if (pCmb_Character->GetValue().c_str().AsChar()[0] == '\0') {
			pCmb_Character->SetFocus();
			wxMessageBox("����ѡ���ɫ");
			return;
		}
		if (pCmb_User->GetValue().c_str().AsChar()[0] == '\0') {
			pCmb_User->SetFocus();
			wxMessageBox("�û�������Ϊ��");
			return;
		}
		if (pTxt_Pwd->GetValue().c_str().AsChar()[0] == '\0') {
			pTxt_Pwd->SetFocus();
			wxMessageBox("���벻��Ϊ��");
			return;
		}
	}

	if (!wxFile::Exists(sFileName)) {
		wxFile file;
		file.Create(sFileName);
		file.Close();
	}

	wxString sPwd;
	sPwd = pTxt_Pwd->GetValue();
	if (!IsDecrypted) {
		sPwd = pTxt_Pwd->GetValue();
		char sPassword[30];
		strcpy(sPassword, base64_encode(reinterpret_cast<const unsigned char*>(sPwd.c_str().AsChar()), strlen(sPwd.c_str().AsChar())).c_str().AsChar());
		sPwd = wxString(sPassword);
	}
		
	wxFileInputStream fileInputStream(sFileName);
	wxFileConfig iniConfig( fileInputStream );
	int nSound = 100;
	int nMusic = 100;
	iniConfig.Read(wxString("config/Sound"), &nSound);
	iniConfig.Read(wxString("config/Music"), &nMusic);
	iniConfig.Write(wxString("Login/isQuickLogin"), pChk_QuickLogin->IsChecked()? 1: 0);
	iniConfig.Write(wxString("Login/user"), pCmb_User->GetValue());
	iniConfig.Write(wxString("Login/password"), sPwd);


	int select = pCmb_Server->GetSelection();

	if( select >= 0 )
	{
		iniConfig.Write(wxString("Login/agentIp"), m_szServerIP[select]);
		iniConfig.Write(wxString("Login/proxyIp"), m_szServerIP[select]);
		iniConfig.Write(wxString("Login/charIndex"), pCmb_Character->GetSelection());
		iniConfig.Write(wxString("Login/Server"), pCmb_Server->GetValue());
		iniConfig.Write(wxString("Login/char"), pCmb_Character->GetValue());
		if (pChk_OffSound->IsChecked()) {
			iniConfig.Write(wxString("config/Sound"), 0);
			iniConfig.Write(wxString("config/Music"), 0);
		} else {
			if ((nSound == 0) && (nMusic == 0)) {
				iniConfig.Write(wxString("config/Sound"), 100);
				iniConfig.Write(wxString("config/Music"), 100);
			} else {
				iniConfig.Write(wxString("config/Sound"), nSound);
				iniConfig.Write(wxString("config/Music"), nMusic);
			}
		}
		int nCount = isExistsByArrayString(pCmb_User->GetStrings(), pCmb_User->GetValue())? pCmb_User->GetCount(): pCmb_User->GetCount() + 1;
		nCount = nCount > 20? 20: nCount;
		iniConfig.Write(wxString("config/user_Count"), nCount);
		iniConfig.Write(wxString("config/user1"), pCmb_User->GetValue());
		iniConfig.Write(wxString("config/pwd1"), sPwd);
		int i = 0;
		int j = 2;
		while (i < nCount - 1) {
			if (pCmb_User->GetString(i) == pCmb_User->GetValue()) {
				i++;
				continue;
			}
			wxString userKey = wxString::Format( "config/user%d", j );
			wxString pwdKey = wxString::Format( "config/pwd%d", j );
			iniConfig.Write(userKey, pCmb_User->GetString(i));
			iniConfig.Write(pwdKey, m_szPwd[i]);
			i++;
			j++;
		}
		wxFileOutputStream fileOutputStream(sFileName);
		wxCSConv cvSystem( wxFONTENCODING_SYSTEM );
		iniConfig.Save(fileOutputStream, cvSystem);
		fileOutputStream.Close();

	}
	wxGauge* pGauge=(wxGauge*)FindWindow(5);

	wxListBox* pListBox = (wxListBox*)FindWindow(1);
	int selectIdx = pListBox->GetSelection();



	httpAddr = "http://"+m_szFtpIp[selectIdx]+":12346/";

	wxURL dirUrl(httpAddr+"dir.txt");

	
//
	if (dirUrl.GetError() == wxURL_NOERR   )
	{
		 wxInputStream *in_stream;
		 in_stream = dirUrl.GetInputStream();
//
		if( in_stream && in_stream->IsOk())
		{

		
		wxTextInputStream txtInputStream(*in_stream);

		wxString dd = txtInputStream.ReadLine();
		wxString dd2 = txtInputStream.ReadLine();

		wxString line;


		bool firstdir = false;
		while( 1 )
		{
			line=txtInputStream.ReadLine();
			if( line.IsEmpty())
			{
				delete in_stream;
				break;
			}

			char text[512] = {0,};
			strcpy( text, line.ToStdString().c_str() );
			char *token = NULL;
			int min = 0;
			int year	= ::atoi(::strtok( text, " /" ));//for taiwan
			int mon		= ::atoi(::strtok( NULL, " /" ));//for taiwan
			int day		= ::atoi(::strtok( NULL, " /" ));//for taiwan
			int hour	= ::atoi(::strtok( NULL, " /:" ));//for taiwan
			char* min_s	= ::strtok( NULL, " -:" ); //for taiwan
			size_t serverFileSize;
			if(min_s[2] =='a')
			{
				if( hour == 12 )
				{
					min_s[2] = 0;
					min = atoi( min_s);
					hour -= 12;
				}
				else
				{
					min_s[2] = 0;
					min = atoi( min_s);
				}
			}
			else
			{
				if( hour == 12 )
				{
					min_s[2] = 0;
					min = atoi( min_s);
				}
				else
				{
					min_s[2] = 0;
					min = atoi( min_s);
					hour += 12;
				}
			}

			token = ::strtok( NULL, " " );
			if( token[0] == '<' ) 
			{

				continue;
			}
			else	
			{
				DeleteComma( token );
				serverFileSize = atoi( token );

				token = ::strtok( NULL, " " );
			}

			
			if(token)
			{
				wxFileName fileName(token);

				bool isDownload = false;
				if(fileName.Exists())
				{
					wxDateTime modDate = fileName.GetModificationTime();

					int fileDay = modDate.GetDay();
					int fileMon = modDate.GetMonth()+1;
					int fileYear = modDate.GetYear();

					int fileHour = modDate.GetHour();
					int fileMin = modDate.GetMinute();

					wxDateTime serverModDate(day,wxDateTime::Month(mon),year,hour,min );
					wxDateTime fileModDate(fileDay,wxDateTime::Month(fileMon),fileYear,fileHour, fileMin );





					wxULongLong localFileSize = fileName.GetSize();
					if( localFileSize != serverFileSize )
						isDownload = true;
					else
					{
						isDownload = serverModDate.IsLaterThan(fileModDate);

					}

					if(isDownload)
					{
						OutputDebugStringA("");
					}
					
				}
				else
				{
					isDownload = true;
				}

				if(isDownload)
				{
					aString.Add( wxString(token) );
					//DownloadFile(httpAddr,  );
				}

			}
		}
	
	}
}

		if ( m_pThread->Run() != wxTHREAD_NO_ERROR )    
		{        
			wxLogError("Can't create the thread!");        
			delete m_pThread;       
			m_pThread = NULL;    
		}




}
void MyFrame::ShowReadme( int idx )
{
	Sleep(2000);

	wxHtmlWindow* pText_readme = (wxHtmlWindow*)FindWindow( 6 );

	
	pText_readme->LoadPage(m_readmeURL);

}




void MyFrame::OnListSelect(wxCommandEvent& event)
{

}


void MyFrame::OnCheckBoxCheck(wxCommandEvent& event)
{
	wxCheckBox* pChk_QuickLogin = (wxCheckBox*)FindWindow(8);
	wxComboBox* pCmb_User = (wxComboBox*)FindWindow(10);
	wxTextCtrl* pTxt_Pwd = (wxTextCtrl*)FindWindow(12);
	wxComboBox* pCmb_Server = (wxComboBox*)FindWindow(13);
	wxComboBox* pCmb_Character = (wxComboBox*)FindWindow(14);	
	pCmb_User->Enable(pChk_QuickLogin->IsChecked());
	pTxt_Pwd->Enable(pChk_QuickLogin->IsChecked());
	pCmb_Server->Enable(pChk_QuickLogin->IsChecked());
	pCmb_Character->Enable(pChk_QuickLogin->IsChecked());
}

void MyFrame::OnPwdChange(wxCommandEvent& event)
{
	IsDecrypted = false;
}

void MyFrame::OnUserChang(wxCommandEvent& event)
{
	wxTextCtrl* pTxt_Pwd = (wxTextCtrl*)FindWindow(12);
	pTxt_Pwd->SetValue(wxString(m_szPwd[event.GetInt()]));
	IsDecrypted = true;
}

void MyFrame::OnLButtonUp(wxMouseEvent& event)
{
}

void MyFrame::OnMouseMove(wxMouseEvent& event)
{
}

void MyFrame::OnBtnCancel(wxCommandEvent& event)
{
	wxCriticalSectionLocker enter(m_pThreadCS);

	if(m_pThread)
	{
		if( m_pThread->IsRunning()  )
			
		{
		 wxMessageOutputDebug().Printf("MYFRAME: deleting thread");
		 if (m_pThread->Delete() != wxTHREAD_NO_ERROR )
			wxLogError("Can't delete the thread!");

		}

	}

	delete m_pThread;
	this->Destroy();
}

void MyFrame::OnCloseWindow(wxCloseEvent& WXUNUSED(event))
{
	//m_timer.Stop();
	this->Destroy();
}

void MyFrame::OnBtnHomePage(wxCommandEvent& event)
{
wxLaunchDefaultBrowser( m_szHomePage );
}




MyFrame::MyFrame( const wxString& title,  const wxPoint& pos, const wxSize& size)       
{
	//::wxInitAllImageHandlers();


	m_ftpCount = 0;
	Create(NULL, wxID_ANY, title, pos, size,  wxBORDER_NONE );

	//SetClientSize(290,415);
	wxBitmap bitmap(  "SelectServer BG.bmp", wxBITMAP_TYPE_BMP);

	//if (bitmap.LoadFile( "bg", wxBITMAP_TYPE_BMP_RESOURCE ))

	if( bitmap.IsNull() == false )
		SetBackgroundBitmap(bitmap);
	

	//wxButton* pBtn_Start = new wxButton(this, 2, "Update", wxPoint(104,377), wxSize(78,26) );

	wxBitmapButton* pBtn_Start = new wxBitmapButton(this, 2, wxBITMAP(OK_NO), wxPoint(104,377), wxSize(78,26) );
	pBtn_Start->SetBitmapPressed(wxBITMAP(OK_DN));
	pBtn_Start->SetBitmapFocus(wxBITMAP(OK_NO));
	
	wxBitmapButton* pBtn_Home = new wxBitmapButton(this, 3,  wxBITMAP(HP_NO), wxPoint(9,377), wxSize(78,26) );
	pBtn_Home->SetBitmapPressed(wxBITMAP(HP_DN));
	pBtn_Home->SetBitmapFocus(wxBITMAP(HP_NO));	
	
	wxBitmapButton* pBtn_Cancel = new wxBitmapButton(this, 4, wxBITMAP(CN_NO), wxPoint(200,377), wxSize(78,26) );
	pBtn_Cancel->SetBitmapPressed(wxBITMAP(CN_DN));
	pBtn_Cancel->SetBitmapFocus(wxBITMAP(CN_NO));		
	
	
	//wxStaticText* pStaticTextPer = new wxStaticText( this,5,"0%", wxPoint(104,330),wxSize(78,26), wxALIGN_CENTRE_HORIZONTAL );
	wxGauge* pGauge = new wxGauge( this, 5, 100, wxPoint(9,363),wxSize(270,10),  wxGA_HORIZONTAL|wxNO_BORDER   ); 
	pGauge->SetShadowWidth(100);
	//pGauge->SetValue( int( ((float)5 / (float)10) * 100 ) );
	
	//wxTextCtrl* pText_readme = new wxTextCtrl( this, 6,  "",wxPoint(90,101),wxSize(183, 193), wxTE_MULTILINE );

	wxHtmlWindow* pText_readme = new wxHtmlWindow( this, 6,   wxPoint(15,50),wxSize(183+74, 193+50), wxTE_MULTILINE );

	// �����˿��ٵ�½��أ�
	wxStaticBox* pGrp_QuickLogin = new wxStaticBox(this, 7, wxString(""), wxPoint(15,293), wxSize(183+74, 70) );

	wxCheckBox* pChk_QuickLogin = new wxCheckBox(this, 8, wxString("���ٵ�½"), wxPoint(18,302), wxSize(64,12) );
	pChk_QuickLogin->SetForegroundColour(wxColour("yellow"));
	wxCheckBox* pChk_OffSound = new wxCheckBox(this, 15, wxString("����"), wxPoint(90,302), wxSize(64,12) );
	pChk_OffSound->SetForegroundColour(wxColour("yellow"));

	wxStaticText* pLbl_User = new wxStaticText(this, 9, wxString("�û���"), wxPoint(126,320), wxSize(64,12) );
	pLbl_User->SetForegroundColour(wxColour("yellow"));
	wxComboBox* pCmb_User = new wxComboBox(this, 10, wxString(""), wxPoint(164,318), wxSize(100,16) );

	wxStaticText* pLbl_Pwd = new wxStaticText(this, 11, wxString("������"), wxPoint(126,340), wxSize(64,12) );
	pLbl_Pwd->SetForegroundColour(wxColour("yellow"));
	wxTextCtrl* pTxt_Pwd = new wxTextCtrl(this, 12, wxString(""), wxPoint(164,338), wxSize(100,16), wxTE_PASSWORD );

	wxString sTemp[1] = {wxString("")};
	wxComboBox* pCmb_Server = new wxComboBox(this, 13, wxString(""), wxPoint(31,318), wxSize(86,16), 0, sTemp, wxCB_READONLY);
	
	wxComboBox* pCmb_Character = new wxComboBox(this, 14, wxString(""), wxPoint(31,338), wxSize(86,16), 0, sTemp, wxCB_READONLY );
	pCmb_Character->Insert(wxString("��һ����ɫ"), 0);
	pCmb_Character->Insert(wxString("�ڶ�����ɫ"), 1);
	pCmb_Character->Insert(wxString("��������ɫ"), 2);
	pCmb_Character->Insert(wxString("���ĸ���ɫ"), 3);
	
	wxListBox* pListBox = new wxListBox( this, 1,  wxPoint(17,101),wxSize(72, 193)  );
	pListBox->Hide();

	wxCSConv cvSystem( wxFONTENCODING_SYSTEM );
	wxFileInputStream fileInputStream("dragon.ini" );
	wxFileConfig iniConfig( fileInputStream, cvSystem );

	// ��ȡ���ٵ�½�����Ϣ
	m_ServerCount = iniConfig.ReadLong(wxString("NetWork/Server_Count"), 1 );
	for (int i = 0; i < m_ServerCount; i++) {
		wxString Host;
		wxString sServerKey = wxString::Format( "NetWork/Name%d", i+1 );
		wxString sServerName;
		iniConfig.Read(sServerKey, &sServerName);
		wxString HostKey = wxString::Format( "NetWork/Name%d_host2", i+1 ); // dragon.bin �У�ֻ��ȡ host2;
		iniConfig.Read(HostKey, &Host);
		if (sServerName == wxEmptyString) continue;
		pCmb_Server->Insert(sServerName, i);
		m_szServerIP.Insert(Host, i);
	}
	if (wxFile::Exists("quickLogin.ini")) {
		wxFileInputStream quickLoginInput("quickLogin.ini" );
		wxFileConfig iniQuickLogin( quickLoginInput, cvSystem );
		int m_UserCount = iniQuickLogin.ReadLong(wxString("config/user_Count"), 0);
		for (int i = 0; i < m_UserCount; i++) {
			wxString Key = wxString::Format( "config/user%d", i+1 );
			wxString sVal;
			iniQuickLogin.Read(Key, &sVal);
			if (sVal == wxEmptyString) continue;
			if (isExistsByArrayString(pCmb_User->GetStrings(), sVal)) continue;
			pCmb_User->Insert(sVal, i);
			Key = wxString::Format( "config/pwd%d", i+1 );
			sVal = wxEmptyString;
			iniQuickLogin.Read(Key, &sVal);
			m_szPwd.Insert(sVal, i);
		}

		wxString sBuf;
		int iTemp = 0;
		iniQuickLogin.Read("Login/isQuickLogin", &iTemp);
		pChk_QuickLogin->SetValue(iTemp == 1);
		iniQuickLogin.Read("Login/Server", &sBuf);
		pCmb_Server->SetValue(sBuf);
		iniQuickLogin.Read("Login/char", &sBuf);
		pCmb_Character->SetValue(sBuf);
		iniQuickLogin.Read("Login/user", &sBuf);
		pCmb_User->SetValue(sBuf);
		iniQuickLogin.Read("Login/password", &sBuf);
		pTxt_Pwd->SetValue(sBuf);
		int nSound = 100;
		int nMusic = 100;
		iniQuickLogin.Read(wxString("config/Sound"), &nSound);
		iniQuickLogin.Read(wxString("config/Music"), &nMusic);
		pChk_OffSound->SetValue((nSound == 0) && (nMusic == 0));
	}
	OnCheckBoxCheck(wxCommandEvent());
	IsDecrypted = true;

	m_ftpCount=iniConfig.ReadLong(wxString("NetWork/Ftp_Count"), 1 );
	for(int i=0;i<m_ftpCount;i++)
	{
		wxString ftpName;

		wxString keyName = wxString::Format( "NetWork/name%d_ftp1", i+1 );
		iniConfig.Read(keyName, &ftpName);
		pListBox->InsertItems(1, &ftpName, i);

	
		wxString szFtpIp;
		keyName = wxString::Format( "NetWork/ftp%d_Host1", i+1 );
		iniConfig.Read(keyName, &szFtpIp);
		m_szFtpIp.Insert(szFtpIp, i);


		iniConfig.Read( "NetWork/readme", &m_readmeURL );
		
	}


	iniConfig.Read("NetWork/HomePage", &m_szHomePage);

	pText_readme->LoadPage(m_readmeURL);

	if(m_ftpCount>0)
	{
		pListBox->SetSelection(0,true);
		ShowReadme(0);
	}
	
	m_pThread = new MyThread( this );
	//m_pThread->Create();



}


void MyFrame::OnThreadCompletion(wxThreadEvent&)
{    
	wxMessageOutputDebug().Printf("MYFRAME: MyThread exited!\n");
	this->DoAsyncExec( "dragonraja.bin" );
}