#include <wx/wxprec.h>
#ifndef WX_PRECOMP    
#include <wx/wx.h>
#endif
#include "wx/custombgwin.h"
wxString base64_encode(unsigned char const* , unsigned int len);  