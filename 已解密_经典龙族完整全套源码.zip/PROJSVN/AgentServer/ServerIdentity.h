﻿// ------------
// AGENT SERVER
// ------------

#ifndef __IS_AGENT_SERVER
#define __IS_AGENT_SERVER
#endif

