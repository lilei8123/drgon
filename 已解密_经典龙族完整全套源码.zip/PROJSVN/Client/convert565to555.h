﻿extern int convert565to555(Spr *sp);
extern void convert565to555RawTile( char *img );
extern int  convert565to555_LoadSprite(Spr *sp);
extern void CopySprToSpr( Spr *target, const Spr *source );