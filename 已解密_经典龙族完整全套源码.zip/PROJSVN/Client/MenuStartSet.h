﻿extern void StartMenuSet();
extern void CommonMenuSet();