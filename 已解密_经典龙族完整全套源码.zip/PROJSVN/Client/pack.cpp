//Author :- Nish [nishforever@vsnl.com]
#include "StdAfx.h"
#include  "pack.h"
#include <iostream>
#include <ctype.h>
#include <algorithm>
#include <stdio.h>
#include <stdarg.h>

using namespace std;
CFileTar cft;
CFileTar::CFileTar()
{

}


CFileTar::~CFileTar()
{
	int i;
		for(i=1; i <= m_TarHeader.GetCount();i++)
		delete m_pTarIndex[i];

}


int CFileTar::TarHeader::GetCount()
{
	return FileCount;
}

int CFileTar::TarHeader::IncrementCount()
{
	if(FileCount<TAR_MAX_FILES)
		return ++FileCount;
	else
		return 0;
}

CFileTar::TarHeader::TarHeader()
{
	FileCount=0;
}

void CFileTar::SetFilePath(char *path)
{
	strcpy(FilePath,path);
	if(path[strlen(path)-1]!='\\')
		strcat(FilePath,"\\");

}

int CFileTar::AddFile(char *fname)
{
	char fullpath[_MAX_PATH];
	strcpy(fullpath,FilePath);
	strcat(fullpath,fname);
	HANDLE hFile;
	DWORD size;
	hFile=CreateFile((LPCSTR)fullpath,GENERIC_READ,0,NULL,
		OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(hFile==INVALID_HANDLE_VALUE)
	{
		CloseHandle(hFile);
		cout << "Can not open file: " << fullpath << endl;
		return 1;
	}
	size=GetFileSize(hFile,NULL);
	if(size==0xFFFFFFFF)
	{
		CloseHandle(hFile);
		return 1;
	}

	if(m_TarHeader.IncrementCount()==0)
	{
		CloseHandle(hFile);
		return 1;
	}
	TarIndex *pTarIndex=new TarIndex;
	strcpy(pTarIndex->FileName,fname);
	pTarIndex->Size=size;

	m_pTarIndex[m_TarHeader.GetCount()]=pTarIndex;

	CloseHandle(hFile);
	cout << "Add file: " << fullpath << endl;
	return 0;
}

int CFileTar::CreateTar(char *TarFName, char *TarPath)
{
	char tarfullpath[_MAX_PATH];
	if(TarPath==NULL)
		strcpy(tarfullpath,FilePath);
	else
		strcpy(tarfullpath,TarPath);
	if(tarfullpath[strlen(tarfullpath)-1]!='\\')
		strcat(tarfullpath,"\\");
	strcat(tarfullpath,TarFName);
	int fdout;
	int ret;
	int i;
	if((fdout=_open(tarfullpath,_O_CREAT|_O_WRONLY|_O_BINARY|_O_TRUNC,
		_S_IWRITE))<0)
	{
		_close(fdout);
		return 1;
	}
	ret=_write(fdout,&m_TarHeader,sizeof(TarHeader));
	int ssize=m_TarHeader.GetCount()*sizeof (TarIndex)+sizeof(TarHeader);
	for(i=1;i<=m_TarHeader.GetCount();i++)
	{
		m_pTarIndex[i]->Start=ssize;
		ret=_write(fdout,m_pTarIndex[i],sizeof(TarIndex));
		ssize += m_pTarIndex[i]->Size;
	}
	for(i=1;i<=m_TarHeader.GetCount();i++)
	{
		char filetoadd[_MAX_PATH];
		strcpy(filetoadd,FilePath);
		strcat(filetoadd,m_pTarIndex[i]->FileName);
		AppendFile(fdout,filetoadd);
	}

	_close(fdout);
	return 0;
}

int CFileTar::AppendFile(int fdout, char *fpath)
{
	int fdin;
	int len;
	if((fdin=_open(fpath,_O_RDONLY|_O_BINARY))<0)
	{
		_close(fdin);
		return 1;
	}
	char buffer[NBUFFSIZE];
	while((len=_read(fdin,buffer,NBUFFSIZE))>0)
	{
		_write(fdout,buffer,len);
	}
	_close(fdin);
	return 0;
}


int CFileTar::GetTarInfo(char *TarFile,TarHeader *pTarHeader)
{
	int fdin;
	if((fdin=_open(TarFile,_O_BINARY|_O_RDONLY))<0)
	{
		_close(fdin);
		return 1;
	}
	memset(pTarHeader,0,sizeof(TarHeader));
	_read(fdin,pTarHeader,sizeof(TarHeader));

	_close(fdin);
	return 0;
}

int CFileTar::GetFileInfo(char *TarFile, TarIndex *pTarIndex, int index)
{
	int fdin;
	if((fdin=_open(TarFile,_O_BINARY|_O_RDONLY))<0)
	{
		_close(fdin);
		return 1;
	}
	TarHeader tmpTarHeader;
	_read(fdin,&tmpTarHeader,sizeof(TarHeader));
	int i;
		for(i=1;i<=tmpTarHeader.GetCount();i++)
	{
		_read(fdin,pTarIndex,sizeof(TarIndex));

		if(i==index)
			break;
	}

	_close(fdin);
	return 0;

}

int CFileTar::UnTar(char *TarFile, int index, char *fpath)
{
	TarIndex ti;
	if(GetFileInfo(TarFile,&ti,index))
		return 1;
	int fdin,fdout;
	if((fdin=_open(TarFile,_O_BINARY|_O_RDONLY))<0)
	{
		_close(fdin);
		return 1;
	}
	if((fdout=_open(fpath,_O_CREAT|_O_WRONLY|_O_BINARY|_O_TRUNC,
		_S_IWRITE))<0)
	{
		_close(fdin);
		_close(fdout);
		return 1;
	}
	_lseek(fdin,ti.Start,SEEK_SET);
	long rem;
	char buff[NBUFFSIZE];
	rem=ti.Size;

	while(rem > NBUFFSIZE)
	{
		_read(fdin,buff,NBUFFSIZE);
		_write(fdout,buff,NBUFFSIZE);
		rem -= NBUFFSIZE;
	}
	if(rem>0)
	{
		_read(fdin,buff,rem);
		_write(fdout,buff,rem);
	}

	_close(fdin);
	_close(fdout);
	return 0;
}

int CFileTar::UnTar(char *TarFile, char *dpath)
{
	TarHeader th;
	GetTarInfo(TarFile,&th);
	TarIndex ti;
	char fpath[_MAX_PATH];
	int i;
		for(i=1;i<=th.GetCount();i++)
	{
		GetFileInfo(TarFile,&ti,i);
		strcpy(fpath,dpath);
		if(fpath[strlen(fpath)-1]!='\\')
			strcat(fpath,"\\");
		strcat(fpath,ti.FileName);
		UnTar(TarFile,i,fpath);
	}

	return 0;
}
int CFileTar::PackPreload(char *packFile){
	TarHeader th;
    
	GetTarInfo(packFile,&th);
	
	TarIndex ti;
	int i;
	string f1(packFile);
	f1 = f1.substr(0,f1.length()-4);
    for(i=1;i<=th.GetCount();i++)
	{
		PackHandle cph;
		GetFileInfo(packFile,&ti,i);

		string f2 = f1 + string(ti.FileName);
		char chars[] = "./\\";
		for (unsigned int i = 0; i < strlen(chars); ++i)
	    {
		  f2.erase (std::remove(f2.begin(), f2.end(), chars[i]), f2.end());
	    }
        std::transform( f2.begin(), f2.end(), f2.begin(), ::tolower);
		cph.fp=NULL;
		cph.Start = ti.Start;
		cph.Size = ti.Size;
		sprintf_s(cph.packFile,"%s",packFile);
		fileMap.insert(pair<string, PackHandle>(f2, cph));
	}
	return 1;
}

int CFileTar::PackOpen(char* filename, PackHandle *ph, char* mode){
	FILE *fp;
	currentPos=0;
	char chars[] = "./\\";
	string f2(filename); 
	for (unsigned int i = 0; i < strlen(chars); ++i)
	{
		f2.erase (std::remove(f2.begin(), f2.end(), chars[i]), f2.end());
	}
    std::transform( f2.begin(), f2.end(), f2.begin(), ::tolower);
	it=fileMap.find(f2);
	if(it != fileMap.end()){
		PackHandle tmp = (PackHandle)it->second;
		ph->Start = tmp.Start;
		ph->Size = tmp.Size;
		fopen_s(&fp,tmp.packFile,mode);
		ph->fp = fp;
        fseek(ph->fp, ph->Start, SEEK_SET);
		if(fp)
			return 1;
		else 
			return 0;
	}
	else{
		fopen_s(&fp,filename,mode);
		ph->Start = 0;
		ph->fp = fp;
		if(fp){
			ph->Size = _filelength(_fileno(fp));
			
			return 1;
		}
		else{
			return 0;
		}
	}
	/*char key[_MAX_PATH] = {0,};
	currentPos=0;
	sprintf(key,"%s%s", packFile, filename);
	string filekey(key);
	FILE *fp;
	fopen_s(&fp,packFile,"rb");
	it=fileMap.find(filekey);
	if(it != fileMap.end()){
		//memcpy(ph, &(PackHandle)it->second, sizeof(PackHandle));
		PackHandle tmp = (PackHandle)it->second;
		ph->Start = tmp.Start;
		ph->Size = tmp.Size;
		ph->fp = fp;
		return 1;
	}
	PackHandle cph;
    TarHeader th;
    
	GetTarInfo(packFile,&th);
	TarIndex ti;
	int i;
    for(i=1;i<=th.GetCount();i++)
	{
		GetFileInfo(packFile,&ti,i);
		string f1(filename);
		string f2(ti.FileName);
		char chars[] = "./\\";
		for (unsigned int i = 0; i < strlen(chars); ++i)
	    {
		  // you need include <algorithm> to use general algorithms like std::remove()
		  f1.erase (std::remove(f1.begin(), f1.end(), chars[i]), f1.end());
		  f2.erase (std::remove(f2.begin(), f2.end(), chars[i]), f2.end());
	    }
        std::transform( f1.begin(), f1.end(), f1.begin(), ::tolower);
        std::transform( f2.begin(), f2.end(), f2.begin(), ::tolower);
		if(f1.length()>=f2.length()){
			if(f1.compare(f1.length()-f2.length(), f2.length(), f2)==0){
				ph->fp = fp;
				ph->Start = ti.Start;
				ph->Size  = ti.Size;

				cph.fp=fp;
				cph.Start = ti.Start;
				cph.Size = ti.Size;
				fileMap.insert(pair<string, PackHandle>(filekey, cph));
				return 1;
			}
		}
	}
    return 0;
	*/
}

int CFileTar::PackRead(void * ptr, size_t Size, size_t Count, PackHandle *ph){
    /*currentPos = PackTell(ph);
	if(currentPos + Count*Size > ph->Start + ph->Size)
		return 0;
	else*/
		return fread(ptr, Size, Count, ph->fp);
}

char* CFileTar::PackGets(char * str, int num, PackHandle *ph){
	long int cp = ftell(ph->fp);
	if(cp >=  ph->Start + ph->Size) return NULL;
	return fgets(str, num, ph->fp);

}

int CFileTar::PackSeek(PackHandle *ph, long int offset, int origin){
	if(origin == SEEK_SET)
		offset = ph->Start + offset;
	else if(origin == SEEK_END){
		offset = ph->Start+ph->Size;
	}
	else{
		offset = offset;
	}
	currentPos = offset;
    return fseek(ph->fp, offset, origin);
}

int CFileTar::PackRewind(PackHandle *ph){
    return fseek(ph->fp, ph->Start, SEEK_SET);
}

size_t CFileTar::PackWrite ( const void * ptr, size_t size, size_t count, PackHandle *ph ){
	if(currentPos==0){
        fseek(ph->fp, ph->Start, SEEK_SET);
    }
	currentPos = ph->Start+count*size;
	return fwrite ( ptr, size,count, ph->fp );
}

int CFileTar::PackPrint(PackHandle* ph, const char * format, ... ){
	int ret = 0;
	va_list args;
	va_start(args, format);
	ret = vfprintf(ph->fp, format, args);
	va_end(args);
	return ret;
}

int CFileTar::PackScanf(PackHandle* ph, const char * format, ... ){
	long int cp = ftell(ph->fp);
	if(cp >  ph->Start + ph->Size) return EOF;
	int ret = EOF;
	va_list args;
	va_start(args, format);
	ret = fscanf(ph->fp, format, (void **)args);
	va_end(args);
	return ret;
}

int CFileTar::PackClose(PackHandle *ph){
    fclose(ph->fp);
	ph=NULL;
    return 0;
}

int  CFileTar::PackGetpos (PackHandle *ph, fpos_t * pos ){
	return fgetpos(ph->fp,pos);
}

long int CFileTar::PackTell ( PackHandle *ph ){
	return ftell(ph->fp);
}

int CFileTar::PackEOF(PackHandle *ph){
	long int cp = ftell(ph->fp);
	return (cp >= ph->Start + ph->Size) ;
}




