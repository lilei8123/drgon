﻿/*****************************************************************************\
* Copyright (c), Future Entertainment World / Seoul, Republic of Korea        *
* All Rights Reserved.                                                        *
*                                                                             *
* This document contains proprietary and confidential information.  No        *
* parts of this document or the computer program it embodies may be in        *
* any way copied, duplicated, reproduced, translated into a different         *
* programming language, or distributed to any person, company, or             *
* corporation without the prior written consent of Future Entertainment World *
\*****************************************************************************/

#include "Stdafx.h"
#include <windows.h>
#include "resource.h"
#include "Dragon.h"
#include "Hong_Sub.h"
#include "GameProc.h"
#include "Menu.h"
//#include "MenuDef.h"
#include "MenuNetWork.h"
#include "Char.h"
#include "Map.h"
#include "Counseler.h"		// 001129 KHS
#include "Music.h"
#include "LineCommand.h"
#include "smallmenu.h"
#include "menuset.h"
#include "SmallMenuSet.h"//020620 lsw
#include "chat.h"
#include "MailMgr.h"
#include "Skill.h"//021030 lsw
#include "Auction.h"//021030 lsw
#include "cScreenEffect.h" // CSD-030306
#include "ArenaManager.h"
#include "QuestFunction.h"
extern char g_szConfigFile[_MAX_PATH];
extern CHARACTERLIST g_CharacterList;
extern void SendSquadChatMessage(int type,char* Message);			
extern void WarMenuOpen();											
extern void WarMenuNoticeOpen();
extern bool g_bScrollScreen;
extern void ShowCommanderInfo(); 				// 010924 LTS
extern void ShowSquadInfo();
extern void WarGiveLife();						// 011015 LTS
extern void WarControl(char* Arg);				// 011020 LTS
extern void WarLoopTime(char* Arg);				// 011025 LTS
extern void WarGiveLife(char* Arg);				// 011213 LTS
extern void WarGiveLife2(char* Arg);			
extern int	IsDead( LPCHARACTER ch );
extern void SendLocalWarChat(char* Arg);		// LTS NEW LOCALWAR	
extern void SendAction(int i,int Direction);	// LTS ACTION
extern void SendCMD_SET_QUESTMODE(char* Arg);	// LTS DRAGON MODIFY
extern void SendCheckDualFame();              // LTS DUAL FAME
extern bool g_bStopWeatherSystem; // CSD-CN-031215
extern bool g_bOffWeatherSystem; // CSD-CN-031217
extern bool g_autoStrikeBack;
extern void SendRegistAllianceImsi(char *guild_name, char *guild_explain);
extern int g_bbsTextDir ;
extern UINT g_acp;
char g_bbs[512] = {0,};

LINECOMMAND LC[MAX_LINE_COMMAND_] = 
{	//< CSD-030311 : 영어는 대문자로 써주세요..
	{"", LC_EAT_ITEM},					// 먹기										
	{"", LC_CHAT_WHISPER},				// @										
	{"", LC_CHAT_WHISPER},				// TO
	{"", LC_CHAT_PARTY},				// 파티에게
	{"", LC_CHAT_PARTY},				// 동료											
	{"", LC_CHAT_GUILD},				// 길드에게								
	{"", LC_TOTAL_MAP_CONNECTIONS},		// 맵현재인원								
	{"", LC_TOTAL_CONNECTIONS},			// 현재인원											
	{"", LC_TOTAL_CONNECTIONS},			// 누구											
	{"", LC_TOTAL_CONNECTIONS},			// USER												
	{"", LC_MAKE_PARTY},				// PARTY											
	{"", LC_MAKE_PARTY},				// 파티													
	{"", LC_DEFAULT_WALK},				// 걷기													
	{"", LC_DEFAULT_WALK},				// 기본걷기													
	{"", LC_DEFAULT_RUN},				// 달리기												
	{"", LC_DEFAULT_RUN},				// 기본달리기											
	{"", LC_TAME_STOP},					// 쉬어												
	{"", LC_TAME_STOP},					// 그만																
	{"", LC_TAME_STOP},					// STOP														
	{"", LC_TAME_ATTACK},				// 공격해													
	{"", LC_TAME_ATTACK},				// ATTACK												
	{"", LC_TAME_FOLLOWME},				// 따라와											
	{"", LC_TAME_FOLLOWME},				// FOLLOW												
	{"", LC_TAME_NAME},					// 네이름은												
	{"", LC_TAME_NAME},					// NAME											
	{"", LC_OPEN_TIMEMENU},				// 시간보기								
	{"", LC_OPEN_TIMEMENU},				// TIME 								
	{"", LC_CLOSE_TIMEMENU},			// 시간끄기									
	{"", LC_CLOSE_TIMEMENU},			// 시간닫기											
	{"", LC_OPEN_TIMEMENU},				// 시간										
	{"", LC_CLOSE_ALL},					// OFF													
	{"", LC_EAR_MESSAGE_REFUSE_WHO},	// 거부상대												
	{"", LC_EAR_MESSAGE_REFUSE},		// 귓속말거부									
	{"", LC_EAR_MESSAGE_OK},			// 귓속말허락									
	{"", LC_REPRINT_EAR_MESSAGE},		// 쪽지				
	{"", LC_GREETING},					// 인사말 								
	{"", LC_EXPLAIN_CLOSE},				// 설명닫기																
	{"", LC_EXPLAIN_CLOSE},				// 설명끄기									
	{"", LC_EXPLAIN_OPEN},				// 설명보기					
	{"", LC_REQ_MAN_TO_MAN},			// 결투						
	{"", LC_RESET_MAGIC_ARRAY},			// 신의권능 						
	{"", LC_RESET_MAGIC_ARRAY},			// 마법재배치										
	{"", LC_MSG_ALL_NATION},			// 모두							
	{"", LC_GUILD_EXIT},				// 길드탈퇴					
	{"", LC_GUILD_JOIN},				// 길드가입						
	{"", LC_GUILD_ALL_MSG},				// 길드모두					
	{"", LC_GUILD_ALL_MSG},				// 길드공지					
	{"", LC_GUILD_CHANGE_EACH_LEVEL},	// 길드등급							
	{"", LC_GUILD_CMD_INFO},			// 길드명령
	{"", LC_CHANGE_JOB},				// 직업바꾸기
	{"", LC_CHANGE_JOB},				// 직업교체						
	{"", LC_STOP_WAR},					// 휴전
	{"", LC_SCAN_TARGET_VYSEUS},		// 야사스의 눈이여
	{"", LC_SCAN_TARGET_ZYPERN},		// 닐림의 의지여
	{"", LC_KILL_CHARACTER},			// 휴식
	{"", LC_DIRECTIONS},				// 방향
	{"", LC_OPEN_DISPLAY_SKILL_EXP},	// 스킬보기
	{"", LC_CLOSE_DISPLAY_SKILL_EXP},	// 스킬닫기
	{"", LC_OPEN_DISPLAY_TAC_EXP},		// 택틱보기
	{"", LC_CLOSE_DISPLAY_TAC_EXP},		// 택틱닫기
	{"", LC_LIGHTOFRESCUE},				// 구원의빛
	{"", LC_AUTOLEVELUP_CLOSE},			// 자동해제
	{"", LC_AUTOLEVELUP_OPEN},			// 자동분배							
	{"", LC_ANNONCE_ON},			    // 도움말듣기
	{"", LC_ANNONCE_OFF},			    // 도움말끄기
	{"", LC_EAR_COMMAND_INFO},		    // 귓속말
	{"", LC_FIGHTMAP_ALL_CHAT},		    // 전체
	{"", LC_SMALL_TIPS},			    // 도움
	{"", LC_SMALL_TIPS},			    // HELP
	{"", LC_SMALL_TIPS},			    // ?
	{"", LC_EMOTION},				    // 감정
	{"", LC_EXIT_GUILD},
	{"", LC_VIEW_NK},				    // NK 수치 보기
	{"", LC_SQUAD_LEADER},			    // 사령관 -> 부대장
	{"", LC_SQUAD},					    // 사령관 -> 부대
	{"", LC_SQUAD_MEMBER},              // 부대장 -> 부대원
	{"", LC_SQUAD_MEMBER_TO_MEMBER},    // 부대원 -> 부대원	
	{"", LC_WAR_MENU_OPEN},		        // War Menu Open
	{"", LC_WAR_MENU_NOTICE_OPEN},	    // War Menu NOTICE
	{"", LC_GUILD_MAIL},			    // 길드메일
	{"", LC_SQUAD_CHAT},			    // 010915 LTS	//임시
	{"", LC_GUILD_CHAT},			    // #
	{"", LC_COMMANDER_INFO},		    // 010924 LTS
	{"", LC_SQUAD_INFO},			    // 010924 LTS	
	{"", LC_GUILD_CHAT_ON},		        // 길드채팅켜기
	{"", LC_GUILD_CHAT_OFF},		    // 길드채팅끄기
	{"", LC_RESET_ABILITY},		        // 어빌재분배
	{"", LC_WAR_GIVE_LIFE},		        // 011015 LTS	// 전쟁터 유령 살리기 // 부활
	{"", LC_PARTY_ALL_FREE},		    // 파티해제
	{"", LC_SEND_GUILD_MAIL},	        // 길드메일보내기
	{"", LC_SEND_MAIL},		 	        // 메일보내기
	{"", LC_SHOW_ME_DUAL},		  	    // 어둠을 걷고 시간을 달린다
	{"", LC_REPORTER_MODE},			    // 기자모드
	{"", LC_FRIEND_MENU},			    // 친구
	{"", LC_WAR_GIVE_LIFE2},		    // 부활장소				// 011213 LTS	N_YILSE
	{"", LC_SCAN_TARGET_YILSE},		    // 011217 LTS
	{"", LC_GETCOLOSSUS_INFO},		    // 콜로서스, 
	{"", LC_GETCOLOSSUS_INFO},		    // colossus, 
	{"", LC_INVITE_COLOSSUS},		    // 초대 
	{"", LC_JOIN_COLOSSUS},			    // 참가
	{"", LC_PK_ON_OFF},				    // PK
	{"", LC_COMBAT_SKILL_ON_OFF},	    // PK//020420 lsw
	{"", LC_LOCALWAR_CHAT},			    // 국지전	%		// LTS NEW LOCALWAR
	{"", LC_QUESTMODE},				    // LTS DRAGON MODIFY
	{"", LC_WEATHER_ON}, // CSD-CN-031215 : 날씨효과켜기
	{"", LC_WEATHER_OFF}, // CSD-CN-031215 : 날씨효과끄기
	{"", LC_COMBAT_RESET},			    // CSD-020611
	{"", LC_MAGIC_DISPLAY_ON},          // CSD-020620
	{"", LC_MAGIC_DISPLAY_OFF},         // CSD-020620
	{"", LC_SET_NORMAL_CHAT_MODE},      // CSD-020620
	{"", LC_REPRINT_NORMAL_CHAT},	    // 보통쪽지
	{"", LC_REPRINT_GUILD_CHAT},	    // 길드쪽지
	{"", LC_REPRINT_GUILD_BBS},	        // 길드공지쪽지
	{"", LC_TRADE},			            // 020808 YGI 
	{"", LC_CHECK_DUAL_FAME},		    // 듀얼명성     // LTS DUAL FAME
	{"", LC_WHAT_QUEST_IN_MAP},	        // 021007	//맵에 어떤 퀘스트가 있는가?
	{"", LC_MERCHANT_BBS},		        // 021022 상인과 직접 거래
	{"", LC_MERCHANT_EXCHANGE},		    // 021022 상인과 거래
	{"", LC_EVENT_MOVE_MAP},		    // 021107 YGI
	//kyo <<
	{"", LC_EMOTI_LOVE},
	{"", LC_EMOTI_SMILE},
	{"", LC_EMOTI_HAPPY},
	{"", LC_EMOTI_SHY},
	{"", LC_EMOTI_CRY},
	{"", LC_EMOTI_GOOD},
	{"", LC_EMOTI_SORRY},
	{"", LC_EMOTI_ANGER},
	{"", LC_EMOTI_THANKS},
	{"", LC_EMOTI_TELL},
	{"", LC_GAME_SCISSOR},
	{"", LC_GAME_ROCK},
	{"", LC_GAME_PAPER},
	{"", LC_GAME_GO},
	{"", LC_GAME_HELP},
	{"", LC_GAME_PARTY},
	{"", LC_GAME_HEAL},
	{"", LC_GAME_TRANSACTION},
	{"", LC_GAME_BEG},
	{"", LC_GAME_CONGRAGULATION},

	{"", LC_BBS_LIMITED_USER_ADD},
	{"", LC_BBS_ON},
	{"", LC_BBS_OFF},
	//>>kyo
	{"", 0},
	{"", 0},
	{"",0},
	{"",0},
	{"",150},
	{"",151},
	{"",152},
	{"",153},
	{"",154},
	{"",155},
	{"",156},
	{"",157},
	{"",158},
	{"",159},
	{"",160},
	{"",161}, //查看会员卡到期
	{"",162}, //查看积分卡到期
	{"",163}, //查看积分倍数
	{"",164}, //help
	{"",165}, 
	{"",166}, 
	{"",167},
	{"",168},//allianceCreate
	{"",169},//allianceJoin
	{"",170},//allianceQuit
	{"",171},//allianceExit
	{"",172},//allianceDisband
	{"",173},//item
	{"",174},//sendOnlineItem
	{"",175},//sendItem
	{"",176},//sendDialog
	{"",177},//item2
	{"",178},//duelOff
	{"",179},//duelOn
	{ "", 180 },//  ShowLocalWarMenu
	{ "", 181 },//  HideLocalWarMenu
	{ "", 182 },//LockViewOff
	{ "", 183 },//LockViewOn
	{ "", 184 },//moveTo
	{ "", 185},//hideSelf
	{ "", 186},//showSelf
	{ "", 187},//freeze
	{ "", 188},//unfreeze
	{"", 189},//文字坚排
	{"", 190},//会员
	
	
};  //> CSD-030311

char	Lc_ChatType;
char	Lc_TempChatName[ 31];
char	Lc_DefaultMoveType;

int		Lc_AutoMovementCmd;


char	GreetingStr[ FILENAME_MAX];

/////////////////////////////////////////////////////////////////////////////////////////
//
//		User Functions Declaration..
//
//
void SendTotalMapConnections( void );
void SendTotalConnections( void );
void RecvTotalMapConnections( int no );
void RecvTotalConnections( int no );

void LC_SendInputParty( char *name );

void SendTameCommand( int command, char *s );
void RecvHostEnd(  tame_end *p );



///////////////////////////////////////////////////////////////////////////////////////////
//
//		User Functions..
//
//

int LineCommandSortFunction( const void *first, const void *second )
{
	LINECOMMAND *lc1 = (LINECOMMAND *)first;
	LINECOMMAND *lc2 = (LINECOMMAND *)second;
	return ( strlen( lc2->reserved ) - strlen( lc1->reserved ) );
}
#ifdef _DEBUG

BOOL CALLBACK SendItemDialogProc(HWND hDlg, UINT Message, WPARAM wParam, LPARAM lParam)
{
	char temp[ 512 ] = {0,};
	
	switch(Message)
	{
	case WM_INITDIALOG:		Edit_SetText ( GetDlgItem(hDlg, IDC_EDIT_NAME ), temp );
		return TRUE;
		
	case WM_PAINT:
		break;
		
	case WM_COMMAND:
		switch( LOWORD( wParam ) )
		{
		case IDOK:	
			{
				t_send_item sendItem;

				memset( &sendItem, 0, sizeof(t_send_item) );
				
				char name[512] = {0,};
				HWND hEditName = GetDlgItem( hDlg, IDC_EDIT_NAME );
				GetWindowText( hEditName, name, 512 );

				char item[256] = {0,};
				HWND hEditItem = GetDlgItem( hDlg, IDC_EDIT_ITEM );
				GetWindowText( hEditItem, item, 256 );


				int grade = 0, soksung1 = 0, soksung2 = 0, soksung3 = 0, iHighLevel = 0, IsDynamicRare = 0;
				ITEMATTR* pItem = &(sendItem.item);

				RareMain* pRareMain = (RareMain*)&pItem->attr[IATTR_RARE_MAIN];
					
				sscanf( item, "%d,%d,%d,%d,%d,%d,%d,%d", &(pItem->item_no), &(pItem->attr[0]), &grade, &soksung1, &soksung2, &soksung3, &iHighLevel, &IsDynamicRare );		

				pRareMain->grade = grade;
				pRareMain->soksung1 = soksung1;
				pRareMain->soksung2 = soksung2;
				pRareMain->soksung3 = soksung3;
				pRareMain->iHighLevel = iHighLevel;
				pRareMain->IsDynamicRare = IsDynamicRare;
				sendItem.type = 1;
				char *token = strtok( name, "," );

				if( token != NULL )
				{
				strcpy( sendItem.targetName, token );					
				SendDirectDB(CMD_CHECK_CHAR_ONLINE, &sendItem, sizeof(t_send_item)  );
				}

				if( pItem->item_no > 0  )
				{

					while( token != NULL )
					{				
						token = strtok( NULL, "," ); 

						if( token != NULL )
						{
							strcpy( sendItem.targetName, token );					
							SendDirectDB(CMD_CHECK_CHAR_ONLINE, &sendItem, sizeof(t_send_item)  );
						}
					}
				}

			}
			break;
			
		case IDCANCEL :	EndDialog(hDlg, LOWORD(wParam));	
			return (TRUE);
		}
		break;
	}
	
	return FALSE;	
}
#endif

void SendGuildNpcCmd( int id )
{
	t_packet p;
	
	p.h.header.type = CMD_CLIENT_GUILD_NPC_CMD;
	p.u.debug_client_req_char_info.id = id;
	p.h.header.size = sizeof( t_req_guild_npc_cmd );
	
	QueuePacket( &p, 1 );
}

HWND g_hSendDialog;
extern void DoHeroMove( int movetype, int x, int y );
extern void HeroActionProc( int mousebutton, int mx, int my  );
int IsLineCommand( char *message, int nsize )
{	
	//if( Hero->viewtype == VIEWTYPE_GHOST_ )// 유령일 경우
	//	return ;		// 명령어를 못 하게 한다.
	int c; 
	LPLINECOMMAND lc;
	LPCHARACTER ch = Hero;
	char *t, *t1;
	char tempmessage[MAX_CHAT_STRING];
	
	if( *message != '/' ) return 0;
	
	message ++;
	strcpy( tempmessage, message );
	//	CharUpper( message );//020926 lsw
	static int first = 1;
	if( first )
	{
		int i;
		for( i=0; i<MAX_LINE_COMMAND_; i++ )
		{
			if( !LC[i].reserved[0] ) break;
		}
		qsort( LC, i, sizeof( LINECOMMAND ), LineCommandSortFunction );
		first = 0;
	}
	
	c = 0;
	lc = &LC[ c];
	while( lc->reserved[0] )
	{		
		if( 0 == strnicmp( lc->reserved, message, strlen( lc->reserved )) )//020926 lsw
		{
			t = tempmessage + strlen(lc->reserved );
			t1 = EatFrontWhiteChar( t );
			
			switch (lc->command)
			{
			//case 152://guildNpc 
			//	{
			//		char subCmd[256] = {0,};
			//		sscanf( t, "%s", subCmd );		

			//		if( strcmp( "lv", subCmd  ) == 0 )
			//		{
			//			SendGuildNpcCmd(LEV);
			//		}
			//		else if( strcmp( "hp", subCmd  ) == 0 )
			//		{
			//			SendGuildNpcCmd(HP);
			//		}
			//		else if( strcmp( "maxHp", subCmd  ) == 0 )
			//		{
			//			SendGuildNpcCmd(MAX_HP);
			//		}
			//		else if( strcmp( "p", subCmd  ) == 0 )
			//		{
			//			SendGuildNpcCmd( 100 + 152 );  //魔法-排除危险
			//		}
			//		else if( strcmp( "help", subCmd  ) == 0 )
			//		{
			//			SendGuildNpcCmd( 80  );
			//		}
			//		else if( strcmp( "learnHelp", subCmd  ) == 0 )
			//		{
			//			SendGuildNpcCmd( 81  );
			//		}	
			//		else if( strcmp( "learnP", subCmd  ) == 0 )
			//		{
			//			SendGuildNpcCmd( 200 + 152  );
			//		}	
			//	}
			//	break;

			case 155://clearExp
				{
					t_packet p;
					p.h.header.type = CMD_LINE_COMMAND;
					p.h.header.size = sizeof(int);
					*( (int*)p.u.data ) = 155;
					QueuePacket( &p, 1 );
					
					break;
				}


			case 156://killMe
				{
					t_packet p;
					p.h.header.type = CMD_LINE_COMMAND;
					p.h.header.size = sizeof(int);
					*( (int*)p.u.data ) = 156;		
					QueuePacket( &p, 1 );

					break;
				}
			case 157: //auto
				g_autoStrikeBack = true;
				break;
			case 158: //autooff
				g_autoStrikeBack = false;
				break;	

			//case 159: //expegg
			//	{
			//		t_packet p;
			//		p.h.header.type = CMD_LINE_COMMAND;
			//		p.h.header.size = sizeof(int);
			//		*( (int*)p.u.data ) = 159;		
			//		QueuePacket( &p, 1 );

			//	break;
			//	}

			case 160: //onlinetime
				{
					t_packet p;
					p.h.header.type = CMD_LINE_COMMAND;
					p.h.header.size = sizeof(int);
					*( (int*)p.u.data ) = 160;		
					QueuePacket( &p, 1 );

				break;
				}

			case 161:		//查看会员卡到期
			case 162:		//查看积分卡到期
			case 163:		//查看积分倍数
				{
					t_packet p;
					p.h.header.type = CMD_LINE_COMMAND;
					p.h.header.size = sizeof(int);
					*( (int*)p.u.data ) = lc->command;		
					QueuePacket( &p, 1 );

				}
				break;


			case 164://help
				{
					char type = 2;
					::CallServer( CMD_PLEASE_GIVE_LIFE, (char *)&type, sizeof( char ) );
				}
				break;


			case 165://bbsMap
			case 166://bbsNation
#ifdef _DEBUG
			case 167://bbsAll
#endif
				{
					sscanf( t, "%s", g_bbs );		

					t_packet p;
					p.h.header.type = CMD_LINE_COMMAND;
					p.h.header.size = sizeof(int);
					*( (int*)p.u.data ) = lc->command;		
					QueuePacket( &p, 1 );
				}
				break;

			case 168:		//allianceCreate
				{
					char supperGuildName[128] = {0,};
					sscanf( t, "%s", supperGuildName );	

					if( strlen(supperGuildName) > 0 )
						SendRegistAllianceImsi(supperGuildName, "");
					else
						AddCurrentStatusMessage( 255, 0, 0, lan->OutputMessage( 3, 305 )  );
				}
				break;

			case 169:
				{
					SendAllianceJoin(t1);
				}
				break;
			case 170:
				{
					SendExitAlliance();
				}
				break;

			case 172:
					if( Hero->name_status.alliance_master )
						CallServer( CMD_DELETE_ALLIANCE, NULL, 0 );
					else
						AddCurrentStatusMessage( 255, 255, 0, lan->OutputMessage( 3, 306 )  );
				break;
#ifdef _DEBUG
			case 173: //item
			case 174: //sendOnlineItem
				{
					int itemNo;
					int itemAttr0;
					int grade = 0, soksung1 = 0, soksung2 = 0, soksung3 = 0, iHighLevel = 0, IsDynamicRare = 0;

					char targetName[20] = {0,};

					t_packet p;


					p.h.header.type = CMD_GIVE_ITEM;
					p.h.header.size = sizeof(t_send_item);

					
					
					if( lc->command == 173 )
					{
						sscanf( t, "%d,%d,%d,%d,%d,%d,%d,%d", &itemNo, &itemAttr0, &grade, &soksung1, &soksung2, &soksung3, &iHighLevel, &IsDynamicRare );		
						strcpy( targetName, "HERO");
						p.u.send_item.type = 0;
					}
					else
					{
						sscanf( t, "%s %d,%d,%d,%d,%d,%d,%d,%d",targetName, &itemNo, &itemAttr0, &grade, &soksung1, &soksung2, &soksung3, &iHighLevel, &IsDynamicRare );		
						p.u.send_item.type = 1;
					}
			

					ITEMATTR* pItem = ( (ITEMATTR*)(&p.u.send_item.item) );

					memset( pItem, 0, sizeof(ITEMATTR) );

					strcpy( p.u.send_item.targetName, targetName );
					pItem->item_no = itemNo;

					pItem->attr[0] = itemAttr0;

					( ( RareMain *)&pItem->attr[IATTR_RARE_MAIN] )->grade = grade;
					( ( RareMain *)&pItem->attr[IATTR_RARE_MAIN] )->soksung1 = soksung1;
					( ( RareMain *)&pItem->attr[IATTR_RARE_MAIN] )->soksung2 = soksung2;
					( ( RareMain *)&pItem->attr[IATTR_RARE_MAIN] )->soksung3 = soksung3;
					( ( RareMain *)&pItem->attr[IATTR_RARE_MAIN] )->iHighLevel = iHighLevel;
					( ( RareMain *)&pItem->attr[IATTR_RARE_MAIN] )->IsDynamicRare = IsDynamicRare;



					QueuePacket( &p, 1 );
				
				}
				break;

			case 175://senditem name
				{
					t_send_item sendItem;
					int grade = 0, soksung1 = 0, soksung2 = 0, soksung3 = 0, iHighLevel = 0, IsDynamicRare = 0;
					ITEMATTR* pItem = &(sendItem.item);

					RareMain* pRareMain = (RareMain*)&pItem->attr[IATTR_RARE_MAIN];
					
					sscanf(t, "%s %d,%d,%d,%d,%d,%d,%d,%d", sendItem.targetName, &(pItem->item_no), &(pItem->attr[0]), &grade, &soksung1, &soksung2, &soksung3, &iHighLevel,&IsDynamicRare);
					
					pRareMain->grade = grade;
					pRareMain->soksung1 = soksung1;
					pRareMain->soksung2 = soksung2;
					pRareMain->soksung3 = soksung3;
					pRareMain->iHighLevel = iHighLevel;
					pRareMain->IsDynamicRare = IsDynamicRare;

					sendItem.type = 1;
					SendDirectDB(CMD_CHECK_CHAR_ONLINE, &sendItem, sizeof(t_send_item)  );
					
				}
				break;
			case 176://sendDialog
				{
					g_hSendDialog = CreateDialog( g_hInstance, MAKEINTRESOURCE( IDD_SEND_ITEM ), g_hwndMain, (DLGPROC)SendItemDialogProc );
					ShowWindow( g_hSendDialog, SW_SHOW );
				}
				break;

			case 177://item2 no,ittr1,ittr2
				{
					int itemNo;
					int itemAttr0;
					int itemAttr1;		//time

					char targetName[20] = {0,};

					t_packet p;


					p.h.header.type = CMD_GIVE_ITEM;
					p.h.header.size = sizeof(t_send_item);

					
					sscanf( t, "%d,%d,%d", &itemNo, &itemAttr0, &itemAttr1 );		
					
					strcpy( targetName, "HERO");
					p.u.send_item.type = 3;

					ITEMATTR* pItem = ( (ITEMATTR*)(&p.u.send_item.item) );

					memset( pItem, 0, sizeof(ITEMATTR) );

					strcpy( p.u.send_item.targetName, targetName );
					pItem->item_no = itemNo;

					pItem->attr[IATTR_DURATION] = itemAttr0;
					//pItem->attr[IATTR_RESERVED1] = itemAttr1;

					QueuePacket( &p, 1 );
				
				}
				break;
#endif
			case 178:	//duelOff
			{
				t_packet p;
				p.h.header.type = CMD_LINE_COMMAND;
				p.h.header.size = sizeof(int);
				*((int*)p.u.data) = lc->command;
				QueuePacket(&p, 1);

				AddCurrentStatusMessage(255, 255, 255, lan->OutputMessage( 3, 307 )  );
				SMenu[MN_SYSTEM_OPTION].nField[23].nType = FT_NO_CHECK; 
				break;
			}
			case 179:	//duelOn
				{
					t_packet p;
					p.h.header.type = CMD_LINE_COMMAND;
					p.h.header.size = sizeof(int);
					*( (int*)p.u.data ) = lc->command;		
					QueuePacket( &p, 1 );

					AddCurrentStatusMessage(255, 255, 255, lan->OutputMessage( 3, 308 ) );
					SMenu[MN_SYSTEM_OPTION].nField[23].nType = FT_NOMAL_PUT; 
				break;
				}

			case 180://ShowLocalWarMenu
				g_bShowLocalWarMenu = true;
				WritePrivateProfileString("Option", "ShowLocalWarMenu", "1", g_szConfigFile);
				AddCurrentStatusMessage(255, 255, 0, lan->OutputMessage( 3, 309 )  );
				SMenu[MN_SYSTEM_OPTION].nField[25].nType = FT_NOMAL_PUT; 
				break;

			case 181://HideLocalWarMenu
				g_bShowLocalWarMenu = false;
				WritePrivateProfileString("Option", "ShowLocalWarMenu", "0", g_szConfigFile);
				AddCurrentStatusMessage(255, 255, 0, lan->OutputMessage( 3, 310 )  );
				SMenu[MN_SYSTEM_OPTION].nField[25].nType = FT_NO_CHECK; 
				break;

			case 182:
				g_bScrollScreen = false;
				WritePrivateProfileString("Option", "LockView", "0", g_szConfigFile);
				SMenu[MN_SYSTEM_OPTION].nField[27].nType = FT_NO_CHECK; 
				break;
			case 183:
				g_bScrollScreen = true;
				WritePrivateProfileString("Option", "LockView", "1", g_szConfigFile);
				SMenu[MN_SYSTEM_OPTION].nField[27].nType = FT_NOMAL_PUT; 

				//SetHeroPosition(0);
				break;
#ifdef _DEBUG
			case 184: //moveTo name			CMD_GET_PLAYER_POS
				{
				
					t_packet p;
					p.h.header.type = CMD_MOVE_TO;
					p.h.header.size = sizeof(k_name2);
					sscanf( t, "%s", p.u.kein.name2.name1 );	
					strncpy( p.u.kein.name2.name2, Hero->name, 20 );	
					QueuePacket( &p, 1 );
					break;
				}


				case 185:	//hideSelf
				case 186:	//showSelf
					{
						t_packet p;
						p.h.header.type = CMD_LINE_COMMAND;
						p.h.header.size = sizeof(int);
						*( (int*)p.u.data ) = lc->command;		
						QueuePacket( &p, 1 );
						break;
					}

				case 187://freeze
					{
						char name[20] = {0,};
						strncpy( name, t, 20 );
						//sscanf( t, "%d,%d", &x, &y );
						SendDirectDB(CMD_FREEZE, name, 20);
						break;
					}
				case 188://unfreeze
					{
						char name[20] = {0,};
						strncpy( name, t, 20 );
						//sscanf( t, "%d,%d", &x, &y );
						SendDirectDB(CMD_UNFREEZE, name, 20);
						break;
					}

				case 189://freezeDisk name
					{
						t_packet p;

						sscanf( t, "%s", p.u.kein.default_name );	
				
						p.h.header.type = CMD_VOLUME_SERIAL;
						p.h.header.size = sizeof(p.u.kein.default_name );

						QueuePacket( &p, 1 );	
						break;
					}

#endif

				case 190:
					{
						t_packet p;
						p.h.header.type = CMD_LINE_COMMAND;
						p.h.header.size = sizeof(int);
						*( (int*)p.u.data ) = lc->command;		
						QueuePacket( &p, 1 );
						break;
					}

			case LC_GO_STOP:
				{
					Lc_AutoMovementCmd = 0;
					break;
				}
			case LC_GO_WEST:
			case LC_GO_NORTH:
			case LC_GO_SOUTH:
			case LC_GO_EAST:		
			case LC_GO_RANDOM:
				{
					Lc_AutoMovementCmd = lc->command;
				
					switch( Lc_AutoMovementCmd )
					{	
					case LC_GO_EAST:
						{
							SendMessage(g_hwndMain, WM_LBUTTONDOWN, 0, MAKELONG(Hero->x - Mapx + 100, Hero->y - Mapy));
							break;
						}
					case LC_GO_WEST:
						{
							SendMessage(g_hwndMain, WM_LBUTTONDOWN, 0, MAKELONG(Hero->x - Mapx - 100, Hero->y - Mapy));
							break;
						}
					case LC_GO_NORTH:
						{
							SendMessage(g_hwndMain, WM_LBUTTONDOWN, 0, MAKELONG(Hero->x - Mapx, Hero->y - Mapy  - 100));
							break;
						}
					case LC_GO_SOUTH:
						{
							SendMessage( g_hwndMain, WM_LBUTTONDOWN, 0, MAKELONG( Hero->x - Mapx, Hero->y - Mapy  + 100) );
							break;
						}
					}

					break;
				}
			case LC_EAT_ITEM:
			case LC_NOT_GO:
				{
					break;
				}
			case LC_CHAT_WHISPER:
				{
					SendWisperByLineCommand(t);
					break;
				}
			case LC_CHAT_PARTY:
				{
					SendPartyChatByLineCommand(t);//020701 lsw
					break;
				}
			case LC_CHAT_GUILD:
				{
					SendChatSet(CHATTYPE_GUILD, NULL);
					break;
				}
			case LC_TOTAL_MAP_CONNECTIONS:
				{
					SendTotalMapConnections();
					break;
				}
			case LC_TOTAL_CONNECTIONS:
				{
					SendTotalConnections();
					break;
				}
			case LC_MAKE_PARTY:
				{
					LC_SendInputParty(t1);
					break;
				}
			case LC_DEFAULT_RUN:
				{
					Lc_DefaultMoveType = 1;
					Kein_PutMessage(KM_INFO, kein_GetMenuString(39));
					break;
				}
			case LC_DEFAULT_WALK:
				{
					Lc_DefaultMoveType = 0;
					Kein_PutMessage(KM_INFO, kein_GetMenuString(40));
					break;
				}
			case LC_TAME_STOP:
				{
					SendTameCommand(LC_TAME_STOP, t1);
					break;
				}
			case LC_TAME_ATTACK:
				{
					SendTameCommand(LC_TAME_ATTACK, t1);
					break;
				}
			case LC_TAME_FOLLOWME:
				{
					SendTameCommand(LC_TAME_FOLLOWME, t1);
					break;
				}
			case LC_TAME_NAME:
				{
					SendTameCommand( LC_TAME_NAME, t1 );	
					break;
				}
			case LC_OPEN_TIMEMENU:
				{
					g_bTimeMenuOn = true;
					break;
				}
			case LC_CLOSE_TIMEMENU:
				{
					g_bTimeMenuOn = false;
					break;
				}
			case LC_CLOSE_ALL:
				{
					g_bTimeMenuOn = false; g_ExplainMenuOn = false;
					CloseAllMenu();
					break;
				}
			case LC_EXPLAIN_OPEN:
				{
					g_ExplainMenuOn = true;
					break;
				}
			case LC_EXPLAIN_CLOSE:
				{
					g_ExplainMenuOn = false;
					break;
				}
			case LC_EAR_MESSAGE_REFUSE: 
				{
					ChatMgr.SetRefuseWhiper(t1);//021025 lsw
					break;
				}
			case LC_EAR_MESSAGE_OK: 
				{
					ChatMgr.SetAcceptWhiper(t1);//021025 lsw
					break;
				}
			case LC_EAR_MESSAGE_REFUSE_WHO:
				{
					ChatMgr.DisplayRefuseList();
					break;
				}
			case LC_REQ_MAN_TO_MAN:	
				{
					SendReqManToMan(t1); 
					break;		// 0810 YGI
				}
			case LC_GREETING:
				{
					strcpy(GreetingStr, t1);
					AddCurrentStatusMessage(FONT_COLOR_SOLID_GREEN, lan->OutputMessage(3,49), GreetingStr);//010215 lsw
					AddCurrentStatusMessage(FONT_COLOR_SOLID_GREEN, lan->OutputMessage(3,48));//010215 lsw
					break;
				}
			case LC_RESET_MAGIC_ARRAY:
				{
					if (SCharacterData.nCharacterData[SPELL] == PRIEST_SPELL)
					{
						MagicSetting2(); // 원래~ 프리스트 경우...
					}

					break;
				}
			case LC_MSG_ALL_NATION:
				{
					SendAllMsgNation(t1);
					break;
				}
			case LC_GUILD_EXIT:
				{
					SendGuildExit(t1);
					break;
				}
			case LC_GUILD_JOIN:
				{
					SendGuildJoin(t1);
					break;
				}
			case LC_GUILD_ALL_MSG:
				{
					SendGuildAllMsg(t1);
					break;
				}
			case LC_GUILD_CHANGE_EACH_LEVEL:
				{
					SendGuildChangeEachLevel(t1);
					break;
				}
			case LC_GUILD_CMD_INFO:
				{
					ViewGuildCommandInfo();
					break;
				}
			case LC_CHANGE_JOB:
				{
					break;//021126 lsw 직업 바꾸기 커멘드 없음
				}
			case LC_STOP_WAR:
				{
					SendReqStopWar(t1);
					break;
				}
			case LC_EAR_COMMAND_INFO:
				{
					ViewEarCommandInfo();
					break;
				}
			case LC_SCAN_TARGET_VYSEUS:
				{
					if (!ScanTarget(N_VYSEUS))
					{
						return 0;
					}

					break;
				}
			case LC_SCAN_TARGET_ZYPERN:
				{
					if (!ScanTarget(N_ZYPERN))
					{
						return 0;
						
					}

					break;  
				}
			case LC_SCAN_TARGET_YILSE:
				{
					if (!ScanTarget(N_YILSE))
					{
						return 0;
					}

					break;		// 011217 LTS
				}
				// 001028 KHS
			case LC_KILL_CHARACTER:
				{
					if( Hero->IsCounselor() )
					{
						LPCHARACTER ch;
						t_packet p;
						
						if (g_GameInfo.lpvSelectedSprite)
						{
							if ((LPCHARACTER)g_GameInfo.lpvSelectedSprite != Hero)
							{
								ch = (LPCHARACTER)g_GameInfo.lpvSelectedSprite; 
								
								if (ch->sprno < 2)
								{
									p.h.header.type = CMD_MAKE_GHOST;
									p.u.make_ghost.id = ch->id;
									p.h.header.size = sizeof( t_make_ghost );
									QueuePacket( &p, 1 );
								}
							}
						}
					}

					break;
				}
			case LC_DIRECTIONS:
				{
					break;
					t_packet p;
					p.h.header.type = CMD_FACE_DIRECTIONS;
					p.h.header.size = sizeof(t_face_directions);
					p.u.face_directions.dir = atoi(t1);
					p.u.face_directions.id  = Hero->id;
					QueuePacket(&p , 1);
					Hero->todir = (DIRECTION)atoi(t1);
					break;
				}
				//020515 lsw
			case LC_OPEN_DISPLAY_SKILL_EXP://	OpenDisplaySkillExp(); break;
			case LC_OPEN_DISPLAY_TAC_EXP://	OpenDisplayTacExp(); break;
			case LC_CLOSE_DISPLAY_SKILL_EXP://	CloseDisplaySkillExp(); break;
			case LC_CLOSE_DISPLAY_TAC_EXP://	CloseDisplayTacExp(); break;
				{
					break;
				}
				// 001129 KHS
			case LC_LIGHTOFRESCUE:
				{
					gr.GuideGhost_TypeTheHelp(true);
					break;
				}
			case LC_AUTOLEVELUP_CLOSE:
				{
					if (SCharacterData.nLevel <= 30)	// 010815 YGI
					{
						AddCurrentStatusMessage(FONT_COLOR_SOLID_GREEN, lan->OutputMessage(3,19));//010215 lsw
					}

					AutoLevelUpOn = false; 
					break;
				}
			case LC_AUTOLEVELUP_OPEN:
				{
					if (SCharacterData.nLevel <= 30)	// 010815 YGI
					{
						AddCurrentStatusMessage(FONT_COLOR_SOLID_GREEN, lan->OutputMessage(3,20));//010215 lsw
					}
					
					AutoLevelUpOn = true; 
					break;
				}
			case LC_ANNONCE_ON:	//if ( pMusic->OpenFile( "./sound/start.mp3" ) )	pMusic->Play();
				{
					break;	
				}
			case LC_ANNONCE_OFF:
				{
					pMusic->Stop();
					break;
				}
			case LC_FIGHTMAP_ALL_CHAT:
				{
					SendChatDataGlobalFightMap(t1);
					break;
				}
			case LC_SMALL_TIPS:
				{
					CallViewSmallTips(t1);
					break;
				}
			case LC_EMOTION:
				{
					SendLcEmotion(t1);
					break;
				}
			case LC_EXIT_GUILD:
				{
					SendExitGuild();
					break;
				}
			case LC_VIEW_NK:
				{
					ViewNk(t1);
					break;
				}
			case LC_SQUAD_CHAT:
			case LC_SQUAD_LEADER:	
			case LC_SQUAD:	
			case LC_SQUAD_MEMBER:
			case LC_SQUAD_MEMBER_TO_MEMBER:
				{
					SendSquadChatMessage(lc->command,t1);	// Nation.cpp
					break;
				}
			case LC_WAR_MENU_OPEN:
				{
					WarControl(t1);	// 011020 LTS
					break;
				}
			case LC_WAR_MENU_NOTICE_OPEN:
				{
					WarLoopTime(t1);						// 011025 LTS
					break;
				}
			case LC_GUILD_MAIL:
				{
					break;//
				}
			case LC_GUILD_CHAT:
				{
					SendChatGuild(t1);
					break;
				}
			case LC_COMMANDER_INFO:
				{
					ShowCommanderInfo();
					break;				// 010924 LTS
				}
			case LC_SQUAD_INFO:
				{
					ShowSquadInfo();
					break;
				}
			case LC_GUILD_CHAT_ON:
				{
					g_Menu_Variable.m_bGuildChatOn = true;
					break;
				}
			case LC_GUILD_CHAT_OFF:
				{
					g_Menu_Variable.m_bGuildChatOn = false;
					break;
				}
			case LC_RESET_ABILITY:	
				{	// 020925 YGI
				#ifdef _NO_COMMAND_RESET_ABILITY
					break;
				#endif
					int iAble = 1;

					for (int i = 0; i < 8; i++)
					{
						if (EquipItemAttr[i].item_no)
						{	
							iAble = 0;
						}
					}

					if (iAble)
					{
						CallSmallMenu(MN_ABILITY_REDISTRIBUTION);
					}
					else
					{
						AddCurrentStatusMessage(FONT_COLOR_RED, lan->OutputMessage(0,500));//020701 lsw
					}

					break;	// LTS LOCALWAR
				}
			case LC_WAR_GIVE_LIFE:
				{
					WarGiveLife();
					break;					// 011015 LTS
				}
			case LC_PARTY_ALL_FREE:	
				{
					memset(SCharacterData.party, 0, sizeof(CharacterParty)*6);
					CallServer(CMD_PARTY_ALL_FREE);
					break;
				}
			case LC_SEND_MAIL:
			case LC_SEND_GUILD_MAIL:
				{
					::Call_MAIL_WRITE_MENU(t1);
					break;
				}
			case LC_SHOW_ME_DUAL:
				{
					CheckShowMeDual();
					break;
				}
			case LC_REPORTER_MODE:	
				{
					if (Hero->name_status.reporter)
					{
						if (!Hero->reporter_mode && IsDead(Hero))
						{
							break;
						}

						CallServer(CMD_REPORTER_MODE);
						//Hero->reporter_mode = !Hero->reporter_mode;
					} 
					else
					{
						Kein_PutMessage(KM_FAIL, kein_GetMenuString(97));
					}

					break;
				}
			case LC_FRIEND_MENU:
				{
					CallFriendMenu();
					break; //CallGuildMemberListMenu(); break;
				}
			case LC_WAR_GIVE_LIFE2:
				{
					WarGiveLife2(t1);
					break;			// 011213 LTS
				}
			case LC_GETCOLOSSUS_INFO:
				{
					CallServer(CMD_CHECK_COLOSSUS_MAP);
					Kein_PutMessage(KM_INFO , kein_GetMenuString(152));
					break;
				}
			case LC_INVITE_COLOSSUS:
				{	//< CSD-030521
					if (!g_pArenaManager->IsLeader(Hero->id)) // 리더가 아니라면
					{
						Kein_PutMessage(KM_FAIL, kein_GetMenuString(153));
					}
					else
					{	
						static DWORD time = g_curr_time - 20;

						DWORD gab = g_curr_time-time;

						if (gab < 10)
						{
							MP3(SN_WARNING);
							Kein_PutMessage(KM_FAIL, kein_GetMenuString(156), 10 - gab);
						}
						else
						{
							time = g_curr_time;
							CallServer(CMD_INVITE_COLOSSUS);
						}
					}
					
					break;
				}	//> CSD-030521
			case LC_JOIN_COLOSSUS: 
				{
					SendJoinColossusMap();
					break;
				}
			case LC_PK_ON_OFF:
				{
					CallServer(CMD_GET_PK_ON_OFF);
					break;	
				}
			case LC_COMBAT_SKILL_ON_OFF://020420 lsw
				{
					g_mgrBattle.SendCombatRequest(Hero);
					break;
				}
			case LC_LOCALWAR_CHAT:		// LTS NEW LOCALWAR
				{
					SendLocalWarChat(t1);		// LTS NEW LOCALWAR	
					break;
				}
			case LC_QUESTMODE: 
				{
					CharUpper(t1);
					SendCMD_SET_QUESTMODE(t1); 
					break;	// LTS DRAGON MODIFY
				}
			case LC_WEATHER_ON:
				{	//< CSD-CN-031222
					g_bOffWeatherSystem = false;
					break;
				}	//> CSD-CN-031222
			case LC_WEATHER_OFF:
				{	//< CSD-CN-031222
					g_bOffWeatherSystem = true;
					break;
				}	//> CSD-CN-031222
			case LC_COMBAT_RESET:
				{	//< CSD-030306
				#ifdef _DEBUG
					CallServer(CMD_COMBAT_RESET);
				#endif
					break;
				}	//> CSD-030306
			case LC_MAGIC_DISPLAY_ON:
				{	//< CSD-030306
					g_mgrBattle.SetDisplay(true);
					g_ParticleManager.SetDisplay(true);
					SMenu[MN_SYSTEM_OPTION].nField[29].nType = FT_NOMAL_PUT;
					break;
				}	//> CSD-030306
			case LC_MAGIC_DISPLAY_OFF:
				{	//< CSD-030306
					g_mgrBattle.SetDisplay(false);
					g_ParticleManager.SetDisplay(false);
					SMenu[MN_SYSTEM_OPTION].nField[29].nType = FT_NO_CHECK;
					break;
				}	//> CSD-030306
			case LC_SET_NORMAL_CHAT_MODE://020620 lsw
				{
					SetChatTarget(CHAT_TARGET_NORMAL);
					SendChatNormal(t1);		
					break;
				}
			case LC_REPRINT_EAR_MESSAGE	:	
				{
					ChatMgr.DisplayPastData(CHATTYPE_WHISPER);		//020704 lsw
					break;
				}
			case LC_REPRINT_NORMAL_CHAT:
				{
					ChatMgr.DisplayPastData(CHATTYPE_NORMAL);		//020704 lsw
					break;
				}
			case LC_REPRINT_GUILD_CHAT:
				{
					ChatMgr.DisplayPastData(CHATTYPE_GUILD);		//020704 lsw
					break;
				}
			case LC_REPRINT_GUILD_BBS:
				{
					ChatMgr.DisplayPastData(CHATTYPE_GUILD_BBS);		//020704 lsw
					break;
				}
			case LC_TRADE://020808 YGI
				{
					TradeONOFF(t1);
					break;
				}
			case LC_CHECK_DUAL_FAME:	  // LTS DUAL FAME
				{
					SendCheckDualFame();
					break;
				}
			case LC_WHAT_QUEST_IN_MAP:	// 021007 kyo //퀘스트정보를 본다. 
				{
					SendWhatQuestInMap(t1);
					break;
				}
			case LC_MERCHANT_BBS://021126 lsw
				{
					if (Hero->viewtype == VIEWTYPE_GHOST_) //다른 사람은 고스트 이며	(딴사람은 유령)
					{
						break;
					}

					if (IsMerchant())
					{
						::SendChatData( t1, CHATTYPE_MERCHANT_BBS);
					}

					break;
				}
			case LC_MERCHANT_EXCHANGE://021026 lsw
				{
					Auction.SendCMD_MERCHANT_EXCHANGE_LIST_REQUEST(t1,0,1,true);
					break;
				}
			case LC_EVENT_MOVE_MAP:	// 021107 YGI
				{
					SendEvnetMoveMap();
					break;
				}
				//<< 031021 kyo
			case LC_EMOTI_SMILE:					
			case LC_EMOTI_SHY:
			case LC_EMOTI_CRY:
			case LC_EMOTI_ANGER:
			case LC_EMOTI_HAPPY:
			case LC_EMOTI_LOVE:
			case LC_EMOTI_TELL:
			case LC_EMOTI_THANKS:
			case LC_EMOTI_SORRY:
			case LC_EMOTI_GOOD:
			case LC_GAME_SCISSOR:
			case LC_GAME_ROCK:
			case LC_GAME_PAPER:
			case LC_GAME_GO:
			case LC_GAME_HELP:
			case LC_GAME_PARTY:
			case LC_GAME_HEAL:
			case LC_GAME_TRANSACTION:
			case LC_GAME_BEG:
			case LC_GAME_CONGRAGULATION:
				{
					::SendSmileFace((lc->command) - LC_EMOTI_SMILE + 2); // 얼굴아이콘이 1부터 시작한다.
					break;
				}
			case LC_BBS_LIMITED_USER_ADD:
				{
					if (!ChatMgr.AddLimintedBBSName(t1))
					{	// 제한인원에 걸린다.
						::AddCurrentStatusMessage(FONT_COLOR_SOLID_YELLOW, lan->OutputMessage(0, 512));
					}
					else if (strlen(t1) > 0)
					{
						::AddCurrentStatusMessage(FONT_COLOR_SOLID_YELLOW, lan->OutputMessage(0, 510), t1);
					}

					break;
				}
			case LC_BBS_ON:
				{
					ChatMgr.SetActiveBBS(true);
					::AddCurrentStatusMessage(FONT_COLOR_SOLID_YELLOW, lan->OutputMessage(0, 513));
					//ChatMgr.ShowLimitedList(); // 031031 kyo
					break;						
				}
			case LC_BBS_OFF:
				{
					ChatMgr.SetActiveBBS(false);
					::AddCurrentStatusMessage(FONT_COLOR_SOLID_YELLOW, lan->OutputMessage(0, 514));
					break;						
				}
#ifdef _DEBUG
			case 150:	//MOVE
				{

					int x, y;
					sscanf( t, "%d,%d", &x, &y );

					t_packet packet;
					packet.h.header.type = CMD_DIRECT_MAP_MOVE;
					packet.h.header.size = sizeof(k_direct_map_move);
					packet.u.kein.direct_map_move.x = x;
					packet.u.kein.direct_map_move.y = y;

					packet.u.kein.direct_map_move.map_number = MapNumber;
					strncpy(packet.u.kein.direct_map_move.name, Hero->name, 20 );
					QueuePacket(&packet, 1);
					break;

				}
				//<< 031021 kyo
#endif

			case 151:  //MALL
				{
				//	SMenu[MN_MALL].nField[1].fCheakFlag=TRUE;
					//DoButtonCheckOfMenu( MN_MALL, 1 );
					t_packet packet;
					packet.h.header.type = CMD_UPDATE_PAYSCORE;
					strncpy( packet.u.kein.default_name, Hero->name, 20 );
					packet.h.header.size = 20;
					::QueuePacket(&packet, 1);				

					//后面这个16其实并不用，因为服务器并不检验，而是写死了，这样是为了防止FPE修改客户端，所以该值不能由客户端提供
					ReqMallMenu( MN_SHOP_BUY, 16 );
					break;
				}



			case 153: //callMenu
				//CallOkCancelMessageBox( MN_MAKECHARACTER_NAME, 0,0,lan->OutputMessage(5,61), 0 );	// 020701 YGI
				::CallDualInterFace(MT_DUAL_DIVIDE);
				break;

			case 154://goto mapName,x,y 
				{
					t_script_spellmapmove spell_mapmove;
					char  mapName[20];
					int x, y;
					sscanf( t, "%s %d %d", mapName, &x, &y );		
					spell_mapmove.cn = Hero->id;
					spell_mapmove.isSuc = 1;
					spell_mapmove.iX = x;
					spell_mapmove.iY = y;
					strcpy( spell_mapmove.szMap, mapName );
					g_cQuest.m_szSpell = "goto";
					strcpy( spell_mapmove.szSpell, "goto" );
					g_cQuest.CheckSpellWord( &spell_mapmove );
					g_cQuest.m_szSpell = "";
				break;
				}
	
			}

			return 1;
		}	

		lc = &LC[++c];
	}

	return 0;
}

void SendTotalMapConnections( void )
{
	//	t_packet p;
	//	p.h.header.type = CMD_TOTAL_MAP_CONNECTIONS;
	//	p.h.header.size = 0;
	//	QueuePacket( &p, 1 );
}

void SendTotalConnections( void )
{
	//	t_packet p;
	//	p.h.header.type = CMD_TOTAL_CONNECTIONS;
	//	p.h.header.size = 0;
	//	QueuePacket( &p, 1 );
}


void RecvTotalMapConnections( int no )
{
	AddCurrentStatusMessage( 255,255,255, lan->OutputMessage(3,53), no );//010215 lsw
}

void RecvTotalConnections( int no )
{
	AddCurrentStatusMessage( 255,170,170, lan->OutputMessage(3,54),  no );//010215 lsw
}

void LC_SendInputParty( char *name )		// 0929 YGI
{
	LPCHARACTER target = ExistHe( name );
	if( !target ) return;
	
	int i;
	for(i=0; i<6; i++ )
	{
		if( !SCharacterData.party[i].m_Name[0] ) break;
	}
	if( i == 6 ) return;
	
	SetMouseCh( target );
	SendInputParty( PARTY, i, &mouse_ch);
	memset( &mouse_ch, 0, sizeof( CharacterParty ) );
}

void SendTameCommand(int command, char* s)
{	//< CSD-031106
	char* tok = strtok(s, " ");
	
	if (tok == NULL) 
	{
		switch (command)
		{
		case LC_TAME_STOP:
			{
				AddCurrentStatusMessage(100, 100, 255, lan->OutputMessage(3, 55));
				break;
			}
		case LC_TAME_ATTACK:
			{
				AddCurrentStatusMessage(100, 100, 255, lan->OutputMessage(3, 56));
				break;
			}
		case LC_TAME_FOLLOWME:
			{
				AddCurrentStatusMessage(100, 100, 255, lan->OutputMessage(3, 57));
				break;
			}
		case LC_TAME_NAME:
			{
				AddCurrentStatusMessage(100, 100, 255, lan->OutputMessage(3, 58));
				break;
			}
		}
		
		return;
	}

	char mybaby[FILENAME_MAX];
	strcpy(mybaby, tok);
	
	tok = strtok(NULL, " \n");

	char toname[FILENAME_MAX];

	if (tok == NULL) 
	{
		toname[0] = 0;
	}
	else
	{
		strcpy(toname, tok);
	}
	
	if (toname[0] == 0)
	{
		switch (command)
		{
		/*
		case LC_TAME_ATTACK:
			{
				AddCurrentStatusMessage(100, 100, 255, lan->OutputMessage(3, 59));	
				return;
			}
		*/
		case LC_TAME_NAME:
			{
				AddCurrentStatusMessage(100, 100, 255, lan->OutputMessage(3, 60));
				return;
			}
		}
	}
	
	t_packet p;
	p.h.header.type = CMD_TAME_COMMAND;
	p.u.tame_command.cmd = command;
	mybaby[19] = 0;
	EatRearWhiteChar(mybaby);
	strcpy(p.u.tame_command.mybaby, mybaby);
	EatRearWhiteChar( toname );
	toname[19] = 0;
	strcpy(p.u.tame_command.toname, toname);
	p.h.header.size= sizeof(t_tame_command);
	QueuePacket(&p, 1);
}	//> CSD-031106

void RecvTameCommandResult( int result )
{
	switch( result )
	{
	case TAME_FAIL_CHANGE_NAME		: AddCurrentStatusMessage( 214,100,122, lan->OutputMessage(3,74));		break;//010215 lsw
	case TAME_NO_CHAR				: AddCurrentStatusMessage( 214,100,122,lan->OutputMessage(3,75) ); break;
	case TAME_NO_NAME_CHAR			: AddCurrentStatusMessage( 214,100,122, lan->OutputMessage(3,76));	break;
	case TAME_FOLLOW				: AddCurrentStatusMessage( 114,100,122, lan->OutputMessage(3,77));	break;
	case TAME_STOP					: AddCurrentStatusMessage( 114,100,122, lan->OutputMessage(3,78));	break;
	case TAME_ATTACK				: AddCurrentStatusMessage( 114,100,122, lan->OutputMessage(3,79));	break;
	case TAME_SUCCESS_CHANGE_NAME	: AddCurrentStatusMessage( 114,100,122, lan->OutputMessage(3,80));	break;//010215 lsw
	}
}

void RecvTameNameChange( t_tame_name_change *p )
{
	LPCHARACTER ch = FindCharacter( &g_CharacterList, p->id);
	if( ch == NULL ) return;
	strcpy( ch->name, p->name );
}


void RecvHostName( tame_host_name *p )
{
	LPCHARACTER ch = FindCharacter( &g_CharacterList, p->id);
	if( ch == NULL ) return;
	strcpy( ch->HostName, p->hostname );
}

//   Tamming 끝..
void RecvHostEnd(  tame_end *p )
{
	LPCHARACTER ch = FindCharacter( &g_CharacterList, p->id);
	if( ch == NULL ) return;
	
	ch->HostName[0] = 0;
}

void SendBBS( char *bbs)
{
	t_packet p;
	int len;
	
	if( bbs == NULL ) return;
	len = strlen( bbs );
	if( len == 0 ) return;
	if( len >= MAX_PATH-1 ) return;
	
	p.h.header.type = CMD_BBS;
	strcpy( p.u.server_bbs.bbs, bbs );
	p.h.header.size = sizeof( t_server_bbs ) - MAX_PATH + len;
	
	QueuePacket( &p, 1 );
}


void SendChatMap( char *bbs)
{
	t_packet p;
	int len;
	
	if( bbs == NULL ) return;
	len = strlen( bbs );
	if( len == 0 ) return;
	if( len >= MAX_PATH-1 ) return;
	
	p.h.header.type = CMD_MAP_CHAT;
	p.h.header.size = sizeof( k_guild_chat )-1024+len;
	strcpy( p.u.kein.guild_chat.name, Hero->name );
	strcpy( p.u.kein.guild_chat.msg, bbs);
	p.u.kein.guild_chat.acp = g_acp;
	
	QueuePacket( &p, 1 );
}


void SendChatNation( char *bbs)
{
	t_packet p;
	int len;
	
	if( bbs == NULL ) return;
	len = strlen( bbs );
	if( len == 0 ) return;
	if( len >= MAX_PATH-1 ) return;
	
	p.h.header.type = CMD_NATION_CHAT;
	p.h.header.size = sizeof( k_guild_chat )-1024+len;
	strcpy( p.u.kein.guild_chat.name, Hero->name );
	strcpy( p.u.kein.guild_chat.msg, bbs);
	p.u.kein.guild_chat.acp = g_acp;
	QueuePacket( &p, 1 );
}


void SendChatAll( char *bbs)
{
	t_packet p;
	int len;
	
	if( bbs == NULL ) return;
	len = strlen( bbs );
	if( len == 0 ) return;
	if( len >= MAX_PATH-1 ) return;
	
	p.h.header.type = CMD_ALL_CHAT;

	p.h.header.size = sizeof( k_guild_chat )-1024+len;
	strcpy( p.u.kein.guild_chat.name, Hero->name );
	strcpy( p.u.kein.guild_chat.msg, bbs);
	p.u.kein.guild_chat.acp = g_acp;
	
	QueuePacket( &p, 1 );
}

void SendNationAll( char *bbs)
{
	t_packet p;
	int len;
	
	if( bbs == NULL ) return;
	len = strlen( bbs );
	if( len == 0 ) return;
	if( len >= MAX_PATH-1 ) return;
	
	p.h.header.type = CMD_NATION_CHAT;
	strcpy( p.u.server_bbs.bbs, bbs );
	p.h.header.size = sizeof( t_server_bbs ) - MAX_PATH + len;
	
	QueuePacket( &p, 1 );
}


void SendBBSAll( char *bbs)
{
	t_packet p;
	int len;
	
	if( bbs == NULL ) return;
	len = strlen( bbs );
	if( len == 0 ) return;
	if( len >= MAX_MSG-1 ) return;
	
	p.h.header.type = CMD_SV_SEND_MESSAGE_ALL;
	strcpy( p.u.kein.default_msg, bbs );
	p.h.header.size = len;
	
	QueuePacket( &p, 1 );
}



////////////// 0810 lhs 퀘스트용  도움말 //////////////
void RecvBbs_quest( char *bbs )
{
	AddCurrentStatusMessage( 200,200,0, lan->OutputMessage(3,132) );//010215 lsw
	AddCurrentStatusMessage( 255,255,0, bbs );
}


////////////////////////////////////////////////////////////////////////////////
// CSmallTipCount member functions
CSmallTipCount	g_SmallTipCount;
int LoadSmallTipsPage()
{
	FILE *fp;
	fp = Fopen( "./data/small_tips.txt", "rt" );
	if( !fp ) return 0;
	
	char str[512];
	while( fgets( str, 512, fp ) )
	{
		if( str[0] == ':' ) break;
		char *token;
		token = strtok( str, "\t\n" );
		if( !token ) continue;
		
		int number = atoi( token );
		if( !number ) continue;
		
		token = strtok( NULL, "\t\n" );
		if( !token ) continue;
		
		while( token )
		{
			g_SmallTipCount.AddData( number, token );
			token = strtok( NULL, "\t\n" );
		}
	}
	
	fclose( fp );
	return 1;
}

int CSmallTipCount::AddData( int number, char *str )
{
	CSmallTipCount* target = this;
	
	while( target->next ) target = target->next;
	if( m_nPage == 0 )
	{
		strncpy( m_szKey, str, 49 );		// 020925 YGI
		m_szKey[49] = 0;					// 020925 YGI
		m_nPage = number;
		return 1;
	}
	else
	{
		target->next = new CSmallTipCount;
		strcpy( target->next->m_szKey, str );
		target->next->m_nPage = number;
		return 1;
	}
}

int CSmallTipCount::GetPage( char *key )
{
	if( !m_nPage ) return 0;
	
	CSmallTipCount *target = this;
	while( target )
	{
		if( strcmp( target->m_szKey, key ) == 0 ) return target->m_nPage;
		target = target->next;
	}
	return 0;
}

////////////////////////////////////////////////////////////////////////////////
void CallViewSmallTips( char *txt )
{
	if( IsDead( Hero ) ) return;
	char *token = strtok( txt, " \t\n" );
	if( !token ) token = txt;
	else
	{
		token = strtok( NULL, " \t\n" );
		if( !token ) token = txt;
	}
	static bool first = true;
	if( first ) 
	{
		LoadSmallTipsPage();
		first = false;
	}
	
	int t = 0;
	if( *token )
		t = g_SmallTipCount.GetPage( EatRearWhiteChar( token ) );
	
	CloseAllMenu();
	SMenu[MN_SMALL_TIPS].key = t;
	bSmallTips = true;
}

CTextCmd *g_lpTextCmd;
CEmotionCmd *g_lpEmotionCmd;
void SendLcEmotion( char *txt )
{
	return;
}

///////////////////////////////////////////////////////////////
// CTextCmd member fuction
void CTextCmd::AddText(char *txt)
{
	if( !m_txt )
	{
		m_txt = new char[strlen(txt)+1];
		strcpy( m_txt, txt );
		return;
	}
	
	CTextCmd *temp;
	for( temp=this; temp->next; temp=temp->next ) ;
	
	CTextCmd *data;
	data = new CTextCmd;
	data->m_txt = new char[strlen(txt)+1];
	strcpy( data->m_txt, txt );
	temp->next = data;
	return;
}
char *CTextCmd::GetLastText()
{
	CTextCmd *temp;
	for(  temp=this; temp->next; temp=temp->next ) ;
	return temp->m_txt;
}
char *CTextCmd::GetFirstText()
{
	return m_txt;
}

///////////////////////////////////////////////////////////////
// CEmotionCmd member function
void CEmotionCmd::AddCmd( char *cmd )
{
	if( !m_Cmd )
	{
		m_Cmd = new char[strlen(cmd)+1];
		strcpy( m_Cmd, cmd );
		return;
	}
	
	CEmotionCmd *temp;
	for(temp =this; temp->next; temp=temp->next ) ;
	
	CEmotionCmd *data;
	data = new CEmotionCmd;
	data->m_Cmd = new char[strlen(cmd)+1];
	strcpy( data->m_Cmd, cmd );
	temp->next = data;
	return;
}

int CEmotionCmd::GetCmd( char *txt )
{
	CEmotionCmd *temp = this;
	int count = 0;
	while( temp )
	{
		if( strcmp( temp->m_Cmd, txt ) == 0 )
			return count;
		count ++;
		temp = temp->next;
	}
	return -1;
}
///////////////////////////////////////////////////////////////
int LoadEmotionCmd( CEmotionCmd *lpEmotionCmd )
{
	FILE *fp;
	fp = Fopen( "./data/emotion.txt", "rt" );
	if( !fp ) return 0;
	
	char temp[256];
	while( fgets( temp, 256, fp ) )
	{
		if( temp[0] == ';' ) continue;
		lpEmotionCmd->AddCmd( EatRearWhiteChar(temp) );
	}
	fclose( fp );
	return 1;
}

void SendExitGuild()
{
	if (!CheckGuildCode(Hero->GetGuildCode())) 
	{	//< CSD-030324
		return;
	}	//> CSD-030324

	if( CheckGuildMaster( Hero ) ) return;		// 길마는 하지 못하게..
	CallServer( CMD_EXIT_GUILD_SELF );
}


void SendExitAlliance()
{
	if (!CheckAllianceCode(Hero->GetAllianceCode())) 
	{	//< CSD-030324
		return;
	}	//> CSD-030324

	if ( CheckGuildMaster( Hero ) == false )
	{
		//只有公会长才能退出盟
		AddCurrentStatusMessage(255,255,0,lan->OutputMessage( 3, 318 ));
		return;
	}

	CallServer( CMD_EXIT_ALLIANCE_SELF );
}

void ViewNk( char *name )
{
	EatRearWhiteChar( name );
	name = EatRearWhiteChar( name );
	LPCHARACTER target = ExistHe( name );
	if( !target ) target = Hero;
	
	Kein_PutMessage( KM_INFO, "[%s] Vysues NK:%3d", target->name, IsNK( target, N_VYSEUS ));
	Kein_PutMessage( KM_INFO, "[%s] Zypern NK:%3d", target->name, IsNK( target, N_ZYPERN ));
	Kein_PutMessage( KM_INFO, "[%s] Yilse  NK:%3d", target->name, IsNK( target, N_YILSE ));
}

extern int IsDead( LPCHARACTER ch );

void RecvGuildChatData( t_packet *p )
{
	if( IsDead( Hero ) ) return;
	
	static int first = 1;
	if( first && !g_Menu_Variable.m_bGuildChatOn )
	{
		// 길드원이 메시지를 보냈습니다. 길드 채팅 명령어를 이용하세요 /#, /길드채팅켜기, /길드채팅끄기
		Kein_PutMessage( KM_INFO, kein_GetMenuString( 70 ) );
		first = 0;
	}
	char *name = p->u.kein.guild_chat.name;
	char *msg = p->u.kein.guild_chat.msg;
	ChatMgr.AddString( name, msg, CHATTYPE_GUILD, p->u.kein.guild_chat.acp );//021001 lsw
}


void RecvAllChatData( t_packet *p )
{
	if( IsDead( Hero ) ) return;
	
	//static int first = 1;
	//if( first && !g_Menu_Variable.m_bGuildChatOn )
	//{
	//	// 길드원이 메시지를 보냈습니다. 길드 채팅 명령어를 이용하세요 /#, /길드채팅켜기, /길드채팅끄기
	//	Kein_PutMessage( KM_INFO, kein_GetMenuString( 70 ) );
	//	first = 0;
	//}
	char *name = p->u.kein.guild_chat.name;
	char *msg = p->u.kein.guild_chat.msg;
	ChatMgr.AddString( name, msg, CHATTYPE_ALL,  p->u.kein.guild_chat.acp);//021001 lsw
}

void RecvMapChatData( t_packet *p )
{
	if( IsDead( Hero ) ) return;
	
	//static int first = 1;
	//if( first && !g_Menu_Variable.m_bMapChatOn )
	//{
	//	// 길드원이 메시지를 보냈습니다. 길드 채팅 명령어를 이용하세요 /#, /길드채팅켜기, /길드채팅끄기
	//	Kein_PutMessage( KM_INFO, kein_GetMenuString( 70 ) );
	//	first = 0;
	//}
	char *name = p->u.kein.guild_chat.name;
	char *msg = p->u.kein.guild_chat.msg;
	ChatMgr.AddString( name, msg, CHATTYPE_MAP, p->u.kein.guild_chat.acp );//021001 lsw
}


void RecvNationChatData( t_packet *p )
{
	if( IsDead( Hero ) ) return;
	
	//static int first = 1;
	//if( first && !g_Menu_Variable.m_bMapChatOn )
	//{
	//	// 길드원이 메시지를 보냈습니다. 길드 채팅 명령어를 이용하세요 /#, /길드채팅켜기, /길드채팅끄기
	//	Kein_PutMessage( KM_INFO, kein_GetMenuString( 70 ) );
	//	first = 0;
	//}
	char *name = p->u.kein.guild_chat.name;
	char *msg = p->u.kein.guild_chat.msg;
	ChatMgr.AddString( name, msg, CHATTYPE_NATION, p->u.kein.guild_chat.acp );//021001 lsw
}

void CheckShowMeDual()
{
	if( EquipItemAttr[WT_NECK].item_no == 10175 )
	{
		CallServer( CMD_SHOW_ME_DUAL_CHAR );
	}
	else
	{
		CItem *item = ItemUnit( 10175 );
		if( item )
			Kein_PutMessage( KM_FAIL, kein_GetMenuString( 78 ), item->GetItemHanName() );
	}	
}
