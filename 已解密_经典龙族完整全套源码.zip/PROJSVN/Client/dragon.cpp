﻿
#include "stdafx.h"
#include <Shlwapi.h>
#pragma comment( lib, "Shlwapi.lib" )
#include <Aclapi.h>
#include <Stdio.h>
#include <Process.h>
#include <Direct.h>
#include "resource.h"
#include "dragon.h"
#include "math.h"
#include "pack.h"////////by cdd 打包处理文件////////
#include "gameproc.h"
#include "network.h"
#include "map.h"
#include "char.h"
//#include "FPS.h"
#include "object.h"

#include "Hong_Sprite.h"
#include "Hong_Light.h"
#include "Hong_Sub.h"

#include "Hangul.h"
//#include "Menudef.h"
#include "Menu.h"
#include "MenuStartSet.h"
#include "DirectSound.h"
#include "Effect.h"
#include "LineCommand.h"
#include "Tool.h"
#include "ItemTable.h"
#include "Midi.h"
#include "MouseCursor.h"
#include "SkillTool.h"
#include "Skill.h"
#include "House.h"
#include "CharDataTable.h"
#include "Item.h"
#include "SmallMenu.h"
#include "Counseler.h"
#include "NPC_Pattern.h"
#include "Music.h"
//1206 zhh
#include "CReadArgument.h"
#include "FrameMgr.h"
#include "LottoMgr.h"//soto-030501
#include "EXECryptor.h"
#include "MD5Checksum.h"
//< CSD-CN-031215
//#include "SecuritySystem.h"
//> CSD-CN-031215
#include <Dbghelp.h>
#pragma comment(lib,"Dbghelp.lib")

extern unsigned long g_cryptTable[0x500]; 
extern SMENU    SMenu[ MAX_MENU];		// startmenu.cpp
extern NPC_INFO g_infNpc[MAX_CHARACTER_SPRITE_]; // CSD-030419
extern int ListenCommand;		// network.cpp
extern void DoQuickmemoryByKeyInput(const int iInputKey,bool bIsDikCheck);
extern HRESULT ChangeCoopLevel(HWND hWnd, LPDIRECTDRAWINFO lpDirectDrawInfo );
extern void Blt16To32(LPDIRECTDRAWSURFACE7 lpSurfaceDst, LPRECT lpRectDst, LPDIRECTDRAWSURFACE7 lpSurfaceSrc, LPRECT lpRectSrc);

///////////////////////////////////////////////////////////////////////////////
// Global Variables:
BOOL				g_bQuickLogin = FALSE;
HWND				g_hwndMain;
HINSTANCE			g_hInstance;
bool				g_bWin8 = false;
bool				g_bHardwaveRender = false;
bool				g_bScrollScreen = false;
int					g_fullScreenBit = 16;
bool				g_bGmMode = false;
GAMEINFO			g_GameInfo;
	
char				g_szTitle[ MAX_LOADSTRING ];
char				g_szWindowClass[ MAX_LOADSTRING ];
char				g_szCWD[ _MAX_PATH ];
char				g_szInfoFile[ _MAX_PATH ];
char				g_szConfigFile[_MAX_PATH];

	
BOOL				g_bIsActive = FALSE;
BOOL				g_bHide = FALSE;
//////////// 0309 lkh 추가 //////////////
BOOL				g_bCommandMode = CM_COMMAND;
	
DIRECTDRAWINFO		g_DirectDrawInfo = {0,};
CHARACTERLIST		g_CharacterList;

int					g_bitsPixel;	
POINT				g_pointMouse, g_pointFuzz;
long				g_pointMouseX, g_pointMouseY;
int					g_nLButtonState, g_nRButtonState;
int					g_bHomeKey = false;
int					g_nLDButtonState, g_nRDButtonState;
int					g_nOldLButtonState, g_nOldRButtonState;
int					g_nSensitivity = 0;		// 마우스감도를 Setting한다. 
int					LButtonDownIng, RButtonDownIng;

DWORD				g_CurrentTime;			// 서버에서 알려준 현재 시간.
DWORD				g_ClientTime;			// GameProc()에서 계속적으로 Check 한다. 
DWORD				g_ServerClientTimeGap;

DWORD				g_curr_time;			//  서버에서보내주는 현재의 시간. 초단위..
DWORD				g_packet_recv_send_checktime;
LPARAM				g_mousePos = 0;
///////////////// 0311 lkh 추가 /////////////////
int					g_Operator_Function;	//운영자용 효과 구현을 위한 스위칭 변수

char IIDD[MAX_PATH]= {0,};
char PPWW[MAX_PATH]= {0,};

int CheckSumError;	
	
// ------------------- khs 0804
char			   *g_DestBackBuf, *g_OldDestBackBuf;
int					Mox, Moy;		// 마우스의 Map의 절대좌표.
int					Mapx, Mapy;		// 현재보여지는 맵의 시작절대좌표.
int					MapTx, MapTy;	// 현재보여지는 맵의 시작절대좌표.
LPCHARACTER         Hero = NULL;			// 주인공의 Point..
//------------------------------
int					QuitFlag = false;

DWORD  g_RecvBytes, g_SendBytes;

bool				MouseCursorOnOff = true;
DWORD				g_Inside;

int					NowLoading;
UINT				g_acp;
	
///////////////////////////////////////////////////////////////////////////////
// Function prototypes.
ATOM				MyRegisterClass( HINSTANCE );
BOOL				InitInstance( HINSTANCE, int );
BOOL				InitApplication( HINSTANCE, LPSTR );
void				ExitApplication( void );
void				ParseCommandLine( LPSTR );
	
void				SetCurrentWorkingDirectory( void );
char*				GetCurrentWorkingDirectory( void );
void				SetInfoFile( void );
char*				GetInfoFile( void );
char*				EatFrontWhiteChar( char* );
char*				EatRearWhiteChar( char* );
BOOL				ShowErrorMessage( char* lpszMessage );
	
BOOL				LoadGameInfo( void );
	
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
void CALLBACK TimerProc(HWND hWnd, UINT nMsg, UINT nTimerid, DWORD dwTime); // CSD-CN-031215
	
/////////////// 0128 이규훈 /////////////////	
bool  g_Volume_Off=0;
	
/////////////// 0126 이규훈 /////////////////	
short int	g_Current_Volume=100;	//현재의 사운드 볼륨(0~100사이값)
short int	g_To_Volume		=100;	//변환되어야 하는 (최종적으로) 목표 사운드 볼륨
short int	g_Change_Volume	=0;		//볼륨 수치 변환치(-+ 변화값->Fade Out/In)
	
extern void InitMoveVariablesSetting( void );
extern void		ItemRead();	
extern void PutStartLodingImg( );		// 0127 YGI
			
#include "Path.h"
		
char nOldVal[MAX_PATH];
int g_aRandom[4] = {0,};			
int recvAttackResultCount;
FILE *keyplayfp;
FILE *keykeyplayfp;
int g_randomGene = 0xa;
int g_aaVarValue[4][15] = {{0,},};
			
bool g_bIsChristmas = false;
			
///////////////////////////////////////////////////////////////////////////////
// Functions.
			
//lsw		
extern char explain_tactics[13][20];
extern char FightTeam[5][13];
extern char NationName[8][20];			// 010227 YGI
// thai2 YGI
extern char	subFarmType[20][25];
extern char	subMineType[20][25];
extern char	subHubType[20][25];

//________________________ // 010904 LTS
extern bool InitNation();
extern void CloseNation();
extern void InitHorseAniTable();		// LTS HORSERIDER
//________________________ // 010904 LTS
			
			
static int FirstCheck = 0;
static char s_szCheckCode[] = "87021595-E214-4061-8E40-98BD9AAED844"; // CSD-CN-031215

HWND g_hMultiDlg = NULL;
//CSecuritySystem g_sysSecurity; // CSD-CN-031215
UINT g_idSafeTimer = 0; // CSD-CN-031215

int C_VarValue::operator= (int i)
{
	if( m_pChar != Hero )
	{
		value = i;
		return value;

	}
	value = i << 0xb;
	
	int random = g_aRandom[m_type] = rand() % 15;
	int* pValue = &g_aaVarValue[m_type][random];
	*pValue = i << g_randomGene;
	return *pValue;

}

int C_VarValue::operator= ( C_VarValue& i )
{
	this->value = i.value;

	if( m_pChar != Hero )
	{
		return this->value;
	}

	int random = g_aRandom[m_type] = rand() % 15;
	int srcType = i.m_type;
	int srcRandom = g_aRandom[srcType];

	g_aaVarValue[m_type][random] = g_aaVarValue[srcType][srcRandom];

	return g_aaVarValue[m_type][random];
}
	
C_VarValue::operator int()
{
	if( m_pChar != Hero )
		return value;
	
	return g_aaVarValue[m_type][  g_aRandom[m_type] ] >> g_randomGene;

}


//---------------------------------------------------------------------------------------------
//  게임을	실행하기전 화일이름의 변동이라든가 자동패치로 못하고 프로그램적으로
//  처리해야 하는 것을 여기서 처리한다. 
//---------------------------------------------------------------------------------------------
void BeforeExe( LPSTR lpCmdLine ) // thai2 YGI
{	//< CSD-030324			

	int i,j;	
	int c = 0;	

	if( !FirstCheck)
	{		

		int ii;
		for( ii=0;ii<13; ii++)
		{
			char *temp = lan->OutputMessage(9,ii+451);
			if( strlen( temp ) >= 20 ) JustMsg( "1 : %d", strlen( temp ) );
			sprintf(explain_tactics[ii],"%s",lan->OutputMessage(9,ii+451));
		}
		
		for(ii=0;ii<5; ii++)
		{
			char *temp = lan->OutputMessage(9,ii+441);
			if( strlen( temp ) >= 13 ) JustMsg( "2: %d", strlen( temp ) );
			
			sprintf(FightTeam[ii],"%s",lan->OutputMessage(9,ii+441));
		}
		
		for(ii=0;ii<8; ii++)
		{
			char *temp = lan->OutputMessage(9,ii+421);
			if( strlen( temp ) >= 20 ) JustMsg( "3: %d", strlen( temp ) );
			sprintf(NationName[ii],"%s",lan->OutputMessage(9,ii+421));
		}
		// 010314 KHS
		for (ii = 0; ii < MAX_CHARACTER_SPRITE_; ++ii)
		{	//< CSD-030419
			char* temp = lan->OutputMessage(10, ii + 201);
			if (strlen(temp) >= 40) 
			{
				JustMsg("4: %d", strlen(temp));
			}
			
			sprintf(g_infNpc[ii].szName, "%s", lan->OutputMessage(10, ii + 201));
		}	//> CSD-030419
		
		for(ii=0;ii<20; ii++)
		{
			char *temp = lan->OutputMessage(4,ii+401);
			if( strlen( temp ) >= 25 ) JustMsg( "5: %d", strlen( temp ) );
			sprintf(subFarmType[ii],"%s",lan->OutputMessage(4,ii+401));
		}
		
		
		for(ii=0;ii<8; ii++)
		{
			char *temp = lan->OutputMessage(4,ii+421);
			if( strlen( temp ) >= 25 ) JustMsg( "6: %d", strlen( temp ) );
			sprintf(subMineType[ii],"%s",lan->OutputMessage(4,ii+421));
		}
		
		
		for(ii=0;ii<11; ii++)
		{
			char *temp = lan->OutputMessage(4,ii+121);
			if( strlen( temp ) >= 25 ) JustMsg( "7: %d", strlen( temp ) );
			sprintf(subHubType[ii],"%s",lan->OutputMessage(4,ii+121));
		}
		
		for(int j=0;j<MAX_LINE_COMMAND_; j++)//010216 lsw 라인 커멘드 / 뒤에 명령어들  501 번부터 시작
		{
			char *temp = lan->OutputMessage(9,j+501);
			if( strlen( temp ) >= 35 ) JustMsg( "8: %d, %d", strlen( temp ), j );
			sprintf(LC[j].reserved,"%s" ,lan->OutputMessage(9,j+501));
		}
		FirstCheck = 1;
	}

	g_pBill = new CClientBill(lpCmdLine);
	
#ifdef _DEBUG//이부분은 디버깅 용으로 어떤 인자값이 넘어 왔는지 보여줍니다. 물론 배포할때는 빼야 합니다
	g_pBill->DisplayAllCommand();
#endif

#ifdef _MAPOBJECT_DIRECTORY_CHANGE_

	_mkdir("./object/0" );
	_mkdir("./object/2" );
	_mkdir("./object/3" );
	_mkdir("./object/4" );
	_mkdir("./object/5" );
	_mkdir("./object/6" );
	_mkdir("./object/7" );

	c = ReturnFileNumber("./object/Sung_Tile_00/" );
	c += ReturnFileNumber("./object/K_Sung2/" );
	c += ReturnFileNumber("./object/Ma-In/" );
	c += ReturnFileNumber("./object/Source/" );
	c += ReturnFileNumber("./object/Ice-w01/" );
	c += ReturnFileNumber("./object/Firedun1/" );
	c += ReturnFileNumber("./object/ManDun1/" );

	if( c )
	{
		JustMsg(lan->OutputMessage(6,1)   );//010215 lsw
		JustMsg( lan->OutputMessage(6,2)  );//010215 lsw
	}

	Dir2DirCopy("./object/Sung_Tile_00/",	"./object/2/" );
	Dir2DirCopy("./object/K_Sung2/",		"./object/7/" );
	Dir2DirCopy("./object/Ma-In/",			"./object/0/" );
	Dir2DirCopy("./object/Source/",			"./object/6/" );
	Dir2DirCopy("./object/Ice-w01/",		"./object/3/" );
	Dir2DirCopy("./object/Firedun1/",		"./object/4/" );
	Dir2DirCopy("./object/ManDun1/",		"./object/5/" );

	if( c )
	{
		JustMsg( lan->OutputMessage(6,3) );//010215 lsw
	}
				
	FILE *fp = Fopen( "./object/7/0277.csp", "rb" );
	if( fp )	
	{			
		fclose(fp);			
		JustMsg( lan->OutputMessage(6,4)  );//010215 lsw
		for( i = 277 ; i <= 798 ; i ++)
		{						
			char temp[ FILENAME_MAX];
			char temp1[ FILENAME_MAX];
													
			for( j = 0 ; j < 10 ; j ++)
			{										
				if( j == 0 )
				{								
					sprintf( temp, "./object/7/%04d.csp", i );
					sprintf( temp1, "./object/7/%04d.csp", i+7000 );
				}								
				else								
				{										
					sprintf( temp, "./object/7/%04d%02d.csp", i,j );
					sprintf( temp1, "./object/7/%04d%02d.csp", i+7000,j );
				}									
				rename( temp, temp1 );
			}									
		}											
	}			
#endif
}		


BOOL LockCurrentProcess()
{
	HANDLE hProcess = ::GetCurrentProcess();
	SID_IDENTIFIER_AUTHORITY sia = SECURITY_WORLD_SID_AUTHORITY;
	PSID pSid;
	BOOL bSus = FALSE;
	bSus = ::AllocateAndInitializeSid(&sia,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,&pSid);
	if(!bSus) goto Cleanup;
	HANDLE hToken;
	bSus = ::OpenProcessToken(hProcess,TOKEN_QUERY,&hToken);
	if(!bSus) goto Cleanup;
	DWORD dwReturnLength;
	 ::GetTokenInformation(hToken,TokenUser,NULL,NULL,&dwReturnLength);
	if(dwReturnLength > 0x400) goto Cleanup;
	LPVOID TokenInformation;
	TokenInformation = ::LocalAlloc(LPTR,0x400);
	DWORD dw;
	bSus = ::GetTokenInformation(hToken,TokenUser,TokenInformation,0x400,&dw);
	if(!bSus) goto Cleanup;
	PTOKEN_USER pTokenUser = (PTOKEN_USER)TokenInformation;
	BYTE Buf[0x200];
	PACL pAcl = (PACL)&Buf;
	bSus = ::InitializeAcl(pAcl,1024,ACL_REVISION);
	if(!bSus) goto Cleanup;
	bSus = ::AddAccessDeniedAce(pAcl,ACL_REVISION,0x000000FA,pSid);
	if(!bSus) goto Cleanup;
	bSus = ::AddAccessAllowedAce(pAcl,ACL_REVISION,0x00100701,pTokenUser->User.Sid);
	if(!bSus) goto Cleanup;
	if(::SetSecurityInfo(hProcess,SE_KERNEL_OBJECT,DACL_SECURITY_INFORMATION | PROTECTED_DACL_SECURITY_INFORMATION,NULL,NULL,pAcl,NULL) == 0)
	bSus = TRUE;
Cleanup:
	if(hProcess != NULL)
	 ::CloseHandle(hProcess);
	if(pSid != NULL)
	 ::FreeSid(pSid);
return bSus;
}


inline void doMsg(unsigned int msgid) {
	CRYPT_START
	char *msg;
	switch(msgid) {
	case 1:
		{
			if(GetVersion() >= 0x80000000)
				msg = "请使用登陆器进入龙族,\n或更新Windows至NT/XP/2003。";
			else
				msg = "请使用登陆器进入龙族 !!!";
		}
		break;
	case 2:
		msg = "error 0xC0000002 !!!";
		break;
	case 3:
		msg = "error 0xC0000003 !!!";
		break;
	case 4:
		msg = "error 0xC0000004 !!!";
		break;
	case 5:
		msg = "error 0xC0000005 !!!";
		break;
	case 6:
		msg = "文件验证错误，请勿擅自修改 !!!";
		break;
	case 7:
		msg = "版本错误,请更新到最新版本 !!!";
		break;
	case 8:
		msg = "Dragon.ini读取错误，请重新下载 !!!";
		break;
	default:
		msg = "未知错误！";
		break;
	}
	MessageBox(0, msg, "vb", MB_ICONERROR + MB_OK);
	CRYPT_END
}

inline void CheckkProtect() {
  CRYPT_START
	EXCEPTION_POINTERS* pException = NULL;
	bool boInvalidkProtect = false;
	__try {
		char *filename = "sdl.dll";
		unsigned char *rightmd5sum = (unsigned char *)"\xe4\x8c\x3c\xbd\x3e\x08\xd1\x73\x53\x91\x01\xf1\x0a\x13\x49\xb4";
	

		unsigned char *md5sum = CMD5Checksum::GetMD5(filename);
		if(!md5sum) {
			boInvalidkProtect = true;
			doMsg(2);
			goto __returnandexit;
		}
 		for(int i=0; i<16; i++) {
 			if(rightmd5sum[i] != md5sum[i]) {
 				boInvalidkProtect = true;
 			}
 		}
		delete []md5sum;

		if(boInvalidkProtect) {
			doMsg(3);
			goto __returnandexit;
		}
		char *kpSingle = (char *)0x6AFD0000;
		LPVOID lpvResult = ::VirtualAlloc(kpSingle, 16, MEM_RESERVE | MEM_COMMIT, 
			PAGE_EXECUTE_READWRITE);
		if(lpvResult == NULL) {
			boInvalidkProtect = true;
			doMsg(4);
			goto __returnandexit;
		}
		memcpy(kpSingle, "MyDragonRaja", 16);

		//char singleaddr[33] = {0};
		//sprintf(singleaddr, "%d", (unsigned int)kpSingle);
		//WritePrivateProfileString("network", "core", singleaddr, "./Dragon.ini");
		HINSTANCE hInst = LoadLibrary(filename);
		if(hInst == NULL){
			boInvalidkProtect = true;
			doMsg(5);
			goto __returnandexit;
		}
		
	}
	__except(pException = GetExceptionInformation(), 0) {
		doMsg(6);
		//LoadLibrary(filename);
		boInvalidkProtect = true;
		goto __returnandexit;
		//ExitProcess(0);
	}
__returnandexit:
	if(boInvalidkProtect) {
		ExitProcess(0);
	}
	CRYPT_END
}


char* MatchStructSize( char* pFileData, DWORD fileSize, DWORD structSize )
{
	if( fileSize >= structSize )
		return pFileData;
	else
	{
		char* buffer = new char[structSize];
		memset( buffer, 0, structSize );
		memcpy( buffer, pFileData, fileSize );
		return buffer;
	}
}

extern int LoadHackingToolName();
//#ifdef _DEBUG
//int main()
//{
//	HINSTANCE hInstance = (HINSTANCE)GetModuleHandle(NULL);
//	LPSTR lpCmdLine = "";
//	int nCmdShow = SW_SHOW;
//#else
bool IsWin8()
{
	DWORD dwVersion = 0;
	DWORD dwMajorVersion = 0;
	DWORD dwMinorVersion = 0;
	DWORD dwBuild = 0;

	dwVersion = GetVersion();

	// Get the Windows version.

	dwMajorVersion = (DWORD)(LOBYTE(LOWORD(dwVersion)));
	dwMinorVersion = (DWORD)(HIBYTE(LOWORD(dwVersion)));


	if (dwMajorVersion >= 6)
	{
		if (dwMinorVersion >1 )
			return true;
	}

	return false;

}


void SavePrepareTable( char* pFileName, MPQHASHTABLE* pHashTable, int size )
{
	FILE* pFile = fopen(pFileName, "wb");
	fwrite( pHashTable, sizeof(MPQHASHTABLE), size, pFile  );
	fclose(pFile);
}

void PrepareTable( char* pFileName, MPQHASHTABLE* pHashTable, int size )
{
	FILE* pFile = fopen(pFileName, "rb");

	fread( (char*)pHashTable, sizeof(MPQHASHTABLE),  size, pFile );

	fclose(pFile);
}


static void DumpMiniDump(HANDLE hFile, PEXCEPTION_POINTERS excpInfo)
{
	if (excpInfo == NULL) 
	{
		// Generate exception to get proper context in dump
		__try
		{
			OutputDebugString("raising exception\r\n");
			RaiseException(EXCEPTION_BREAKPOINT, 0, 0, NULL);
		}
		__except (DumpMiniDump(hFile, GetExceptionInformation()),
			EXCEPTION_CONTINUE_EXECUTION)
		{
		}
	}
	else
	{
		OutputDebugString("writing minidump\r\n");
		MINIDUMP_EXCEPTION_INFORMATION eInfo;
		eInfo.ThreadId = GetCurrentThreadId();
		eInfo.ExceptionPointers = excpInfo;
		eInfo.ClientPointers = FALSE;

	
		MiniDumpWriteDump(
			GetCurrentProcess(),
			GetCurrentProcessId(),
			hFile,
			MiniDumpNormal,
			excpInfo ? &eInfo : NULL,
			NULL,
			NULL);
	}
}

HINSTANCE hProtectDll;

int APIENTRY WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow )
{
////////by cdd 打包处理文件begin////////
	::Sleep(1000);//
	cft.PackPreload("qshow.dpk");//完成
	cft.PackPreload("zshow.dpk");//完成
	cft.PackPreload("npcshow.dpk");//完成
////////by cdd 打包处理文件end////////
//#ifndef _DEBUG
//CheckkProtect();
//#endif
	MSG		msg = {0,};
#ifndef _DEBUG	// 031110 YGI
	EXCEPTION_POINTERS* pException = NULL;//020508 lsw	

	HANDLE hFile = CreateFile("md.dmp", GENERIC_READ | GENERIC_WRITE,
		0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	int code;
	__try	//020514 lsw
	{
		LockCurrentProcess();
#endif


	wsprintf(g_szConfigFile, "./drConfig.ini");
	g_acp = GetACP();


#ifndef FROM_DISK
	PrepareCryptTable();

//PrepareZip( "./Res/object.dat", g_objectHashTable, OBJECT_FILE_COUNT );
//PrepareZip( "./Res/char.dat", g_charHashTable, CHAR_FILE_COUNT );
//PrepareZip( "./Res/dat.dat", g_datHashTable, DAT_FILE_COUNT );
//PrepareZip( "./Res/map.dat", g_mapHashTable, MAP_FILE_COUNT );
//
//SavePrepareTable( "./Res/001.dat", g_objectHashTable, OBJECT_FILE_COUNT );
//SavePrepareTable("./Res/002.dat", g_charHashTable, CHAR_FILE_COUNT );
//SavePrepareTable("./Res/003.dat", g_datHashTable, DAT_FILE_COUNT );
//SavePrepareTable("./Res/004.dat", g_mapHashTable, MAP_FILE_COUNT );

	PrepareTable("./Res/001.dat", g_objectHashTable, OBJECT_FILE_COUNT );
	PrepareTable("./Res/002.dat", g_charHashTable, CHAR_FILE_COUNT );
	PrepareTable("./Res/003.dat", g_datHashTable, DAT_FILE_COUNT );
	PrepareTable("./Res/004.dat", g_mapHashTable, MAP_FILE_COUNT );
#endif

	/*HDC screenDC = GetDC(NULL);
	g_bitsPixel = GetDeviceCaps( screenDC, 0xc );
	ReleaseDC(NULL,screenDC);*/
	g_bWin8 = IsWin8();
	srand( unsigned int(time(NULL)));
	g_randomGene = ( rand() % 0x0f ) + 0xa;

	if (g_bWin8)
		g_fullScreenBit = 32;

	g_bitsPixel = GetBitsPerPixel();

	g_bQuickLogin = PathFileExists( "./quickLogin.ini" );
	if (g_bQuickLogin) {
		g_bQuickLogin = (GetPrivateProfileInt("Login", "isQuickLogin", 0, "./quickLogin.ini") == 1);
	}

	g_CrashLog.Init(OUTPUT_JUST_FILE,"ClientCrash");//모드 셋팅 기록 될 파일의 고유 이름입니다.
	g_DBGLog.Init(OUTPUT_JUST_FILE,"CustomerService");//모드 셋팅 기록 될 파일의 고유 이름입니다.
	
	CrackMgr.SetInitClock();//030319 lsw
	CrackMgr.InitCrackMgr();

	
	if(!CrackMgr.StartCrackThread())
	{
		MessageBox(NULL,"Can Not Run Program. Call to A/S Center","Init Error",NULL);
		return false;
	}
	
	if(!LoadLanguageText())
	{
		MessageBox(NULL,"Loading Language Pack Error","LanguagePack",NULL);
		return false;
	}



	if(!LoadHackingToolName()) 
	{
		g_DBGLog.Log(LOG_LV1,"Can't Load Hacking Tool Check File");
		return false;
	}

	if ( !InitApplication( hInstance, lpCmdLine ) )
	{
		g_DBGLog.Log(LOG_LV1,"Application Init Failed");
	 	return	FALSE;
	}
	if ( !InitInstance( hInstance, nCmdShow ) )
	{	
		g_DBGLog.Log(LOG_LV1,"Instance Init Failed");
	 	return	FALSE;
	}


	//< CSD-040224
//#ifndef _DEBUG
	//#if defined (KOREA_LOCALIZING_)
	//	if (!g_sysSecurity.CheckFileName("dragonraja.bin"))
	//	{
	//		ExitWindows(EWX_SHUTDOWN, 0);
	//		return FALSE;
	//	}
	//#endif
/*	
	#ifndef KOREA_LOCALIZING_
		const int nError = g_sysSecurity.Connect(g_hwndMain);
	
		if (nError != 1)
		{
			MessageBox(NULL, VA("Connect Error!\nERR.CODE.00%d!", nError), "Run Error", NULL);
			return FALSE;
		}
	
		g_idSafeTimer = SetTimer(g_hwndMain, 24, 1000, TimerProc);
		
		if (g_idSafeTimer == 0)
		{
			return FALSE;
		}
	#endif
*/
//#endif
	//> CSD-040224
	//< CSD-TEST : SafeMeme 테스트
	/*
	const int nError = g_sysSecurity.Connect(g_hwndMain);

	if (nError != 1)
	{
		MessageBox(NULL, VA("Connect Error!\nERR.CODE.00%d!", nError), "Run Error", NULL);
		return FALSE;
	}

	g_idSafeTimer = SetTimer(g_hwndMain, 24, 1000, TimerProc);
	
	if (g_idSafeTimer == 0)
	{
		return FALSE;
	}
	*/
	//> CSD-TEST
	BeforeExe(lpCmdLine);

	if ( !InitDirectDraw( g_hwndMain, &g_DirectDrawInfo ) )
	{	
		g_DBGLog.Log(LOG_LV1,"DDraw Init Failed");
	 	return	FALSE;
	}	
	if ( InitDirectInput( g_hwndMain, g_hInstance, g_bIsActive ) != DI_OK )
	{		
		g_DBGLog.Log(LOG_LV1,"DInput Init Failed");
	 	return	FALSE;
	}
	if ( !EWndMgr.InitEditWnd())//021001 lsw
	{
		g_DBGLog.Log(LOG_LV1,"EditWnd Init Failed");
		return	FALSE;
	}


	InitSpriteTransTable( g_DirectDrawInfo.lpDirectDrawSurfacePrimary );

	g_DestBackBuf = GetSurfacePointer( g_DirectDrawInfo.lpDirectDrawSurfaceBack );
	EraseScreen( &g_DirectDrawInfo, (WORD)RGB( 0xff, 0xff, 0xff ) );
	PutStartLodingImg( );


	FlipScreen( &g_DirectDrawInfo );
	
	LoadSoundList();
	RenameSoundFile();
	
	if( SysInfo.effect )
	if ( !InitSfx( g_hwndMain ) )
	{		
	 	//return	FALSE;
	}	

	LoadConditionTable();
	
	if (!LoadEffect())
	{
		MessageBox(NULL,"Loading Effect Error","Effect Data", NULL);
		return false; 
	}

	memset( n_MagicBagic, 0, sizeof(n_MagicBagic) );

	if (!LoadMagicTable2())
	{
		MessageBox(NULL,"Loading Magic Error","Magic Data", NULL);
		return false; 
	}
	////////////////////// SoundUp LKH 추가 ////////////////////////
	LoadBGESoundTable();		//배경 효과 이펙트음 테이블 읽어 오기

	LoadSmallMapBack();

	ViewTipsLoad( 0 );
	 	
	HangulOutputArea( 0, SCREEN_WIDTH-1, 0, SCREEN_HEIGHT-1 );
	LoadHangulEnglishFont( "./data/han.fnt", "./data/eng.fnt" );
	MakergbTable();		
	LoadLevelExpTable();
	LoadCursorAni();	
	LoadMouseCursor( "Cursor.Spr" );

	//010928 lsw
	LoadChatImage();

	if(!LoadItemTableData())//021111 lsw
	{
		g_DBGLog.Log(LOG_LV1,"ItemTableData Init Failed");
		return false;
	}

	if (checkbeta=='1')
	{	//< CSD-031030
		if (!g_mgrLimit.Load("./data_b5/AbilityLimit.bin"))
		{
			if (!g_mgrLimit.Load("./data/AbilityLimit.bin"))
			{
				MessageBox(NULL,"Loading LimitData Error","Limit Data", NULL);
				return false; 
			}
		}
	}	//> CSD-031030
	else
	{
		if (!g_mgrLimit.Load("./data/AbilityLimit.bin"))
		{
			MessageBox(NULL,"Loading LimitData Error","Limit Data", NULL);
			return false; 
		}
	}
	//> CSD-021015
	if (!InitNation()) 
	{
        MessageBox(NULL,"Loading NationData Error","Nation Data",NULL);
		return false; 
	}
	//________________________________________________________________ // 010904 LTS

#ifdef USE_PROFILER	// 031013 kyo
	g_ProFileMgr.Init();
	g_ProFileMgr.AddCounter("GameProc", "GameProc" );
	g_ProFileMgr.AddCounter("GameProc", "Protocol" );
	g_ProFileMgr.AddCounter("GameProc", "Input" );
#endif 

#ifndef LIGHT_VERSION_
	InitHorseAniTable();		// LTS HORSERIDER
#endif

MAIN_MENU_:
	HACCEL hAccel = LoadAccelerators(g_hInstance, MAKEINTRESOURCE(IDR_MAIN_ACCEL));

	LoadMenuData( 0 );
	LoadMenuData( 4 );
	StartMenuSetting();      //게임을 시작하기 전에 메뉴 구조체들을 초기화  GamePorc() 전에 호출MenuSetting();      //게임을 시작하기 전에 메뉴 구조체들을 초기화  GamePorc() 전에 호출
	
	PlayBackMusic( g_hwndMain, 0 );
	
	CursorNo( 1 );

	struct tm *today;
	time_t lTime;
	time( &lTime );
	today = localtime( &lTime );
	//Log( "Packet받음.txt", "%02d:%02d  %d", today->tm_min, today->tm_sec, addlen );
	if( today->tm_mon == 11 && ( today->tm_mday == 24 ||  today->tm_mday == 25  ))  
	{
		g_bIsChristmas = true;
	}

	// 0811 NPC KHS
	LoadNPCAccessTable();
	g_FrameMgr.InitTime();
	while( TRUE )
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if (!GetMessage(&msg, NULL, 0, 0 )){break;}
			
			// soto-030602 자식 대화상자에. Tab키를 먹이자.
			if(g_hMultiDlg)
			{
				if ( IsDialogMessage(g_hMultiDlg, &msg) == FALSE )
				{
					if (0 == TranslateAccelerator(g_hwndMain, hAccel, &msg))
					{
					TranslateMessage(&msg);
					DispatchMessage(&msg);
					}
				}
			}
			else
			{
				if (0 == TranslateAccelerator(g_hwndMain, hAccel, &msg))
				{
					TranslateMessage(&msg);
					DispatchMessage(&msg);
				}

			}
		}
		else
		{
#ifdef ALT_TAB_BLOCK
			if (g_DirectDrawInfo.lpDirectDraw==NULL)		// 엑티브는 되었지만 서페이스가 없다	// LTS 020725
			{
				SetFocus2(HWND_GAME_MAIN);//021001 lsw
				ShowWindow(g_hwndMain,SW_RESTORE);
				UpdateWindow(g_hwndMain);
			}
#endif
			if( g_bHide ) {
#ifdef BlackNabs
				Sleep(50);
#endif
				continue;
			}
			

			if( !StartMenuProc( &g_DirectDrawInfo ))
			{
				PostMessage(g_hwndMain, WM_CLOSE, 0, 0);
				goto END_;
			}

			if (QuitFlag == SWD_QUIT || QuitFlag == SWD_LOGON) 
			{
				goto END_;
			}
			if( SMenu[MN_MAININTERFACE].bActive == TRUE ) 
			{
				goto START_GAME_;
			}

		}
	}
	goto END_;		
					
START_GAME_:		
					
	MenuSetting();	
	SendAllReady();	
	// 팁보기 저랩은 기본으로 보이게 한다.  0818 khs
	// 010205 KHS
	if( SCharacterData.nLevel < 8 )  ViewTipToggle = 1;
					
	double		StartTime, Duration;
	StartTime = timeGetTime( );
	ListenCommand = CMD_NONE;
	while( 1 )			
	{						
		Duration = timeGetTime( ) - StartTime;	// 5초를 기다린다. 
		if ( Duration > 1000 )
		{			
			break;	
		}			
					
		if ( ProtocolProc( &connections ) < 0 )	break;
	}				
					
	InitBytesRoutine();	// 
	YouCanHeroActionProc =0; YouCanViewTipsCheck  = 0;

	CLottoMgr::Create();//soto-030501
	g_FrameMgr.InitTime();


	while( TRUE )
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE ))//PM_NOREMOVE
		{
			if (!GetMessage(&msg, NULL, 0, 0 )){break;}
			if (0 == TranslateAccelerator(g_hwndMain, hAccel, &msg))
			{
				TranslateMessage(&msg); 
				DispatchMessage(&msg);
			}

		}
		else
		{

#ifdef ALT_TAB_BLOCK
			if (g_DirectDrawInfo.lpDirectDraw==NULL)		// 엑티브는 되었지만 서페이스가 없다	// LTS 020725
			{
				SetFocus2(HWND_GAME_MAIN);//021001 lsw
				ShowWindow(g_hwndMain,SW_RESTORE);
				UpdateWindow(g_hwndMain);
			}
#endif
//			if(g_bHide) {
//#ifdef BlackNabs
//				Sleep(50);
//#endif
//				continue;
//			}

				
			if (!GameProc(&g_DirectDrawInfo))
			{
				PostMessage(g_hwndMain, WM_CLOSE, 0, 0);
				goto END_;
			}

			if (QuitFlag == SWD_QUIT || QuitFlag == SWD_LOGON) 
			{
				goto GOTO_MAIN_MENU_;			//0201 YGI
			}
		}
	}		


	goto END_;
			
GOTO_MAIN_MENU_:
	ReStartMenu( );
	pMusic->Stop();
	Release( &connections );				// Release()호출..
	FreeTOI();
	DestroyRoofHeader( &g_RoofHeader );			
	DestroyEventList();							
	FreeMapSource();							
	DestroyItemList();
	FreeCharacterSpriteDataAll( 0, MAX_CHARACTER_SPRITE_ );	
	DestroyCharacterListExceptHero();

	CLottoMgr::Destroy();//soto-030501

	goto MAIN_MENU_;

#ifndef _DEBUG	// 031110 YGI
	}
	//__except(pException = GetExceptionInformation(), 0 )//020508 lsw
	//{
	//	::DumpException( pException, "Exception Raised on WinMain()");		
	//}
	__except (code = GetExceptionCode(), DumpMiniDump(hFile, GetExceptionInformation()), EXCEPTION_EXECUTE_HANDLER) //出现了异常, 记录异常的code, 生成dump!!
	{
		printf("%x\n", code);
		char msg[512];
		wsprintf(msg, "Exception happened. Exception code is %x", code);
		MessageBox(NULL, msg, "Exception", MB_OK); //显示消息给用户
	}

	CloseHandle(hFile);
#endif
	
END_:

	FreeLibrary(hProtectDll);

	CloseNation(); // 010904 LTS	//메인메뉴에 위치하게 되면 Closenation이 계속호출된다.. 
									//g_pNation이 계속 지워진다. 
	ExitApplication(EA_NORMAL);
#ifdef HGE_RES
	hge->Release();
#endif
	return msg.wParam;
}

ATOM
MyRegisterClass( HINSTANCE hInstance )
{
	WNDCLASSEX	wcex;

	wcex.cbSize			= sizeof( WNDCLASSEX );
	wcex.style			= CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
	wcex.lpfnWndProc	= ( WNDPROC )WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon( hInstance, ( LPCTSTR )IDI_DRAGON );
	wcex.hCursor		= NULL;// LoadCursor( NULL, IDC_ARROW );
	wcex.hbrBackground	= ( HBRUSH )( COLOR_WINDOW + 1 );
	
	//acer7
	if( SysInfo.enable_menu ) 
	{
		if( SysInfo.notdead )
		{
			wcex.lpszMenuName	= ( LPCSTR )IDC_DRAGON;
		}
		else
		{
			wcex.lpszMenuName	= ( LPCSTR )IDR_GM;
		}
	}
	else 
	{
		wcex.lpszMenuName	= NULL; 
	}

	wcex.lpszClassName	= g_szWindowClass;
	wcex.hIconSm		= LoadIcon( wcex.hInstance, ( LPCTSTR )IDI_SMALL );

	return	RegisterClassEx( &wcex );
}

BOOL
InitInstance( HINSTANCE hInstance, int nCmdShow )
{
	HWND		hWnd;
	int			cx, cy;
	DWORD         nStyle = 0;

	g_hInstance = hInstance;

	cx = SCREEN_WIDTH + GetSystemMetrics(SM_CXFRAME) * 2;
	cy = SCREEN_HEIGHT + GetSystemMetrics(SM_CYFRAME)*2 + GetSystemMetrics(SM_CYCAPTION);

	RECT rectW;

	#ifndef _DEBUG
		rectW.left=(GetSystemMetrics(SM_CXSCREEN)-cx)/2;
		rectW.top=(GetSystemMetrics(SM_CYSCREEN)-cy)/2;
		rectW.right=rectW.left+800;
		rectW.bottom=rectW.top+600;
	#else
		rectW.left=0;
		rectW.top=0;
		rectW.right=SCREEN_WIDTH;
		rectW.bottom=SCREEN_HEIGHT;
	#endif

	switch( SysInfo.dx )
	{
	case 0:	nStyle = WS_POPUP | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;	break;
		//case 0 :	nStyle =0x14ca0000;	break;
		case 1 :	nStyle = WS_POPUP;		break;
	}

	//if( GetSysInfo( SI_GAME_MAKE_MODE ) == 0 )
	//	if(FindWindow("DRAGONRAJA_CLASS","DragonRaja Online")){ return FALSE; }
#ifdef _DEBUG
	if( g_bGmMode )
		AdjustWindowRect(&rectW, nStyle, true);
	else
#endif
		BOOL b = AdjustWindowRect(&rectW, nStyle, 0);


#ifdef _DEBUG
	hWnd = CreateWindow( g_szWindowClass,
						 g_szTitle,
						 nStyle,
						 0,0, rectW.right - rectW.left, rectW.bottom - rectW.top,
						
						 NULL,
						 NULL,
						 hInstance,
						 NULL );
#else
	hWnd = CreateWindow( g_szWindowClass,
		g_szTitle,
		nStyle,
		rectW.left, rectW.top, rectW.right-rectW.left, rectW.bottom-rectW.top,
		NULL,
		NULL,
		hInstance,
		NULL );
#endif
	if ( !hWnd )
	{
		return	FALSE;
	}
	
	//RECT winRect;
	//GetWindowRect(hWnd, &winRect );

	g_hwndMain = hWnd;
	
	ShowWindow( hWnd, nCmdShow );
	//UpdateWindow( hWnd );

	GetClientRect(hWnd, &g_DirectDrawInfo.rectPrimarySurface);
	ClientToScreen(hWnd, (LPPOINT)&g_DirectDrawInfo.rectPrimarySurface);
	ClientToScreen(hWnd, (LPPOINT)&g_DirectDrawInfo.rectPrimarySurface + 1);

	return	TRUE;
}	


bool FindProxyIp2( char* pHostName = 0)
{
	HOSTENT* pHostEnt0;
	//HOSTENT* pHostEnt1;	

	if( strlen(pHostName) == 0 )
	{
		pHostEnt0 =	gethostbyname(  g_GameInfo.hostName[0] );
	}
	else
		pHostEnt0 =	gethostbyname( pHostName );

	if( pHostEnt0 == 0 )
	{
		MessageBoxW( g_hwndMain, L"无法解析服务器IP", L"ERROR", MB_OK );
		return FALSE;
	}

	sprintf( g_GameInfo.proxy_ip[0], "%d.%d.%d.%d", pHostEnt0->h_addr_list[0][0] & 0x00ff,
		pHostEnt0->h_addr_list[0][1] & 0x00ff,
		pHostEnt0->h_addr_list[0][2] & 0x00ff,
		pHostEnt0->h_addr_list[0][3] & 0x00ff);

	if ( g_GameInfo.proxy_ip[0][0]== 0 )
	{
		return	FALSE;
	}

	//pHostEnt1 = gethostbyname( g_GameInfo.hostName[1]  );

	//if( pHostEnt1 == 0 )
	//{
	//	return FALSE;
	//}


	//sprintf( g_GameInfo.proxy_ip[1], "%d.%d.%d.%d", pHostEnt1->h_addr_list[0][0] & 0x00ff,
	//	pHostEnt1->h_addr_list[0][1] & 0x00ff,
	//	pHostEnt1->h_addr_list[0][2] & 0x00ff,
	//	pHostEnt1->h_addr_list[0][3] & 0x00ff);

	//if ( g_GameInfo.proxy_ip[1][0]== 0 )
	//{
	//	return	FALSE;
	//}

	return TRUE;
}

bool FindProxyIp()
{
	HOSTENT* pHostEnt0;
	HOSTENT* pHostEnt1;	
	pHostEnt0 =	gethostbyname( g_GameInfo.hostName[0] );

	if( pHostEnt0 == 0 )
	{
		return FALSE;
	}

	sprintf( g_GameInfo.proxy_ip[0], "%d.%d.%d.%d", pHostEnt0->h_addr_list[0][0] & 0x00ff,
		pHostEnt0->h_addr_list[0][1] & 0x00ff,
		pHostEnt0->h_addr_list[0][2] & 0x00ff,
		pHostEnt0->h_addr_list[0][3] & 0x00ff);

	if ( g_GameInfo.proxy_ip[0][0]== 0 )
	{
		return	FALSE;
	}

	pHostEnt1 = gethostbyname( g_GameInfo.hostName[1]  );

	 if( pHostEnt1 == 0 )
	 {
		 return FALSE;
	 }


	sprintf( g_GameInfo.proxy_ip[1], "%d.%d.%d.%d", pHostEnt1->h_addr_list[0][0] & 0x00ff,
		pHostEnt1->h_addr_list[0][1] & 0x00ff,
		pHostEnt1->h_addr_list[0][2] & 0x00ff,
		pHostEnt1->h_addr_list[0][3] & 0x00ff);

	if ( g_GameInfo.proxy_ip[1][0]== 0 )
	{
		return	FALSE;
	}

	return TRUE;
}

BOOL
InitApplication( HINSTANCE hInstance, LPSTR lpCmdLine )
{	
#ifdef _DEBUG
	ModeSetting( g_hwndMain, hInstance);
#endif
	if( SysInfo.result == 999 ) return FALSE;
	//SysInfo.music = MF_UNCHECKED;
	//SysInfo.effect = MF_UNCHECKED;	

#ifdef _DEBUG
	SysInfo.music = MF_UNCHECKED;
	SysInfo.effect = MF_UNCHECKED;
#else
	SysInfo.music = MF_CHECKED;
	SysInfo.effect = MF_CHECKED;
#endif

	MakeSizeofSOU2();	
	
	
	LoadString( hInstance, IDS_APP_TITLE, g_szTitle, MAX_LOADSTRING);
	LoadString( hInstance, IDC_DRAGONRAJA_CLASS, g_szWindowClass, MAX_LOADSTRING );
	MyRegisterClass( hInstance );
	
//	ParseCommandLine( lpCmdLine );
	srand( ::timeGetTime() );
	
	SetCurrentWorkingDirectory();
	SetInfoFile();
	
	if ( !LoadGameInfo( ) )
	{
		return	FALSE;
	}

	pMusic->Stop();

	CoInitialize( NULL );
	if ( !::Initialize() )
	{
		return	FALSE;
	}

	if( !FindProxyIp() )
		return FALSE;

	g_pointMouseX = SCREEN_WIDTH / 2;
	g_pointMouseY = SCREEN_HEIGHT / 2;
	g_nLButtonState = g_nRButtonState = g_nOldLButtonState = g_nOldRButtonState = STATE_BUTTON_RELEASED;
	g_nSensitivity = 0;
	
	return	TRUE;
}	

void ExitApplication( const eExitAppType eEAType )
{
	CrackMgr.StopCrackThread();

	SendLogOut();
	GameEndFree();

	::Release( &connections );
	
	EndLoadCharSpriteDataThread();
	DestroyCharacterList( &g_CharacterList );
	CleanupDirectDraw( &g_DirectDrawInfo );
	StopBackMusic( g_hwndMain );
	FreeSfx();
	CoUninitialize( );
	FreeAllOfMenu();		// 0927 YGI
	DeleteAllSkillData();
	pMusic->Stop();
	if(EA_NORMAL != eEAType)
	{
		g_DBGLog.Log(LOG_LV1,"ExitApplication Call(%d)",eEAType);
	}

	if( CheckSumError ) 
	{
		JustMsg( "Found corrupted or tampered files while loading. \nExiting program. [%d]", CheckSumError);
	}

	//FreeItemTable();

	delete g_pBill;
	delete lan;

	exit(0);
}
	
void ParseCommandLine( LPSTR lpCmdLine )
{	
	while ( lpCmdLine[ 0 ] == '-' || lpCmdLine[ 0 ] == '/' )
	{
		lpCmdLine++;
	
		switch ( *lpCmdLine++ )
		{
		case	'f':
		case	'F':
			g_DirectDrawInfo.bFullscreen = FALSE; // LTS TEST
			break;
		}
	
		lpCmdLine = EatFrontWhiteChar( lpCmdLine );
	}
}
void SetCurrentWorkingDirectory( void )
{	
	char*	ptr;
	
	GetModuleFileName( g_hInstance, g_szCWD, sizeof( g_szCWD ) );
	ptr = strrchr( g_szCWD, '\\' );
	*ptr = 0;
}

char*
GetCurrentWorkingDirectory( void )
{	
	return	g_szCWD;
}	

void SetInfoFile( void )
{	
	wsprintf( g_szInfoFile, "./dragon.ini" );
}	
	
char*
GetInfoFile( void )
{	
	return	g_szInfoFile;
}	
	
char*
EatFrontWhiteChar( char* pStr )
{	
	char*	szWhite = " \t\n\r";
	
    if ( pStr )
    {
		while ( *pStr )
		{
			if ( strchr( szWhite, *pStr ) )
			{
				pStr++;
			}
			else
			{
				break;
			}
		}	
    }
        
    return  pStr;    
}	
	
char*
EatRearWhiteChar( char* pStr )
{	
	char*	szWhite = " \t\n\r";
	char*	pRear;
	
	pRear = pStr + strlen( pStr ) - 1;
	if ( pRear )
	{
		while ( pStr <= pRear )
		{
			if ( strchr( szWhite, *pRear ) )
			{
				*pRear-- = 0;
			}
			else
			{
				break;
			}
		}
	}
	
	return	pStr;
}	
	
BOOL
ShowErrorMessage( char* lpszMessage )
{	
	MessageBox( g_hwndMain, lpszMessage, "Dragon Raja Online", MB_OK );
	return	FALSE;
}	
	
	
	
	

														
///////////////////////////////////////////////////////////////////////////////
// window procedure										
																
void MouseProcess( UINT message, WPARAM wParam, LPARAM lParam)
{	
	int x, y;

	switch( message )										
	{														
	case WM_LBUTTONUP     :	g_nLButtonState = STATE_BUTTON_RELEASED; LButtonDownIng= 0;	tool_MyHouseLBU( wParam, lParam ); ReleaseCapture();				break;
	case WM_LBUTTONDOWN   :	
		YouCanHeroActionProc = 1; 
		YouCanViewTipsCheck  = 1;
		g_nLButtonState = STATE_BUTTON_PRESSED; 
		LButtonDownIng= 1;	
		tool_MyHouseLBD( wParam, lParam ); 
		SetCapture( g_hwndMain);		
		break;
	case WM_RBUTTONUP	  :	g_nRButtonState = STATE_BUTTON_RELEASED; RButtonDownIng= 0;	ReleaseCapture();				break;
	case WM_RBUTTONDOWN   :	g_nRButtonState = STATE_BUTTON_PRESSED;	 RButtonDownIng= 1;	SetCapture( g_hwndMain);  		break;
	case WM_LBUTTONDBLCLK :	g_nLDButtonState = STATE_BUTTON_DOUBLECLICK;	SetCapture( g_hwndMain);		break;
	case WM_RBUTTONDBLCLK :	
		g_nRDButtonState = STATE_BUTTON_DOUBLECLICK;	
		SetCapture( g_hwndMain);		
		break;
	}												
							
	x = LOWORD( lParam );
	y = HIWORD( lParam );

	//if (Hero)
	//{
	//	char buffer[256] = { 0, };

	//	int heroX = (g_Map.file.wWidth / (float)small_map_spr[0].xl) * x;
	//	int heroY = (g_Map.file.wHeight / (float)small_map_spr[0].yl) * y;
	//	sprintf(buffer, "%d,%d", heroX, heroY);
	//	SetWindowText(g_hwndMain, buffer);

	//}

	g_mousePos = lParam;

//#ifdef _DEBUG
//	y += ::GetSystemMetrics(SM_CYMENUSIZE);
//#endif
	
	if(LButtonDownIng==1 )								
	{															
		g_DragMouse.ex=x+Mapx;	//마우스의 화면좌표에 맵의 절대 좌표를 더함
		g_DragMouse.ey=y+Mapy;	
	}


	AdjustSkillMouseCursor( &x, &y );
		
	
	// 현재 노가다 기술을 하는 중이면   마우스는 그 박스안에 있어야 한다. 
	g_pointMouseY = g_pointMouse.y = y;
	g_pointMouseX = g_pointMouse.x = x;
	Mox =  Mapx + g_pointMouseX;		Moy =  Mapy + g_pointMouseY;
	
	/*int		SkillNo;
int		SkillStatus;
Spr	   *SkillIcon;
int		SkillItemNo;			// 기술에 사용될  Item의 번호.
POS		SkillItemPOS ;			// 기술에 사용될  Item의 위치값.



bool	SkillMouseDontMoveFlag;	//	노가다를 해야 하는 기술은 한번 그곳을 선택하면   오른쪽마우스로 취소하든가 NogadaCount가 Max가 될때까지 기다려야 한다. 
DWORD	SkillRetryTime;
int		SkillDontMoveSx,SkillDontMoveSy,SkillDontMoveEx,SkillDontMoveEy;
bool	YouCanNogadaFlag;
*/

}															

//1206 zhh
//#include "Language.h" //010215 lsw 주석처리.


// 10505 KHS  //010605 lms
bool chinese_input;
void CheckChineseInput( HWND hwnd, LPARAM lParam )
{
	if( ( lParam & 0x00ff ) == 0x0004 )
	{	
		HRESULT hResult;

		chinese_input = true;

		if( g_DirectDrawInfo.lpClipper )
		{
			g_DirectDrawInfo.lpClipper->Release();	
			g_DirectDrawInfo.lpClipper = NULL;
		}

		hResult = g_DirectDrawInfo.lpDirectDraw->CreateClipper( 0, &g_DirectDrawInfo.lpClipper, NULL );
		if( hResult == DD_OK ) 
			g_DirectDrawInfo.lpClipper->SetHWnd( 0, g_hwndMain );
	}	
	else
	{	
		chinese_input = false;

		if( g_DirectDrawInfo.lpClipper )
		{
			g_DirectDrawInfo.lpClipper->Release();	
			g_DirectDrawInfo.lpClipper = NULL;
		}
	}	
}

//extern	void	kein_KeyProc_win( DWORD wParam );

														
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	//PAINTSTRUCT ps;
	//HDC	hDC;
    MINMAXINFO* pMinMax = NULL;
	
	if (EWndMgr.CheckSysKey( message, wParam ) == 0)
	{	//021001 lsw
		return 0;
	}
	
	switch (message)							
	{
	case WM_INPUTLANGCHANGE:
		{
			CheckChineseInput( hWnd, lParam );
			break;
		}
	case WM_COMMAND:
		{
			if( LOWORD(wParam) == IDM_TOGGLEFULLSCREEN )
			{
				if( g_bIsActive )
				{
					

					//if( g_DirectDrawInfo.bFullscreen == false)
					//{
					//	//GetWindowRect( g_hwndMain, &g_rcWindow );

					//	//AtlTrace( "%d,%d, %d, %d\n", g_rcWindow.left, g_rcWindow.top, 
					//	//	g_rcWindow.right - g_rcWindow.left,
					//	//	g_rcWindow.bottom - g_rcWindow.top );


					//}


					g_DirectDrawInfo.bFullscreen = !g_DirectDrawInfo.bFullscreen;

					if( g_DirectDrawInfo.bFullscreen )
						SysInfo.dx = 1;
					else
						SysInfo.dx = 0;
					ChangeCoopLevel(g_hwndMain, &g_DirectDrawInfo);
					//g_bReady = TRUE;

				}

			}
			else
				SystemMenuProcess ( wParam );	
			break;
		}
	case WM_INITMENU:
		{	//soto 030307
		#ifdef _DEBUG
			MainMenuSelected(wParam,lParam);
		#endif
			break;
		}	//soto End.
	case WM_CREATE:
		{
			SetCursor( NULL );
			SetTimer( hWnd, 13, 1000, NULL);
			break;
		}					
	case WM_TIMER:
		{
			if (wParam == 13)
			{
				g_curr_time++;
				g_packet_recv_send_checktime++;
			}

			break;
		}
	case WM_ACTIVATE:		
	case WM_ACTIVATEAPP:			
		{		
			HRESULT r;
			switch (LOWORD(wParam))
			{							
			case WA_CLICKACTIVE:
				{
					//printf( "%x-%x-%x-WA_CLICKACTIVE\n", message,hWnd, ::GetThreadId(GetCurrentThread()) );
					g_bIsActive = TRUE;
					//g_FrameMgr.InitTime();

					if (g_DirectDrawInfo.lpDirectDraw == NULL)
					{
						if (!InitDirectDraw(g_hwndMain, &g_DirectDrawInfo))
						{
							return 0;
						}
						
						EraseScreen(&g_DirectDrawInfo, RGB(0,0,0));
					}
					//else
					//{
					//	r = g_DirectDrawInfo.lpDirectDraw->TestCooperativeLevel();

					//	if (r == DDERR_EXCLUSIVEMODEALREADYSET)
					//	{
					//		//g_DirectDrawInfo.bFullscreen = !g_DirectDrawInfo.bFullscreen;

					//		//if (g_DirectDrawInfo.bFullscreen)
					//		//	SysInfo.dx = 1;
					//		//else
					//		//	SysInfo.dx = 0;
					//		ChangeCoopLevel(g_hwndMain, &g_DirectDrawInfo);

					//	}
					//}
					//
					break;
				}
			case WA_INACTIVE:
				{
					g_bIsActive = FALSE;
					//g_FrameMgr.InitTime();
					//printf( "%x-%x-%x-WA_INACTIVE\n", message, hWnd, ::GetThreadId(GetCurrentThread()) );
					HRESULT hRet;

					if( g_DirectDrawInfo.lpClipper != NULL )
					{
						g_DirectDrawInfo.lpClipper->Release();
						g_DirectDrawInfo.lpClipper  = NULL;

						if(!g_DirectDrawInfo.bFullscreen)
						{


						LPDIRECTDRAWCLIPPER pClipper;
						hRet = g_DirectDrawInfo.lpDirectDraw->CreateClipper(0, &pClipper, NULL);
						//if (hRet != DD_OK)
							//return InitFail(hWnd, hRet, "CreateClipper FAILED");

						pClipper->SetHWnd(0, hWnd);
						g_DirectDrawInfo.lpDirectDrawSurfacePrimary->SetClipper(pClipper);
						pClipper->Release();
						pClipper = NULL;


						}

					}

					break;
				}
			case WA_ACTIVE:
				{
					g_bIsActive = TRUE;
					
					
					//printf( "%x-%x-%x-WA_ACTIVE\n", message , hWnd,  ::GetThreadId(GetCurrentThread()) );
					if (g_DirectDrawInfo.lpDirectDraw == NULL)
					{
						if (!InitDirectDraw(g_hwndMain, &g_DirectDrawInfo))
						{
							return 0;
						}

						EraseScreen(&g_DirectDrawInfo, RGB(0,0,0));
						
						SetCursor(NULL);
					}
					else
					{
						 r = g_DirectDrawInfo.lpDirectDraw->TestCooperativeLevel();

						if (r != DD_OK)
						{
							//g_DirectDrawInfo.bFullscreen = !g_DirectDrawInfo.bFullscreen;

							//if (g_DirectDrawInfo.bFullscreen)
							//	SysInfo.dx = 1;
							//else
							//	SysInfo.dx = 0;
							ChangeCoopLevel(g_hwndMain, &g_DirectDrawInfo);




						}
					}

					break;
				}
			}
			
			SetAcquire(g_bIsActive);
			CheckingAccelator_Sub1();
			break;	
		}	
	case WM_SYSKEYUP:
		{
			if (wParam == VK_F10)
			{
				return TRUE;
			}
			break;
		}

	case WM_GETMINMAXINFO:
		{								
			pMinMax = (MINMAXINFO*)lParam;
			pMinMax->ptMinTrackSize.x = SCREEN_WIDTH + GetSystemMetrics(SM_CXSIZEFRAME) * 2;
			pMinMax->ptMinTrackSize.y = SCREEN_HEIGHT + GetSystemMetrics(SM_CYSIZEFRAME) * 2 + GetSystemMetrics(SM_CYMENU);
			pMinMax->ptMaxTrackSize.x = pMinMax->ptMinTrackSize.x;
			pMinMax->ptMaxTrackSize.y = pMinMax->ptMinTrackSize.y;
			break;					
		}								
	case WM_MOVE:							
	case WM_SIZE:						
		{			
			if( SIZE_MAXHIDE == wParam || SIZE_MINIMIZED == wParam )
				g_bHide = TRUE;
			else
				g_bHide = FALSE;


			if (g_bIsActive)
			{
				if (g_DirectDrawInfo.bFullscreen)
				{						
					SetRect(&g_DirectDrawInfo.rectPrimarySurface, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN));
				}									
				else									
				{								
					GetClientRect(hWnd, &g_DirectDrawInfo.rectPrimarySurface);
					ClientToScreen(hWnd, (LPPOINT)&g_DirectDrawInfo.rectPrimarySurface);
					ClientToScreen(hWnd, (LPPOINT)&g_DirectDrawInfo.rectPrimarySurface + 1);

				}									
			}

			break;										
		}													
	case WM_PAINT:								
		{	
#ifndef BlackNabs
			if (g_bIsActive)
			{
				//hDC = BeginPaint(hWnd, &ps);
				//EndPaint(hWnd, &ps);

				break;
			}
#endif

			if (!g_DirectDrawInfo.bFullscreen )
			{
				//hDC = BeginPaint(hWnd, &ps);
				//EndPaint(hWnd, &ps);
                while (TRUE)
                {
                    // If we are in windowed mode, perform a blt.
					HRESULT hRet;	
					if (g_bitsPixel == 32 && !g_bHardwaveRender )
					{
					
						RECT rect = { 0, 0, 800, 600 };
						Blt16To32(g_DirectDrawInfo.lpDirectDrawSurfaceBack2, &rect, g_DirectDrawInfo.lpDirectDrawSurfaceBack, &rect);
						hRet = g_DirectDrawInfo.lpDirectDrawSurfacePrimary->Blt(&g_DirectDrawInfo.rectPrimarySurface,
							g_DirectDrawInfo.lpDirectDrawSurfaceBack2, NULL, DDFLIP_WAIT, NULL);

					}
					else
					{
						 hRet = g_DirectDrawInfo.lpDirectDrawSurfacePrimary->Blt( &g_DirectDrawInfo.rectPrimarySurface,
							g_DirectDrawInfo.lpDirectDrawSurfaceBack, NULL, DDBLT_WAIT, NULL );
					}

                    if (hRet == DD_OK)
                        break;
                    if (hRet == DDERR_SURFACELOST)
                    {
                        hRet = g_DirectDrawInfo.lpDirectDrawSurfacePrimary->Restore();
                        if (hRet != DD_OK )
							break;
                    }
                    if (hRet != DDERR_WASSTILLDRAWING)
                        break;
                }

			}


			break;
		}
	case WM_KEYDOWN:
		{		
			DoSomeThingWithKey( wParam, lParam );		// tool.cpp
			CheckCharacterFrameOrder( wParam, lParam );	// tool.cpp
			
			switch (wParam)
			{
			case VK_RETURN:		
				{
					if (!IsChatBoxActive())		// 0601 YGI
					{
						SetChatMode(CM_MESSAGE);
					}

					break;
				}

			case VK_HOME:
				{
					g_bHomeKey = true;
					break;
				}
			case VK_END:
				{
					g_bHomeKey = false;
					break;
				}
			}

			if( wParam < 256 )
				g_aCurrentKeys_win[wParam] = 0x80;

			break;
		}
	case WM_CHAR:
		{
			switch (wParam)
			{
			case VK_RETURN:		
			case VK_TAB:		
				{
					return 0;
				}
			}

			break;
		}
	case WM_KEYUP://021008 lsw
		{
			const int nVirtKey = (int)wParam;	// virtual-key code 
			LPARAM lKeyData = lParam;			// key data
			
			switch (nVirtKey)
			{
			case VK_F1:
			case VK_F2:
			case VK_F3:
			case VK_F4:
			case VK_F5:
			case VK_F6:
			case VK_F7:
			case VK_F8:
				{
					::DoQuickmemoryByKeyInput(nVirtKey,false);
					return 0;
				}
			}

			break;
		}
	case WM_LBUTTONDOWN:
	case WM_LBUTTONUP:
	case WM_RBUTTONDOWN:
	case WM_RBUTTONUP:
	case WM_LBUTTONDBLCLK:
	case WM_RBUTTONDBLCLK:
		{		
			MouseProcess( message, wParam, lParam);
			break;	
		}	
	case WM_MOUSEMOVE:
		{
			MouseProcess( message, wParam, lParam);
			break;	
		}
	case MM_MCINOTIFY:			// MCI 통지 메시지를 받는다.
		{
			if (wParam == MCI_NOTIFY_SUCCESSFUL)    // 연주가 끝났을때.
			{
				PlayBackMusic(g_hwndMain, CurMidi);
			}
			else if (CurMidi >= 0)
			{
				PlayBackMusic(g_hwndMain, CurMidi);
			}
			
			break;
		}
	case WM_DESTROY:
		{	
			PostQuitMessage( 0 );	
			break;					 
		}								
	}		
	
	return DefWindowProc( hWnd, message, wParam, lParam );
}

void CALLBACK TimerProc(HWND hWnd, UINT nMsg, UINT nTimerid, DWORD dwTime)
{	//< CSD-CN-031215
	//if (nTimerid == g_idSafeTimer)
	//{ 	//< PowerZ-030116
	//	HWND hSafeWnd = g_sysSecurity.GetSafeWindowHandle();
	//	
	//	if (!IsWindow(hSafeWnd))
	//	{ 
	//		KillTimer(hWnd, g_idSafeTimer);
	//		PostMessage(hWnd, WM_CLOSE, 0, 0);
	//	}
	//}	//> PowerZ-030116
}	//> CSD-CN-031215

BOOL LoadGameInfo( void )
{
//#ifndef _DEBUG


	memset( g_GameInfo.hostName, 0, sizeof(g_GameInfo.hostName) );
	DWORD d = GetPrivateProfileString( "network", "host1", "", g_GameInfo.hostName[0], sizeof( g_GameInfo.hostName[0] ), g_szInfoFile );
	
	if ( g_GameInfo.hostName[0][0]== 0 )
	{
		return	FALSE;
	}
	GetPrivateProfileString( "network", "host2", "", g_GameInfo.hostName[1], sizeof( g_GameInfo.hostName[1] ), g_szInfoFile );
	if ( g_GameInfo.hostName[1][0]== 0 )
	{
		return	FALSE;
	}
//#else
	//GetPrivateProfileString( "network", "host1", "", g_GameInfo.proxy_ip[0], sizeof( g_GameInfo.proxy_ip[0] ), g_szInfoFile );
	//if ( g_GameInfo.proxy_ip[0][0]== 0 )
	//{
	//	return	FALSE;
	//}
	//GetPrivateProfileString( "network", "host2", "", g_GameInfo.proxy_ip[1], sizeof( g_GameInfo.proxy_ip[1] ), g_szInfoFile );
	//if ( g_GameInfo.proxy_ip[1][0]== 0 )
	//{
	//	return	FALSE;
	//}

//#endif
	g_GameInfo.version = GetPrivateProfileInt( "network", "ver", 0, g_szInfoFile );
	if ( g_GameInfo.version == 0 )
	{
		return	FALSE;
	}
	else
	{
//	char temp[ MAX_PATH];
//	sprintf( temp, "%d", 400 );
//	WritePrivateProfileString( "network", "ver", temp, "dragon.ini" );
	}

	if (PathFileExists("./quickLogin.ini")) {
		int nVolume = GetPrivateProfileInt( "config", "Sound", 99999, "./quickLogin.ini" );
		if (nVolume != 99999) {
			system_info.sound = nVolume;
			SetVolume(system_info.sound);
		}
		nVolume = GetPrivateProfileInt( "config", "Music", 99999, "./quickLogin.ini" );
		if (nVolume != 99999) {
			system_info.music = nVolume;
			SetVolumeMusic(system_info.music);
		}
	}

	// 010711 YGI
	g_SelectServerIndex = GetPrivateProfileInt( "network", "ServerSet", 0, g_szInfoFile );

	//< kjy-040325 
	// 일스 선택 방지 플래그를 dragon.ini파일로부터 입력받는다. 
	char szKeySelectYilse[50];
	memset( szKeySelectYilse, '\0', 50 );
	sprintf( szKeySelectYilse, "name%d_prevent_select_yilse", g_SelectServerIndex+1 );
	g_GameInfo.preventSelectYilse = GetPrivateProfileInt( "network", szKeySelectYilse, 0, g_szInfoFile );
	//> kjy-040325 

	GetPrivateProfileInt("Option", "ShowLocalWarMenu", 0, g_szConfigFile) ? g_bShowLocalWarMenu = true : g_bShowLocalWarMenu = false;
	GetPrivateProfileInt("Option", "LockView", 0, g_szConfigFile) ? g_bScrollScreen = true : g_bScrollScreen = false;
	GetPrivateProfileInt("Option", "hardwaveRender", 0, g_szConfigFile) ? g_bHardwaveRender = true : g_bHardwaveRender = false;
	//< CSD-040127
//#ifdef KOREA_LOCALIZING_
	g_GameInfo.proxy_port = 9884;
//#else
//	g_GameInfo.proxy_port = 9000;
//#endif
  	g_GameInfo.agent_port = 9881;
	//> CSD-040127
	return	TRUE;
}	
	
int LoadingGameData()
{	// eLoadingGameDataStep 를 사용
	static int s_iLoadingPos = LGDS_FIRST;
	
	switch (s_iLoadingPos)
	{
	case LGDS_FIRST:
		{
			LoadAttackRangeTable(0);
			LoadAttackRangeTable(1);

			if (SysInfo.notconectserver)
			{
				s_iLoadingPos = LGDS_STEP1;
				return s_iLoadingPos;
			}

			DWORD StartTime = ::timeGetTime();
			ListenCommand = CMD_NONE;
			
			while (true)
			{	
				DWORD Duration = ::timeGetTime( ) - StartTime;
				
				if (Duration > WAIT_TIME_RESPONSE_DURATION) // 030930 kyo
				{
					s_iLoadingPos = LGDS_FIRST;
					return -1;								
				}
				
				if (HandleRunning(&connections) <= 0)
				{																	
					Release(&connections);
					s_iLoadingPos = LGDS_FIRST;
					return -2;											
				}																		
				
				if (ListenCommand == CONNECT_REFUSE)
				{
					s_iLoadingPos = LGDS_FIRST;
					return -3;
				}
				
				if (ListenCommand == CMD_CONNECT_INFO)
				{
					s_iLoadingPos = LGDS_STEP1;	
					return s_iLoadingPos;
				}
			}

			break;
		}
	case LGDS_STEP1:
		{
			HandleRunning(&connections);
			g_Volume_Off = 1; // 로딩이 끝날 때까지 배경음악 이외의 소리 안나오게
			
			if (SysInfo.notconectserver)
			{
				if (!BuildCharacterList(&g_CharacterList))
				{
					JustMsg(lan->OutputMessage(6, 8)); //010215 lsw
				}
			}

			s_iLoadingPos = LGDS_STEP2;
			break;
		}
	case LGDS_STEP2:
		{
			MapBuild(&g_Map, MapName);	// map
			
			if (HandleRunning(&connections) <= 0)
			{
				Release(&connections);
				return -2;
			}

			s_iLoadingPos = LGDS_STEP3;
			break;
		}
	case LGDS_STEP3 :
		{
			LoadTOI(MapName);
			HandleRunning(&connections );
			BuildRoofHeader(&g_RoofHeader, MapName);					// rof
			HandleRunning(&connections);
			BuildEventList(MapName);									// ent
			HandleRunning(&connections);
			
			ReqTacSkillExp();	// 전체 택틱 수치 가져오기
			HandleRunning(&connections);
			AllReqSkillExp();	// 전체 스킬 경험치 가져오기
			HandleRunning(&connections);
			s_iLoadingPos = LGDS_STEP4;
			break;
		}
	case LGDS_STEP4:		
		{
#ifdef FROM_DISK
			LoadMapSource2( MapName );									// sou		
#else
			LoadMapSourceFromDat2( MapName );									// sou		
#endif
			HandleRunning( &connections);
			s_iLoadingPos = LGDS_STEP5;
			break;
		}
	case LGDS_STEP5: 
		{
			LoadCharSpriteData( "./char/000000.spr",  &CharBuf[0],  &CharBufLength[0], &CharSpr[0], LD_CHAR_SPRITE_ALL_LOAD);
			HandleRunning(&connections);
			s_iLoadingPos= LGDS_STEP6;
			break;
		}
	case LGDS_STEP6: 
		{
			LoadCharSpriteData( "./char/001000.spr",  &CharBuf[1],  &CharBufLength[1], &CharSpr[1], LD_CHAR_SPRITE_ALL_LOAD);
			LoadHeroClothAccessoryData( 104, 107 );
			
			char tempfilename[FILENAME_MAX];
			const int preloadcharsprite[21] = {29,30,37,38,46,72,79,1005,1006,1017,1018,1019,1020,1027,1028,1041,1060,1061,1075,1083,1092 };
						
			for (int i = 0; i < 21; ++i)
			{
				int tt = preloadcharsprite[i];
				sprintf(tempfilename, "./char/%06d.spr", tt);
				LoadCharSpriteData(tempfilename, &CharAccessoryBuf[tt/1000][tt%1000], &CharAccessoryBufLength[ tt/1000][tt%1000], &CharAccessorySpr[tt/1000][tt%1000], LD_CHAR_SPRITE_ALL_LOAD);
				HandleRunning(&connections);
			}
			
			HandleRunning(&connections);
			s_iLoadingPos = LGDS_STEP7;	
			break;
		}
	case LGDS_STEP7:
		{
			LoadClothOrderData();	
			HandleRunning(&connections);
			s_iLoadingPos = LGDS_STEP8;
			break;
		}
	case LGDS_STEP8 : 
		{
			LoadBrightData();			
			HandleRunning(&connections);
			s_iLoadingPos = LGDS_STEP9;
			break;
		}
	case LGDS_STEP9: 	
		{
			StartSetView(Hero);
			HandleRunning(&connections);
			s_iLoadingPos = LGDS_STEP10;
			break;
		}
	case LGDS_STEP10: 
		{
			LoadMenuData(1);
			HandleRunning(&connections);
			s_iLoadingPos = LGDS_STEP11;
			break;
		}
	case LGDS_STEP11: 
		{
			LoadMenuData(2);
			HandleRunning(&connections);
			s_iLoadingPos = LGDS_STEP12;
			break;
		}
	case LGDS_STEP12:
		{
			LoadHongSkillTable();
			HandleRunning(&connections);
			LoadMenuData(5);
			HandleRunning(&connections);

			if (CurOpenHouse >= 0)
			{
				RecvRoofOpen(CurOpenHouse);
			}

			InitHpUpDown();
			HandleRunning(&connections);
			s_iLoadingPos = LGDS_FIRST;
			return LGDS_END; // 이것만 예외 처리
		}
	}
	
	return s_iLoadingPos;
}