﻿
////쇱꿴溝固角뤠頓契죄Softice,TRW
//BOOL IsSofticeLoad()
//{   HANDLE hFile;
//	hFile = CreateFile( "\\\\.\\SICE", GENERIC_READ | GENERIC_WRITE,FILE_SHARE_READ | FILE_SHARE_WRITE,NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
//	if( hFile != INVALID_HANDLE_VALUE ) {  CloseHandle(hFile); return true; }
//	hFile = CreateFile( "\\\\.\\NTICE", GENERIC_READ | GENERIC_WRITE,FILE_SHARE_READ | FILE_SHARE_WRITE,NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
//	if( hFile != INVALID_HANDLE_VALUE )  { CloseHandle(hFile);return true;}
//	hFile = CreateFile( "\\\\.\\TRW", GENERIC_READ | GENERIC_WRITE,FILE_SHARE_READ | FILE_SHARE_WRITE,NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
//	if( hFile != INVALID_HANDLE_VALUE )  { CloseHandle(hFile);return true;}
//	hFile = CreateFile( "\\\\.\\TRWDEBUG", GENERIC_READ | GENERIC_WRITE,FILE_SHARE_READ | FILE_SHARE_WRITE,NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
//	if( hFile != INVALID_HANDLE_VALUE )  { CloseHandle(hFile);return true;}
//	return false;
//}

////쇱꿴溝固角뤠갛陋죄Softice
//BOOL IsSofticeInstall()
//{ 
//	//  '-#1: HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Uninstall\SoftICE
//	//'　-#2: HKEY_LOCAL_MACHINE\Software\NuMega\SoftICE
//	//'　-#3: HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\App Paths\Loader32.Exe
//	//'　-#4: HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\NTice
//	HKEY hKEY;
//	LPCTSTR data_Set="Software\\NuMega\\SoftICE";
//	long ret0=(::RegOpenKeyEx(HKEY_LOCAL_MACHINE,data_Set, 0, KEY_READ, &hKEY)); 
//	if(ret0!=ERROR_SUCCESS) { ::RegCloseKey(hKEY); return false;}
//	
//	data_Set="Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\SoftICE";
//	ret0=(::RegOpenKeyEx(HKEY_LOCAL_MACHINE,data_Set, 0, KEY_READ, &hKEY));
//	if(ret0!=ERROR_SUCCESS) { ::RegCloseKey(hKEY); return false;}
//	
//	::RegCloseKey(hKEY);
//	return true;
//}


//쇱꿴角뤠굳Ring3잚딧桿흡숭딧桿,NT溝固賈痰
/*
BOOL Check_Debugger() 
{ 	
	HANDLE     hProcessSnap = NULL; 
	char Expchar[] ="\\EXPLORER.EXE"; 
	char szBuffer[MAX_PATH] = {0}; 
	char FileName[MAX_PATH] = {0};  
	PROCESSENTRY32 pe32     = {0}; 
	hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0); //돤돕杰唐쏵넋돨죗깊우亮 
	if (hProcessSnap == INVALID_HANDLE_VALUE)   
		return FALSE;           
	
	pe32.dwSize = sizeof(PROCESSENTRY32); 	
	if (!Process32First(hProcessSnap, &pe32))
	{ 
		CloseHandle (hProcessSnap); 
		return FALSE;  
	} 

	do
	{ 
		if(pe32.th32ProcessID==GetCurrentProcessId() )//털뙤角뤠角菱성돨쏵넋？ 
		{ 
			HANDLE hProcess = OpenProcess (PROCESS_ALL_ACCESS, FALSE, pe32.th32ParentProcessID); //댔역만쏵넋 
			if (hProcess)  
			{  
				if (GetModuleFileNameEx(hProcess, NULL, FileName,  MAX_PATH) ) // 돤돕만쏵넋츰 
				{  
					GetWindowsDirectory(szBuffer,MAX_PATH); //돤돕溝固杰瞳커쩌 
					strcat(szBuffer,Expchar);            //莉북냥잚慨돨俚눔D:\Winnt\Explorer.EXE 
					if(strcmpi (FileName,szBuffer))  // 궐싹뎠품角뤠槨Explorer.EXE쏵넋 
						return TRUE;   // 만쏵넋흼꼇角Explorer.EXE，橙角딧桿포 
				}  
				else  
				{  
					return FALSE; // 轟랬삿돤쏵넋츰 
					
				}  
				CloseHandle (hProcess);  
			}  
			else  
			{  
				return FALSE;//轟홈련狂맡쏵넋  
			}  
		
		} 	
	} 
	while (Process32Next(hProcessSnap, &pe32)); 
	
	CloseHandle (hProcessSnap); 
	return FALSE;  

} 
*/