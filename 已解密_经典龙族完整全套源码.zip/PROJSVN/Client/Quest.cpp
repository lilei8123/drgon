﻿#include	"stdafx.h"
#include	"network3.h"

#define	QSF_TELEPORT		1

void	RecvQSF_Command( t_qsf_command	qc )
{
	switch(qc.command)
	{
	case QSF_TELEPORT:		//Teleport
		break;
	default:
		break;
	}
}