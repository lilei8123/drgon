//Author :- Nish [nishforever@vsnl.com]
#ifndef CFILETAR
#define CFILETAR

#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <map>

#define TAR_MAX_FILES 1024
#define NBUFFSIZE 8092


typedef struct
{
    FILE *fp;
    long Start;
    long Size;
	char packFile[_MAX_PATH];
} PackHandle;

class CFileTar
{
public:
	struct TarIndex
	{
		long Start;
		long Size;
		char FileName[_MAX_FNAME];
	};

	struct TarHeader
	{
	private:
		int FileCount;
	public:
		TarHeader();
		int IncrementCount();
		int GetCount();
	};



public:
	static int UnTar(char *TarFile, char *dpath);
	static int UnTar(char *TarFile, int index, char *fpath);
	static int GetFileInfo(char *TarFile, TarIndex *pTarIndex, int index);
	static int GetTarInfo(char *TarFile,TarHeader *pTarHeader);
	int PackPreload(char *packFile);
	int PackOpen(char* filename, PackHandle *ph, char* mode);
	int PackRead(void * ptr, size_t Size, size_t Count, PackHandle *ph);
	size_t PackWrite ( const void * ptr, size_t size, size_t count, PackHandle *ph );
	int PackPrint ( PackHandle* ph, const char * format, ... );
	char* PackGets(char * str, int num, PackHandle *ph);
	int PackSeek(PackHandle *ph, long int offset, int origin);
	int PackRewind(PackHandle *ph);
	int PackClose(PackHandle *ph);
	int PackGetpos (PackHandle *ph, fpos_t * pos );
	int PackScanf(PackHandle* ph, const char * format, ... );
	int PackEOF(PackHandle *ph);
	long int PackTell(PackHandle *ph);

	int CreateTar(char *TarFName, char *TarPath = NULL);
	int AddFile(char *fname);
	void SetFilePath(char *path);
	CFileTar();
	CFileTar(char* packfile);
	virtual ~CFileTar();
private:
	TarHeader m_TarHeader;
	TarIndex* m_pTarIndex[TAR_MAX_FILES];
	char FilePath[_MAX_PATH];
	int AppendFile(int fdout, char *fpath);
	long currentPos;
	fpos_t fpos;
	std::map<string,PackHandle> fileMap;
	std::map<string,PackHandle>::iterator it;
	
};
extern CFileTar cft;

#endif
