﻿



#ifndef __HONG_SUB_H__
#define __HONG_SUB_H__

extern int debug_makemode;
extern int debug_pc_neverdie; 

extern int InitGameMakeModeSetting( char *filename );
extern char* EatRearWhiteChar( char* pStr );

extern void Debug( char *s, ... );
extern int ViewCheckRoutine( int t );


extern void JustMsg( char *s, ... );
extern void ErrMsg( char *s, ... );
extern int YesOrNo( char *s, char *title );

extern void Log_LogIn( int mon, int day, int hour, int min, int sec, char *id );

#else




#endif
