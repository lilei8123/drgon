﻿
#define HACKING_DELETE_CHAR_NORMAL_	10000
#define HACKING_EFFECTTABLE_	20001
#define HACKING_011106_			20002
#define HACKING_CONDITIONTABLE_	20003
#define HACKING_MOVEPATTERN_	20004
#define HACKING_ANITABLE_		20005
#define HACKING_ATTACKRANGE_	20006
#define HACKING_ACCELATOR_		20007
#define HACKING_FILTER_			20008
#define HACKING_INVALID_CHAR_	20009



extern int  Recv_ChrLogDB( t_packet *p, int cn );


extern void InitHackingLog( void );
extern bool RecvHackingUser( const char *id, const char *name, const int type, const char *ip, const char *cause );//020725 lsw

extern void InitRareItemMakeResultLog( void );
extern bool RecvRareItemMakeLog( t_rare_item_make_log *tp );

