﻿#ifndef __SCRIPT_INT_H__
#define __SCRIPT_INT_H__

const int SCRIPT_OLD = 0;
const int SCRIPT_NEW = 1;

enum 
{
    goto_     =  0xe0,
    if_       =  0xe1,
    call_     =  0xe2,
    add_      =  0xe3,
    sub_      =  0xe4,
    mul_      =  0xe5,
    div_      =  0xe6,
    rest_     =  0xe7,
    equal_    =  0xe8,
    end_      =  0xe9,
    ifequal_  =  0xea,
    or_       =  0xeb,
    and_      =  0xec,
    variable_ =  0xed,
    value_    =  0xee,
    add2_     =  0xef,
    sub2_     =  0xf0,
    mul2_     =  0xf1,
    div2_     =  0xf2,
    rest2_    =  0xf3,
    or2_      =  0xf4,
    and2_     =  0xf5,
};


#ifndef __SCRIPT_C__

    
	extern int  NScriptNo;    //SCRIPT_NO;
    extern int  CLoadScript;  //LOAD_SCRIPT;
    
	extern int  TotalFunction;

#endif

void Incode( char *s );

/* 
 함수명 : GetByte
 인  자 : 없음
 리턴값 : 1바이트의 값
 설  명 : prog에 기록된 내용에서 1바이트를 리턴하고 prog포인터를 1증가
 */
BYTE GetByte( void );


/* 
 함수명 : GetInt
 인  자 : 없음
 리턴값 : 4바이트의 값
 설  명 : prog에 기록된 내용에서 4바이트를 리턴하고 prog포인터를 4증가
 */
int GetInt( void );


/* 
 함수명 : GetString
 인  자 :
 리턴값 : 문자열을 저장하고 있는 배열의 시작 포인터
 설  명 : 스크립트 데이타에서 문자열을 읽어들인다.
 */
void GetString( char *buf );


/* 
 함수명 : Script
 인  자 : 없음
 리턴값 : 없음
 설  명 : 스크립트 주 실행기
 */
void Script( int num );


/* 
 함수명 : LoadScript
 인  자 : name - 읽어들이고자 하는 스크립트 데이타 화일명이 아니라 일련번호.
 리턴값 :
 설  명 : 정상적으로 읽어들이면 1을 리턴한다.
 */
int LoadScript( char *scriptname );
int LoadScriptText( char *scrname );




#endif


