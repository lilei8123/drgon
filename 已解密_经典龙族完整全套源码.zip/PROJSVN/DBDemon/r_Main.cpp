﻿#include "StdAfx.h"
#define __MAIN_H__
#include "MAIN.H"
#include "SealStone.h"
#include "MyLog.h"
#include <MMSystem.h>
#include "ChrLog.h"
#include "CItem.h"//010708 lsw 
#include "network.h"
#include "LottoDBMgr.h"//soto-030505
#include "ShopDemon.h"

SOCKET lsock = 0;
struct sockaddr_in laddr;

DWORD global_time		= 0;
DWORD g_start_time		= 0;
DWORD g_alive_time		= 0;
DWORD g_curr_time		= 0;



HourSeg g_aDungeonHourSeg[7];

HourSeg g_aHourSeg2[7];
int g_total_gameserver, g_current_gameserver;	// 현재 접속된 게임서버의 수..
int g_gameserver_check_start; // 1되면 게임서버수를 Check하기 시작한다. 
int g_closed_gameserver;
int g_year				= 0;
int g_mon				= 0;
int g_yday				= 0;
int g_day				= 0;
int g_hour				= 0;
int g_min				= 0;
int g_sec				= 0;
int g_OldDay			= 0;
int g_wday				= 0;//020410 lsw
int g_count_ok;
int		GameServerVersion;
int     StartMap, StartPosition;
int	g_OnlineCount = 0;
// 010221_3 YGI
//020822 lsw
char	StartMapPosition[ 5][20][20] = {	{ "", "k_sung2","ma-in", "Source",  "Gray",  "color","bis_i", "Renes_c", "","iramus","dep","SCHOLIUM", "tynen", "barantan","SCHOLIUM2", },	// 헾턴트....
{ "", "k_sung2","ma-in", "Source",  "Gray",  "color","bis_i", "Renes_c", "","iramus","dep","SCHOLIUM", "tynen", "barantan","SCHOLIUM2", },	// 헾턴트....		// 010414 YGI
{ "", "k_sung2","ma-in", "Hu_Vm",  "Gray",  "color","","Renes_c", },	// 헾턴트....
{ "", "k_sung2","ma-in", "source", "ma-in", "ma-in","","ma-in", },};



extern HWND g_hWnd;

extern int initItem(void) ;
extern bool IsConnectName( char *name );
extern bool g_bDisablePay;
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------

//---------------------------------------------------------------------------------

void prepare(t_connection c[])
{
	global_time = ::timeGetTime();
	
	time_t lTime = {0,};
	time(&lTime);
	struct tm *today = localtime(&lTime);
	
	g_year = today->tm_year + 1900;
	g_mon  = today->tm_mon;
	g_yday = today->tm_yday;
	g_wday = today->tm_wday;
	g_day  = today->tm_mday;
	g_hour = today->tm_hour;
	g_min  = today->tm_min;
	g_sec  = today->tm_sec;
	
	g_curr_time = ( (g_year-1999 ) * 31536000) 
		+ (g_yday* 86400) 
		+ (g_hour* 3600) 
		+ (g_min * 60) 
		+ g_sec;
}
//---------------------------------------------------------------------------------
// 020808 YGI
struct ID_PASS
{
	char m_szID1[30];		// dragon id
	char m_szPASS1[30];
	char m_szID2[30];		// totaldb id
	char m_szPASS2[30];
	char m_szID3[30];		// chrlogdb id
	char m_szPASS3[30];
	
	ID_PASS()
	{
		m_szID1[0] = 0;
		m_szPASS1[0] = 0;
		m_szID2[0] = 0;
		m_szPASS2[0] = 0;
		m_szID3[0] = 0;
		m_szPASS3[0] = 0;
	}
};
#include "hsel.h"
bool DecoadFile( char *filename, void *pData, int size )
{
	CHSEL_STREAM m_hsel;
	FILE *fp = fopen( filename, "rb" );
	if( !fp ) return false;
	
	int nVersion = 0;
	fread( (void*)(&nVersion), sizeof(int), 1, fp ); 
	if (m_hsel.GetVersion() != nVersion)  return false;
	HselInit deinit;
	fread( (void*)(&deinit), sizeof(HselInit), 1, fp );
	if (!m_hsel.Initial(deinit))  return false;
	fread( pData, 1, size, fp );
	m_hsel.Decrypt((char *)pData, size);
	fclose( fp );
	return true;
}
bool IncordFile( char *filename, void *pData, int size )
{
	CHSEL_STREAM m_hsel;
	FILE *fp = fopen( filename, "wb" );
	if( !fp ) return false;
	
	HselInit eninit;
	eninit.iEncryptType	=	HSEL_ENCRYPTTYPE_RAND;
	eninit.iDesCount	=	HSEL_DES_TRIPLE;
	eninit.iCustomize	=	HSEL_KEY_TYPE_DEFAULT;
	eninit.iSwapFlag	=	HSEL_SWAP_FLAG_ON;
	
	if (!m_hsel.Initial(eninit)) 
	{
		return false;
	}
	
	HselInit deinit;
	deinit = m_hsel.GetHSELCustomizeOption();
	const int nVersion = m_hsel.GetVersion();
	fwrite((void *)(&nVersion), sizeof(nVersion), 1, fp ); 
	fwrite((void *)(&deinit), sizeof(HselInit), 1, fp ); 
	m_hsel.Encrypt((char*)pData, size);
	fwrite( pData, 1, size, fp );
	fclose( fp );
	return true;
}
//---------------------------------------------------------------------------------


//extern struct HourSeg;
extern HourSeg g_aDungeonHourSeg[7];

bool LoadDungeonTable()
{

	char		szQuerry[512];
	HSTMT		hStmt = NULL;
	RETCODE		retCode;
	SDWORD		cbValue;
	//struct tm* NewTime;
	//time_t LongTime;

	int			nRow = 0, nTemp = 0, nApplyDay = 0, nStartHour = 0, nEndHour = 0;
	DWORD idIndex = 0;

	//time(&LongTime);
	//NewTime = localtime(&LongTime);	


	sprintf(szQuerry, "SELECT idDungeon, idStartUp, apply_day, start_hour, end_hour FROM scenario_dungeon_startup" );
	SQLAllocStmt(hDBC, &hStmt);
	retCode = _SQLExecDirect(hStmt, (UCHAR *)szQuerry, SQL_NTS);

	if( !SQLOK(retCode) ) 
	{
		return false;
	}

	retCode = SQLFetch( hStmt );



	while( SQLOK(retCode) ) 
	{

		SQLGetData(hStmt, 1, SQL_C_ULONG, &nTemp, 0, &cbValue);
		SQLGetData(hStmt, 2, SQL_C_ULONG, &idIndex, 0, &cbValue);
		SQLGetData(hStmt, 3, SQL_C_ULONG, &nApplyDay, 0, &cbValue);
		SQLGetData(hStmt, 4, SQL_C_ULONG, &nStartHour, 0, &cbValue);
		SQLGetData(hStmt, 5, SQL_C_ULONG, &nEndHour, 0, &cbValue);


		g_aDungeonHourSeg[nApplyDay].start = nStartHour;
		
		if( nEndHour < nStartHour )
		{
			g_aDungeonHourSeg[nApplyDay].end = 24;

			g_aHourSeg2[(nApplyDay+1) % 7].start  = 0;
			g_aHourSeg2[(nApplyDay+1) % 7].end  = nEndHour;
		}
		else
		{
			g_aDungeonHourSeg[nApplyDay].end = nEndHour;
		}

		retCode = SQLFetch( hStmt );		

	}


	SQLFreeStmt(hStmt, SQL_DROP);

	return true;	

}

void TrimRight(char AStr[]) {
	for (int i = strlen(AStr) - 1; i >= 0; i--) {
		if ((AStr[i] != ' ') && (AStr[i] != '\0')) break;
		if (AStr[i] == ' ') {
			AStr[i] = '\0';
		}
	}
}

bool isRunRealUpdateScore = false;
struct tagPayInfo {
	char				ID[20];
	char				name[20];
	int					payID;
	int					payCount;
	int					payType;
	TIMESTAMP_STRUCT	buyTime;
};
void CALLBACK RealUpdateScore(HWND hWnd,UINT nMsg,UINT nTimerid,DWORD dwTime)
{
	// 此处为实时加载玩家充值积分的定时器
	// 本地图玩家遍历，读取 chr_payinfo，如果有相关充值记录，那么立刻删除该条记录并增加相应的积分。
	// 如果数据连接未初始化，或者 chr_payinfo 表中没有数据，那么停止本次检测;
	// 本队列最多处理1000条充值记录，如果超过1000条，那么由下批处理;
	if (isRunRealUpdateScore) return;
	if (!hDBC) return;

	isRunRealUpdateScore = true;
	__try {
		HSTMT		hStmt = NULL;
		RETCODE		retCode;
		SDWORD		cbValue;
		char		szQuerry[2048];
		char		szDelete[4000];
		int			t;
		tagPayInfo	payInfo[1000];
		int			nIndex = 0;

		// 这里更新在线玩家，由于此处也是3秒更新一次，所以写在一起了。
		sprintf(szDelete, "Select count(*) from login_name");
		SQLAllocStmt(hDBC, &hStmt);
		__try {
			retCode = _SQLExecDirect(hStmt, (UCHAR *)szDelete, SQL_NTS);
			if (retCode == SQL_SUCCESS || retCode == SQL_SUCCESS_WITH_INFO) {		
				retCode = SQLFetch(hStmt);
				if (retCode == SQL_SUCCESS || retCode == SQL_SUCCESS_WITH_INFO) {
					retCode = SQLGetData(hStmt, 1, SQL_C_ULONG, &t, 0, &cbValue); g_OnlineCount = (short)t;
				}
			}
		} __finally {
			SQLFreeStmt(hStmt, SQL_DROP);
		}

		memset(payInfo, 0L, sizeof(tagPayInfo) * 1000);
		sprintf(szQuerry, "Select top 1000 login_id, name, payID, payCount, payType, buyTime from Chr_PayInfo");
		SQLAllocStmt(hDBC, &hStmt);
		__try {
			retCode = _SQLExecDirect(hStmt, (UCHAR *)szQuerry, SQL_NTS);
			if (retCode == SQL_SUCCESS || retCode == SQL_SUCCESS_WITH_INFO) {		
				retCode = SQLFetch(hStmt);
				while (retCode == SQL_SUCCESS || retCode == SQL_SUCCESS_WITH_INFO) {
					retCode = SQLGetData(hStmt, 1, SQL_C_CHAR,		payInfo[nIndex].ID, 20, &cbValue);
					retCode = SQLGetData(hStmt, 2, SQL_C_CHAR,		payInfo[nIndex].name, 20, &cbValue);
					retCode = SQLGetData(hStmt, 3, SQL_C_ULONG,		&t, 0, &cbValue);	payInfo[nIndex].payID = (short)t;
					retCode = SQLGetData(hStmt, 4, SQL_C_ULONG,		&t, 0, &cbValue);	payInfo[nIndex].payCount = t;
					retCode = SQLGetData(hStmt, 5, SQL_C_ULONG,		&t, 0, &cbValue);	payInfo[nIndex].payType = (short)t;
					retCode = SQLGetData(hStmt, 6, SQL_C_TIMESTAMP,	&payInfo[nIndex].buyTime, sizeof(TIMESTAMP_STRUCT), &cbValue);
					TrimRight(payInfo[nIndex].ID);
					TrimRight(payInfo[nIndex].name);
					
					if (payInfo[nIndex].payCount == 0) {
						payInfo[nIndex].payID = 0;
					} else {
						nIndex++;
					}
					if (nIndex >= 1000) break;
					retCode = SQLFetch(hStmt);
				}
			}
		} __finally {
			SQLFreeStmt(hStmt, SQL_DROP);
		}

		for (nIndex = 0; nIndex < 1000; nIndex++) {
			if (payInfo[nIndex].payID == 0) break;
			if (payInfo[nIndex].payCount == 0) continue;
			bool isFind = false;
			if (IsConnectName(payInfo[nIndex].name)) {
				for (int cn = 0; cn < LOGIN_MAX_CONNECTIONS; cn++) {
					// 对所有 MapServer 广播更新消息
					if (connections[cn].dwConIndex > 0) {
						t_packet rp;
						rp.h.header.type = CMD_REALUPDATESCORE;
						rp.h.header.size = sizeof(t_char_payinfo);
						memcpy(rp.u.char_payinfo.ID, payInfo[nIndex].ID, 20);
						memcpy(rp.u.char_payinfo.name, payInfo[nIndex].name, 20);
						rp.u.char_payinfo.payID = payInfo[nIndex].payID;
						rp.u.char_payinfo.payCount = payInfo[nIndex].payCount;
						rp.u.char_payinfo.payType = payInfo[nIndex].payType;
						memcpy(&rp.u.char_payinfo.buyTime, &payInfo[nIndex].buyTime, sizeof(TIMESTAMP_STRUCT));
						::QueuePacket(connections, cn, &rp, 1);
					}
				}
			} else {
				// 直接更改数据库
				if (payInfo[nIndex].payType == 0) { // 会员
					sprintf(szDelete, "delete from Chr_PayInfo where payId = %d", payInfo[nIndex].payID);
					if (Querry_SQL(szDelete, hDBC) == 1) {
						char sTime[20];
						sprintf(sTime, "%d-%d-%d %d:%d:%d", payInfo[nIndex].buyTime.year, payInfo[nIndex].buyTime.month, payInfo[nIndex].buyTime.day, payInfo[nIndex].buyTime.hour, payInfo[nIndex].buyTime.minute, payInfo[nIndex].buyTime.second);
						sprintf(szDelete, "update Chr_Info2 set cardEndDay = DATEADD(month, %d, (case when cardEndDay > cast('%s' as datetime) then cardEndDay else cast('%s' as datetime) end)), payCount = payCount + 1 where login_id = '%s' and name='%s'", payInfo[nIndex].payCount, sTime, sTime, payInfo[nIndex].ID, payInfo[nIndex].name);
						Querry_SQL(szDelete, hDBC);
					} else {
						MyLog(LOG_NORMAL, "更新充值会员记录失败，用户名：%s，密码：%s", payInfo[nIndex].ID, payInfo[nIndex].name);
					}

				} else if (payInfo[nIndex].payType == 1) { // 双倍卡
					sprintf(szDelete, "delete from Chr_PayInfo where payId = %d", payInfo[nIndex].payID);
					if (Querry_SQL(szDelete, hDBC) == 1) {
						char sTime[20];
						sprintf(sTime, "%d-%d-%d %d:%d:%d", payInfo[nIndex].buyTime.year, payInfo[nIndex].buyTime.month, payInfo[nIndex].buyTime.day, payInfo[nIndex].buyTime.hour, payInfo[nIndex].buyTime.minute, payInfo[nIndex].buyTime.second);
						sprintf(szDelete,
							"declare @loginID varchar(20);\n"
							"declare @charName varchar(20);\n"
							"declare @buycount int;\n"
							"declare @payCount int;\n"
							"declare @buytime datetime;\n"
							"declare @scoreTime1 datetime;\n"
							"declare @scoreTime2 datetime;\n"
							"declare @scoreTime3 datetime;\n"
							"declare @scoreTime4 datetime;\n"
							"declare @scoreTime5 datetime;\n"
							"declare @score1 int;\n"
							"declare @score2 int;\n"
							"declare @score3 int;\n"
							"declare @score4 int;\n"
							"declare @score5 int;\n"
							"declare @tScore1 int;\n"
							"declare @tScore2 int;\n"
							"declare @tScore3 int;\n"
							"declare @tScore4 int;\n"
							"declare @tScore5 int;\n"
							"declare @tScoreTime1 datetime;\n"
							"declare @tScoreTime2 datetime;\n"
							"declare @tScoreTime3 datetime;\n"
							"declare @tScoreTime4 datetime;\n"
							"declare @tScoreTime5 datetime;\n"
							"set @tScore1=0;\n"
							"set @tScore2=0;\n"
							"set @tScore3=0;\n"
							"set @tScore4=0;\n"
							"set @tScore5=0;\n"
							"set @tScoreTime1=NULL;\n"
							"set @tScoreTime2=NULL;\n"
							"set @tScoreTime3=NULL;\n"
							"set @tScoreTime4=NULL;\n"
							"set @tScoreTime5=NULL;\n"
							"set @loginID = '%s';\n"
							"set @charName = '%s';\n"
							"set @buycount = %d;\n"
							"set @buytime = '%s';\n"
							"if exists ( SELECT * FROM [DragonRajaDB].[dbo].Chr_Info2 WHERE login_id = @loginID and name=@charName ) begin\n"
							"	select @payCount=payCount+1, @scoreTime1=scoreTime1,@scoreTime2=scoreTime2,@scoreTime3=scoreTime3,@scoreTime4=scoreTime4,@scoreTime5=scoreTime5, @score1=score1,@score2=score2,@score3=score3,@score4=score4,@score5=score5 from [DragonRajaDB].[dbo].Chr_Info2 WHERE login_id = @loginID and name=@charName\n"
							"	if @score1=0 begin\n"
							"		update [DragonRajaDB].[dbo].Chr_Info2 set scoreTime1=DATEADD( month ,1,@buytime ),score1=@buycount,payCount=@payCount where name=@charName;\n"
							"	end else begin\n"
							"		set @tScore1=@buycount;\n"
							"		set @tScoreTime1=DATEADD( month ,1,@buytime );\n"
							"		if( @scoreTime1 > @buytime ) begin\n"
							"			set @tScore2=@Score1+@buycount;\n"
							"			set @tScoreTime2=@scoreTime1;\n"
							"			if (@score2 > 0) and (@scoreTime2 > @buytime) begin\n"
							"				set @tScore3=@score2+@buycount; \n"
							"				set @tScoreTime3=@scoreTime2;\n"
							"				if ( @score3 > 0 ) and (@scoreTime3 > @buytime) begin\n"
							"					set @tScore4=@score3+@buycount;\n"
							"					set @tScoreTime4=@scoreTime3;\n"
							"					if ( @score4 > 0) and (@scoreTime4 > @buytime) begin\n"
							"						set @tScore5=@score4+@buycount;\n"
							"						set @tScoreTime5=@scoreTime4;\n"
							"					end;\n"
							"				end;\n"
							"			end;\n"
							"		end;\n"
							"		update [DragonRajaDB].[dbo].Chr_Info2 set\n"
							"			scoreTime1=@tScoreTime1,scoreTime2=@tScoreTime2,scoreTime3=@tScoreTime3,\n"
							"			scoreTime4=@tScoreTime4,scoreTime5=@tScoreTime5,score1=@tScore1,score2=@tScore2,\n"
							"			score3=@tScore3,score4=@tScore4,score5=@tScore5,payCount=@payCount\n"
							"		where name=@charName;\n"
							"	end;\n"
							"end\n", payInfo[nIndex].ID, payInfo[nIndex].name, payInfo[nIndex].payCount, sTime);
						Querry_SQL(szDelete, hDBC);
					} else {
						MyLog(LOG_NORMAL, "更新充值会员记录失败，用户名：%s，密码：%s", payInfo[nIndex].ID, payInfo[nIndex].name);
					}

				} else if (payInfo[nIndex].payType == 2) { // 积分
					sprintf(szDelete, "delete from Chr_PayInfo where payId = %d", payInfo[nIndex].payID);
					if (Querry_SQL(szDelete, hDBC) == 1) {
						sprintf(szDelete, "update Chr_Info set score = score + %d where login_id = '%s' and name = '%s'", payInfo[nIndex].payCount, payInfo[nIndex].ID, payInfo[nIndex].name);
						Querry_SQL(szDelete, hDBC);
					} else {
						MyLog(LOG_NORMAL, "更新充值积分记录失败，用户名：%s，密码：%s", payInfo[nIndex].ID, payInfo[nIndex].name);
					}
				}
			}
		}
	}__finally {
		isRunRealUpdateScore = false;
	}
}

// 020808 YGI - 주의사항 참조
int init_login_main( void )
{
	char path[MAX_PATH];
	ID_PASS id_password;
	int bIdPassword = 0;		// 정확히 암호를 읽어 왔는가?
	int size = GetPrivateProfileString( "option", "path", "", path, 50, DB_DEMON_INI_ );//021007 lsw
	if( size )
	{
		sprintf( path, "%s/data/IdPassword.bin", path );
		bIdPassword = DecoadFile( path, (char *)&id_password, sizeof( ID_PASS ) );
	}
	
	ID_PASS IdPassWord;
	strcpy( IdPassWord.m_szID1,		LocalMgr.GetDBAccount(DRAGON_DB,ID));
	strcpy( IdPassWord.m_szPASS1,	LocalMgr.GetDBAccount(DRAGON_DB,PASS) );
	strcpy( IdPassWord.m_szID2,		LocalMgr.GetDBAccount(TOTAL_DB,ID) );
	strcpy( IdPassWord.m_szPASS2,	LocalMgr.GetDBAccount(TOTAL_DB,PASS) );
	strcpy( IdPassWord.m_szID3,		LocalMgr.GetDBAccount(CHRLOG_DB,ID) );
	strcpy( IdPassWord.m_szPASS3,	LocalMgr.GetDBAccount(CHRLOG_DB,PASS) );
		
	if( bIdPassword )
		IdPassWord = id_password;
	
	if( (Init_SQL("DragonRajaDB", IdPassWord.m_szID1, IdPassWord.m_szPASS1) ) == 0)
	{
		ErrMsg( "'DragonRajaDB' Table Initializing Fail !" );
		return(-1);
	}
	MyLog( LOG_NORMAL, "SQL server( DragonDB ) connect OK!");
	
	if( (Init_TotalDB_SQL( "TotalDB", IdPassWord.m_szID2, IdPassWord.m_szPASS2) ) == 0 ) 
	{
		ErrMsg( "'TotalDB' Table Initializing Fail !" );
		return(-1);
	}
	MyLog( LOG_NORMAL, "SQL server( Total DB ) connect OK!");
	
	if( (Init_ChrLogDB_SQL( "ChrLogDB", IdPassWord.m_szID3, IdPassWord.m_szPASS3) ) == 0 ) 
	{
		ErrMsg( "'ChrLogDB' Table Initializing Fail !" );
		return(-1);
	}

	MyLog( LOG_NORMAL, "SQL server( ChrLogDB ) connect OK!");

	if(LocalMgr.IsAbleNation(JAPAN))
	{
		if((Init_NGCDB_SQL( "NgcDB", "terradragon", "xpfkemforhs"))  == 0 )
		{
			ErrMsg( "'NGCDB' Table Initializing Fail !" );
			return(-1);
		}
		MyLog( LOG_NORMAL, "SQL server( NGCB ) connect OK!");
	}	
	
	InitHackingLog();
	InitRareItemMakeResultLog();
	
	LoadNoName_SQL();		// 010117 YGI
	InitItemList();
	
	CShopDemon::Create(); // soto-HK-030931
	CLottoDBMgr::Create();

	LottoDBMgr()->LoadTable(hDBC);
	
	if(initItem() < 0) 	
	{	
		ErrMsg( "'initItem()' Fail !" );return(-2);
	}
	
	if( LoadChangeItem() != 1 )
	{	
		ErrMsg( "'LoadChangeItem()' Fail !" );return(-2);
	}
	if(!LoadEventRareItem())//020815-2 lsw
	{
		ErrMsg( "'LoadEventRareItem()' Fail !" );return(-2);
	}
	
	if	(LoadNPCLevTable() < 0)
	{	//< CSD-030306
		ErrMsg("'LoadNPCLevTable()' Fail !");
		return(-2);
	}	//> CSD-030306

	//if( !g_bDisablePay )
	//{
	//	char szDelete[100];
	//	sprintf(szDelete, "delete from login_name");
	//	if (Querry_SQL(szDelete, hDBC) != 1) {
	//		ErrMsg("Clear table login_name Fail !");
	//		return(-2);
	//	}
	//	SetTimer(0, 1, 1000*60, RealUpdateScore); 
	//}

				
	// 001126 KHS
	GetMapInfo( MapInfo );		
	memset(connections,0,sizeof(t_connection)*LOGIN_MAX_CONNECTIONS);
	
	if( !CheckWorstDBTable() )	// 010322 KHS
	{	
		return -1;
	}	

	LoadDungeonTable();
	
	return 0;
}		

//---------------------------------------------------------------------------------
