﻿#include "stdafx.h"
#include "Main.h"
	
#define __DEBUG_H__
#include "debug.h"
	
	
	
	
	
static int debug_SavePacketExeTimeStartFlag;
	
int debug_SavePacketExeTimeIng( void )
{	
	return debug_SavePacketExeTimeStartFlag;
}	
	
void debug_SavePacketExeTime( void )
{	
	debug_SavePacketExeTimeStartFlag = 1;
}	
	
void debug_StopSavePacketExeTime( void )
{	
	debug_SavePacketExeTimeStartFlag = 0;
}	













