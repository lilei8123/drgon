﻿#pragma once


#include "inetwork.h"

bool InitDBDemon();
void EndDBDemon();

extern I4DyuchiNET* g_pINet;
extern HANDLE hKeyEvent;
