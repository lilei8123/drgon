﻿// --------
// DB DEMON
// --------

#ifndef __IS_DB_DEMON
#define __IS_DB_DEMON
#endif
