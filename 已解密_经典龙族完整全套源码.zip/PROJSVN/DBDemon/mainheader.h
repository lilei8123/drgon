﻿#pragma once

#define HEADER_SIZE						7

extern int init_login_main( void );
extern int Release_SQL(void);
extern int Release_TotalDB_SQL(void);

extern void MapLog( int type, char *logmsg, ... );