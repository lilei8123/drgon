﻿








#ifndef __DEBUG_H__
#define __DEBUG_H__

	extern int debug_SavePacketExeTimeIng( void );
	extern void debug_SavePacketExeTime( void );
	extern void debug_StopSavePacketExeTime( void );

#else


#endif

