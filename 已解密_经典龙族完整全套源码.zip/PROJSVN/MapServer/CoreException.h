#ifndef COREEXCEPTION_H
#define COREEXCEPTION_H

BOOL DumpException(LPEXCEPTION_POINTERS lpExcep,char* szOutMsg, void *pData = NULL, int nSize = 0);

#endif // COREEXCEPTION_H ///:~