﻿// GameDefine.cpp: implementation of the CGameDefine class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GameDefine.h"
