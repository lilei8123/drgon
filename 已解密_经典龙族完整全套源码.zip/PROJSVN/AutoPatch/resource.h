//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DragonRaja.rc
//
#define IDD_DRAGONRAJA_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDB_CANCEL                      141
#define IDB_OK                          142
#define IDB_GOHOMEPAGE                  143
#define IDB_NEWID                       144
#define IDB_START                       145
#define IDB_UPDATENOW                   147
#define IDB_STARTGAME                   148
#define IDD_SMALLWINDOW                 151
#define IDD_GETCHCHE                    152
#define IDD_SERVERSELECT                152
#define IDD_SERVERSELECT_OTHER_NATION   153
#define IDB_SS_CANCEL_DOWN              159
#define IDB_SS_CANCEL_UP                160
#define IDB_SS_CANCEL_NORMAL            161
#define IDB_SS_OK_DOWN                  162
#define IDB_SS_OK_NORMAL                163
#define IDB_SS_OK_UP                    164
#define IDB_SS_BG                       165
#define IDB_SS_HP_DOWN                  167
#define IDB_SS_HP_NORMAL                168
#define IDB_SS_HP_UP                    169
#define IDB_NC_BG                       171
#define IDB_DN_BG                       172
#define IDB_DN_CANCEL_DOWN              173
#define IDB_DN_CANCEL_NORMAL            174
#define IDB_DN_CANCEL_UP                175
#define IDB_DN_NEWID_DOWN               176
#define IDB_DN_NEWID_NORMAL             177
#define IDB_DN_UPDATE_UP                178
#define IDB_DN_NEWID_UP                 179
#define IDB_DN_START_DOWN               180
#define IDB_DN_START_NORMAL             182
#define IDB_DN_START_UP                 183
#define IDB_UPDATE_DOWN                 184
#define IDB_DN_UPDATE_NORMAL            185
#define IDB_DN_UPDATE_DOWN              186
#define IDB_NC_BG2                      188
#define IDC_PROGRESS                    1000
#define IDC_README                      1001
#define IDC_NEWID                       1003
#define IDC_GOHOMEPAGE                  1004
#define IDC_PROGRESS2                   1006
#define IDC_LIST1                       1008
#define IDC_EDIT1                       1009
#define IDC_README2                     1010
#define IDC_LIST2                       1011
#define IDC_LIST3                       1012
#define IDC_PROGRESS1                   1012
#define IDC_LIST4                       1013
#define IDC_SERVERSELECT                1013
#define ID_OK                           1014
#define ID_CANCEL                       1015
#define IDC_TITLE_STRING                1016
#define ID_HOMEPAGE                     1016
#define IDC_TITLE_STRING3               1018
#define IDC_EDIT3                       1021
#define IDC_EDIT4                       1022
#define IDC_CHECK3                      1024
#define IDC_CHECK4                      1025
#define IDC_COMBO1                      1026
#define IDC_COMBO2                      1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        189
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
